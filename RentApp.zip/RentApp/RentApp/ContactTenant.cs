﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class ContactTenant : Form
    {
        public ContactTenant()
        {
            InitializeComponent();
        }

        static ContactTenant newContactTenant;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newContactTenant = new ContactTenant();
            newContactTenant.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newContactTenant = new ContactTenant();
            newContactTenant.ShowDialog();
            return buttin_id;

        }
    }
}
