﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class OccupatonStatus : Form
    {
        public OccupatonStatus()
        {
            InitializeComponent();
        }

        static OccupatonStatus newOccupatonStatus;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newOccupatonStatus = new OccupatonStatus();
            newOccupatonStatus.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newOccupatonStatus = new OccupatonStatus();
            newOccupatonStatus.ShowDialog();
            return buttin_id;

        }
    }
}
