﻿using RentApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace RentApp
{
    public partial class RentApp : Form
    {
        public RentApp()
        {
            InitializeComponent();
        }

        public static string tenant_first_name = "";
        public static string tenant_second_name = "";
        public static string tenant_third_name = "";
        public static string tenant_kra_pin = "";
        public static string tenant_email = "";
        public static string tenant_phone_number = "";
        public static string tenant_id_number = "";
        public static string tenant_unit = "";
        public static string propertyId = "";
        public static string unitsId = "";




        public void loadData()
        {


            try
            {

                string url = "http://165.232.121.9/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<LandlordModel> landlords = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("landlord/");
                consumeApi.Wait();


                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<LandlordModel>>();
                    displaydata.Wait();

                    landlords = displaydata.Result;

                    foreach (var landlord in landlords)
                    {
                        foreach (var property in landlord.property)
                        {
                            //propertyModelBindingSource.DataSource = (new propertyModel { name = property.name, address = property.address, county = property.county, Landlord = property.Landlord});
                            datagridViewOccupiedUnits.Rows.Add(new object[]
                            {
                                property.name,
                                property.address,
                                property.county,
                                landlord.first_name,
                                property.unit.Count,
                                property.id
                            });
                            foreach (var unit in property.unit)
                            {
                                //foreach (var tenant in unit.tenant)
                                //{
                                //    tenant_name = tenant.first_name;
                                //}

                                string tenant_number = "";
                                string moneyin = "";
                                int money = 0;
                                int moneyout = 0;

                                //zone
                                foreach (var transactions in unit.mpesa)
                                {
                                    moneyin = transactions.amount;
                                    for (int i = 0; i < moneyin.Length; i++)
                                    {
                                        if (char.IsDigit(moneyin[i]))
                                            money += moneyin[i];
                                    }
                                    zoneDataGridView.Rows.Add(new object[]
                                    {
                                    transactions.mpesa_code,
                                    transactions.amount,
                                    transactions.first_name,
                                    transactions.second_name,
                                    transactions.phone_number,
                                    transactions.current_date,
                                    transactions.current_time,
                                    transactions.account_number,
                                    unit.name
                                    });
                                }
                                //zone ends here


                                //live mpesa
                                

                                //live mpesa ends


                                foreach (var transactions in unit.mpesa)
                                {
                                    moneyin = transactions.amount;
                                    for (int i = 0; i < moneyin.Length; i++)
                                    {
                                        if (char.IsDigit(moneyin[i]))
                                            money += moneyin[i];
                                    }
                                    datagridViewTransactions.Rows.Add(new object[]
                                    {
                                    transactions.mpesa_code,
                                    transactions.amount,
                                    transactions.first_name,
                                    transactions.second_name,
                                    transactions.phone_number,
                                    transactions.current_date,
                                    transactions.current_time,
                                    transactions.account_number,
                                    unit.name
                                    });
                                }
                                foreach (var maintanances in unit.maintainance)
                                {
                                    moneyout = int.Parse(maintanances.amount);

                                    datagridViewMaintenance.Rows.Add(new object[]
                                    {
                                    maintanances.name,
                                    maintanances.description,
                                    maintanances.status,
                                    unit.name,
                                    maintanances.amount,
                                    });
                                    if (maintanances.status == true)
                                    {
                                        datagridViewComplete.Rows.Add(new object[]
                                        {
                                    maintanances.name,
                                    maintanances.description,
                                    maintanances.status,
                                    unit.name,
                                    maintanances.amount,
                                        });
                                    }
                                    if (maintanances.status == false)
                                    {
                                        datagridViewIncomplete.Rows.Add(new object[]
                                        {
                                    maintanances.name,
                                    maintanances.description,
                                    maintanances.status,
                                    unit.name,
                                    maintanances.amount,
                                        });
                                    }

                                }
                                foreach (var tenant in unit.tenants)
                                {
                                    tenant_number = tenant.phone_number;
                                    datagridViewTenants.Rows.Add(new object[]
                                    {
                                    tenant.first_name,
                                    tenant.second_name,
                                    tenant.third_name,
                                    tenant.kra_pin,
                                    tenant.email,
                                    tenant.phone_number,
                                    tenant.id_number,
                                    unit.name,
                                    unit.id
                                    });
                                }
                                bool isEmpty = !unit.tenants.Any();
                                if (isEmpty)
                                {
                                    datagridViewNotOccupiedUnits.Rows.Add(new object[]
                                    {
                                    unit.name,
                                    property.name,
                                    unit.deposit,
                                    unit.rent,
                                    unit.house_type,
                                    unit.no_of_bedrooms,
                                    unit.no_of_bathrooms,
                                    unit.tenants.Count,
                                    unit.id
                                    });
                                }
                                else
                                {
                                    datagridViewOccupiedUnits.Rows.Add(new object[]
                                    {
                                    unit.name,
                                    property.name,
                                    unit.deposit,
                                    unit.rent,
                                    unit.house_type,
                                    unit.no_of_bedrooms,
                                    moneyout,
                                    money,
                                    unit.id
                                    });
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //zone highlight
        //zoneDataGridView  dataGridViewTextBoxColumn7


                     private void zoneDataGridView_cellformatting(object sender, DataGridViewCellFormattingEventArgs e)
                     {
                        int columnIndex = 4; // quantity column , zero based index
                        foreach (DataGridViewRow row in zoneDataGridView.Rows)
                        {
                            int dataGridViewTextBoxColumn7;
                            if (int.TryParse(row.Cells[columnIndex].Value.ToString(), out dataGridViewTextBoxColumn7))
                            {
                                if (dataGridViewTextBoxColumn7 < 20)
                                    row.Cells[columnIndex].Style.BackColor = System.Drawing.Color.Red;
                                if (dataGridViewTextBoxColumn7 < 2)
                                    row.Cells[columnIndex].Style.BackColor = System.Drawing.Color.Orange;
                            }
                        }
        }


        //zone highlight ends here


        private void RentApp_Load(object sender, EventArgs e)
        {
           // bunifuButton27.Anchor = AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Left;

            bunifuPanel1.Height = 41;
             bunifuPanel5.Height = 45;
             bunifuPanel3.Height = 45;
             bunifuPanel4.Height = 40;
             bunifuPanel2.Height = 40;

            loadData();
        }

        private void bunifuButton21_Click_1(object sender, EventArgs e)
        {
            if (bunifuPanel1.Height == 243)
            {
                bunifuPanel1.Height = 45;
            }
            else
            {
                bunifuPanel1.Height = 243;
            }
        }

        private void bunifuButton224_Click(object sender, EventArgs e)
        {
            if (bunifuPanel5.Height == 243)
            {
                bunifuPanel5.Height = 45;
            }
            else
            {
                bunifuPanel5.Height = 243;
            }

        }

        private void bunifuButton212_Click(object sender, EventArgs e)
        {
            if (bunifuPanel3.Height == 241)
            {
                bunifuPanel3.Height = 45;
            }
            else
            {
                bunifuPanel3.Height = 241;
            }
        }

        private void bunifuButton27_Click(object sender, EventArgs e)
        {
            if (bunifuPanel4.Height == 244)
            {
                bunifuPanel4.Height = 45;
            }
            else
            {
                bunifuPanel4.Height = 244;
            }

        }

        private void bunifuShadowPanel1_ControlAdded(object sender, ControlEventArgs e)
        {

        }

        private void bunifuButton4_Click(object sender, EventArgs e)
        {
            if (bunifuPanel2.Height == 177)
            {
                bunifuPanel2.Height = 40;
            }
            else
            {
                bunifuPanel2.Height = 177;
            }

        }

        private void bunifuButton214_Click(object sender, EventArgs e)
        {
           string result = LiveFeed.ShowBox("");

           
        }

        private void bunifuButton214_MouseHover(object sender, EventArgs e)
        {
            MessageBox.Show("Mouse Hover");
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            string result = BestTenant.ShowBox("");
        }

        private void bunifuButton6_Click(object sender, EventArgs e)
        {
            string result = BestProperties.ShowBox("");
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            string result = Expenses.ShowBox("");
        }


        private void bunifuButton23_Click(object sender, EventArgs e)
        {

            bunifuButton23.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("Tenantstatus");
            //  string result = tenantView.ShowBox("");
        }

        private void bunifuButton223_Click(object sender, EventArgs e)
        {
            bunifuButton223.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("listProperty");

            //string result = PropertyView.ShowBox("");

        }

        private void bunifuButton215_Click(object sender, EventArgs e)
        {
            bunifuButton215.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("payments");
           // string result = TransactionView.ShowBox("");
        }

        private void bunifuButton28_Click(object sender, EventArgs e)
        {
            bunifuButton28.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("zones");
            //string result = ZoneView.ShowBox("");

        }

        private void bunifuButton3_Click(object sender, EventArgs e)
        {
           
           string result = PeriodicReport.ShowBox("");
        }

        private void bunifuButton29_Click(object sender, EventArgs e)
        {
            bunifuButton29.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("maintenance");
            //string result = MaintenanceView.ShowBox("");
        }

        private void buttonProperties_Click(object sender, EventArgs e)
        {
            buttonProperties.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("notOccupied");
            // string result = VacancyPosition.ShowBox("");

        }

        private void bunifuButton24_Click(object sender, EventArgs e)
        {
            string result = AddTenant.ShowBox("");

        }

        private void bunifuButton220_Click(object sender, EventArgs e)
        {
            string result = AddUnits.ShowBox("");

        }

        private void bunifuButton210_Click(object sender, EventArgs e)
        {
            string result = AddMaintenance.ShowBox("");

        }

        private void bunifuButton26_Click(object sender, EventArgs e)
        {
            string result = ContactTenant.ShowBox("");

        }

        private void bunifuButton221_Click(object sender, EventArgs e)
        {
            // string result = OccupatonStatus.ShowBox("");
            bunifuButton221.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("notOccupied");

        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            bunifuButton23.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("complete");
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            bunifuButton22.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("incomplete");

        }

        private void bunifuButton222_Click(object sender, EventArgs e)
        {
            bunifuButton222.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("occupied");

        }


         //export to excel code
        private void bunifuButton25_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewTransactions.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewTransactions.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewTransactions.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewTransactions.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewTransactions.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\payments.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();
        }

        private void bunifuButton216_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewTenants.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewTenants.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewTenants.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewTenants.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewTenants.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\tenants.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();

        }

        private void bunifuButton217_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewOccupiedUnits.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewOccupiedUnits.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewOccupiedUnits.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewOccupiedUnits.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewOccupiedUnits.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\propertyList.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();
        }

        private void bunifuButton225_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewComplete.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewComplete.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewComplete.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewComplete.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewComplete.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\maintenance Complete.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();
        }

        private void bunifuButton226_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewIncomplete.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewIncomplete.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewIncomplete.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewIncomplete.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewIncomplete.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\maintenanceIncomplete.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();
        }

        private void bunifuButton227_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewTransactions.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewTransactions.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewTransactions.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewTransactions.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewTransactions.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\occupied.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();
        }

        private void bunifuButton228_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewNotOccupiedUnits.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewNotOccupiedUnits.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewNotOccupiedUnits.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewNotOccupiedUnits.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewNotOccupiedUnits.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\Vacancy Position.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();
        }

        private void bunifuButton218_Click(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < datagridViewMaintenance.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = datagridViewMaintenance.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < datagridViewMaintenance.Rows.Count - 1; i++)
            {
                for (int j = 0; j < datagridViewMaintenance.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = datagridViewMaintenance.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            workbook.SaveAs("c:\\Vacancy Position.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application  
            app.Quit();

        }

        private void bunifuButton229_Click(object sender, EventArgs e)
        {
            bunifuButton229.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("complete");
        }

        private void bunifuButton230_Click(object sender, EventArgs e)
        {
            bunifuButton230.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("incomplete");
        }

        private void bunifuButton5_Click(object sender, EventArgs e)
        {
            bunifuButton5.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("tabPage2");

        }

        private void bunifuButton213_Click(object sender, EventArgs e)
        {
            bunifuButton213.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("amenity");

        }

        private void bunifuButton211_Click(object sender, EventArgs e)
        {
           

        }

        private void bunifuLabel4_Click(object sender, EventArgs e)
        {

        }

        private void bunifuDataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            propertyId = datagridViewOccupiedUnits.CurrentRow.Cells["id"].Value.ToString();
            AddProperty units = new AddProperty();
            units.Show();
        }

        private void pnlMenu_Click(object sender, EventArgs e)
        {

        }

        private void datagridViewOccupiedUnits_Click(object sender, EventArgs e)
        {

            propertyId = datagridViewOccupiedUnits.CurrentRow.Cells["id"].Value.ToString();
            AddUnits units = new AddUnits();
            units.Show();

            //propertyId = datagridViewOccupiedUnits.CurrentRow.Cells["id"].Value.ToString();
            //AddProperty units = new AddProperty();
            //units.Show();
        }

        private void datagridViewTenants_Click(object sender, EventArgs e)
        {
            propertyId = datagridViewTenants.CurrentRow.Cells["id_unit"].Value.ToString();
            AddTenant units = new AddTenant();
            units.Show();

        }

        private void datagridViewMaintenance_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void datagridViewMaintenance_Click(object sender, EventArgs e)
        {
            propertyId = datagridViewMaintenance.CurrentRow.Cells["maint_id"].Value.ToString();
            AddMaintenance units = new AddMaintenance();
            units.Show();

        }

        private void datagridViewComplete_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton211_Click_1(object sender, EventArgs e)
        {
            datagridViewOccupiedUnits.Rows.Clear();
            datagridViewOccupiedUnits.Rows.Clear();
            datagridViewNotOccupiedUnits.Rows.Clear();

            datagridViewMaintenance.Rows.Clear();
            datagridViewComplete.Rows.Clear();
            datagridViewIncomplete.Rows.Clear();

            datagridViewTransactions.Rows.Clear();
            datagridViewTenants.Rows.Clear();

            datagridViewComplete.Visible = false;
            datagridViewMaintenance.Visible = false;
            datagridViewIncomplete.Visible = true;
            loadData();
        }

        private void bunifuButton219_Click(object sender, EventArgs e)
        {
            datagridViewNotOccupiedUnits.Rows.Clear();
            datagridViewOccupiedUnits.Rows.Clear();
            datagridViewNotOccupiedUnits.Rows.Clear();

            datagridViewMaintenance.Rows.Clear();
            datagridViewComplete.Rows.Clear();
            datagridViewIncomplete.Rows.Clear();

            datagridViewTransactions.Rows.Clear();
            datagridViewTenants.Rows.Clear();

            datagridViewComplete.Visible = false;
            datagridViewMaintenance.Visible = false;
            datagridViewIncomplete.Visible = true;
            loadData();

        }



        private void bunifuDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            unitsId = bunifuDataGridView1.CurrentRow.Cells["unit_id"].Value.ToString();
            AddUnits units = new AddUnits();
            units.Show();
        }

        private void datagridViewNotOccupiedUnits_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void datagridViewNotOccupiedUnits_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            unitsId = datagridViewNotOccupiedUnits.CurrentRow.Cells[8].Value.ToString();
            AddTenant units = new AddTenant();
            units.Show();

        }

        private void bunifuButton22_Click(object sender, EventArgs e)
        {
            bunifuButton22.Top = ((Control)sender).Top;
            bunifuPages1.SetPage("Tenantstatus");
            //  string result = tenantView.ShowBox("");
        }

        private void bunifuShapes3_ShapeChanged(object sender, Bunifu.UI.WinForms.BunifuShapes.ShapeChangedEventArgs e)
        {

        }

        private void bunifuShapes1_ShapeChanged(object sender, Bunifu.UI.WinForms.BunifuShapes.ShapeChangedEventArgs e)
        {

        }

        private void bunifuShapes1_Click(object sender, EventArgs e)
        {
            //bunifuShapes1.Top = ((Control)sender).Top;
            //bunifuPages1.SetPage("greenZone");

        }

        private void bunifuIconButton1_Click(object sender, EventArgs e)
        {
            string result = GreenZone.ShowBox("");

        }

       

        private void bunifuIconButton3_Click(object sender, EventArgs e)
        {
            string result = RedZone.ShowBox("");
        }

        private void bunifuIconButton2_Click(object sender, EventArgs e)
        {
            string result = BlueZone.ShowBox("");

        }


        //propertyId = datagridViewOccupiedUnits.CurrentRow.Cells["id"].Value.ToString();
        //    AddProperty units = new AddProperty();
        //units.Show();
    }
}
