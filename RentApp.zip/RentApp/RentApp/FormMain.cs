﻿using Newtonsoft.Json;
using RentApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }



        public void loadForm()
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<propertyModel> properties = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("property/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<propertyModel>>();
                    displaydata.Wait();

                    properties = displaydata.Result;

                    //landlordDropDown.ValueMember = "ID";
                    //landlordDropDown.DisplayMember = "Name";
                    //landlordDropDown.DataSource = properties;

                    string count_tenants = "";
                    foreach (var property in properties)
                    {
                        foreach (var unit in property.unit)
                        {
                            count_tenants = unit.tenants.Count.ToString();

                        }
                    }

                    datagridViewProperties.DataSource = properties;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void loadUnits()
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<unitModel> units = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("units/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<unitModel>>();
                    displaydata.Wait();

                    units = displaydata.Result;

                    //landlordDropDown.ValueMember = "ID";
                    //landlordDropDown.DisplayMember = "Name";
                    //landlordDropDown.DataSource = properties;

                    string count_tenants = "";
                    foreach (var unit in units)
                    {

                    }

                    datagridViewUnits.DataSource = units;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void loadTenants()
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<tenantModel> tenants = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("tenants/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<tenantModel>>();
                    displaydata.Wait();

                    tenants = displaydata.Result;

                    //landlordDropDown.ValueMember = "ID";
                    //landlordDropDown.DisplayMember = "Name";
                    //landlordDropDown.DataSource = properties;

                    foreach (var tenant in tenants)
                    {

                    }

                    datagridViewTenant.DataSource = tenants;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void loadTransactions()
        {
            try
            {
                string url = "http://longrichkenya.co.ke/orders/mpesa/";

                HttpClient client = new HttpClient();

                IEnumerable<transactionModel> transactions = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("transaction/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<transactionModel>>();
                    displaydata.Wait();

                    transactions = displaydata.Result;

                    //dataGridViewTenants.DataSource = transactions;
                    double sum = 0;
                    foreach (var item in transactions)
                    {
                        string stramount = item.amount;
                        string amount = Regex.Match(stramount, @"\d+").Value;
                        sum += Convert.ToDouble(amount);
                        //MessageBox.Show(amount);
                    }
                    lblTotal.Text = sum.ToString();

                    datagridTransactions.DataSource = transactions;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void countTenants()
        {
            try
            {
                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<tenantModel> tenants = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("tenants/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<tenantModel>>();
                    displaydata.Wait();

                    tenants = displaydata.Result;

                    lblAvail.Text = tenants.Count().ToString();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void countUnits()
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<unitModel> units = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("units/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<unitModel>>();
                    displaydata.Wait();

                    units = displaydata.Result;

                    lblUnit.Text = units.Count().ToString();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            loadForm();
            loadUnits();
            loadTenants();
            loadTransactions();
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
        }

        private void labelDashboard_Click_1(object sender, EventArgs e)
        {
            var lbl = (Label)sender;

            foreach (var item in lbl.Parent.Controls)
            {
                if (item.GetType() != typeof(Label)) continue;
                var curlbl = (Label)item;
                curlbl.Font = lblIdle.Font;
                curlbl.ForeColor = lblIdle.ForeColor;
            }

            lbl.Font = lblActive.Font;
            lbl.ForeColor = lblActive.ForeColor;


            pages.SetPage(lbl.Text);
        }

        private async void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                var property = new propertyModel()
                {
                    name = textBoxName.Text,
                    address = textBoxAddress.Text,
                    county = textBoxCounty.Text,
                    Landlord = textboxLandlord.Text

                };

                var json = JsonConvert.SerializeObject(property);
                StringContent data = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url + "property/", data);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Insert successfull");
                    textBoxName.Clear();
                    textBoxAddress.Clear();
                    textBoxCounty.Clear();
                    textboxLandlord.Clear();
                    loadForm();
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private async void buttonAddUnit_Click(object sender, EventArgs e)
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/units/";

                HttpClient client = new HttpClient();

                var units = new unitModel()
                {
                    property = int.Parse(textBoxProperty.Text),
                    name = textBoxName.Text,
                    deposit = textBoxDeposit.Text,
                    rent = textBoxRent.Text,
                    house_type = textBoxHouseType.Text,
                    no_of_bedrooms = int.Parse(textBoxNumberOfBedrooms.Text),
                    no_of_bathrooms = int.Parse(textBoxNumberOfNathRooms.Text),
                    balcon = textBoxBalcony.Text,
                    floor = TextBoxFloor.Text,
                    square_foot = textBoxSquareFoot.Text

                };
                MessageBox.Show("1");
                var jsonData = JsonConvert.SerializeObject(units);
                StringContent dataUnit = new StringContent(jsonData, Encoding.UTF8, "application/json");

                MessageBox.Show("2");
                HttpResponseMessage response = await client.PostAsync(url, dataUnit);

                MessageBox.Show("3");
                if (response.IsSuccessStatusCode)
                {

                    MessageBox.Show("4");
                    MessageBox.Show("Insert successfull");
                    textBoxProperty.Clear();
                    textBoxName.Clear();
                    textBoxDeposit.Clear();
                    textBoxRent.Clear();
                    textBoxHouseType.Clear();
                    textBoxNumberOfBedrooms.Clear();
                    textBoxNumberOfNathRooms.Clear();
                    textBoxBalcony.Clear();
                    TextBoxFloor.Clear();
                    textBoxSquareFoot.Clear();
                    loadUnits();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private async void buttonAddTenant_Click(object sender, EventArgs e)
        {

            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                var tenant = new tenantModel()
                {
                    unit = int.Parse(textBoxUnit.Text),
                    first_name = textBoxFName.Text,
                    second_name = textBoxSname.Text,
                    third_name = textBoxTName.Text,
                    kra_pin = textBoxKra.Text,
                    email = textBoxEmail.Text,
                    phone_number = textBoxPnumber.Text,
                    id_number = TextBoxIDNumber.Text

                };

                var jsontenant = JsonConvert.SerializeObject(tenant);
                StringContent data = new StringContent(jsontenant, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url + "tenants/", data);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Insert successfull");
                    textBoxUnit.Clear();
                    textBoxFName.Clear();
                    textBoxSname.Clear();
                    textBoxTName.Clear();
                    textBoxKra.Clear();
                    textBoxEmail.Clear();
                    textBoxPnumber.Clear();
                    TextBoxIDNumber.Clear();
                    loadTenants();
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuPanel4_Click(object sender, EventArgs e)
        {

        }
    }
}
