﻿using RentApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class LiveFeed : Form
    {
        static LiveFeed newLiveFeedCall;
        static string buttin_id;
        public LiveFeed()
        {
            InitializeComponent();
        }



        public static string ShowBox(String txtMessage)
        {
            newLiveFeedCall = new LiveFeed();
            newLiveFeedCall.lblFeed.Text = txtMessage;
            newLiveFeedCall.ShowDialog();
            return buttin_id;
            
        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newLiveFeedCall = new LiveFeed();
            newLiveFeedCall.lblTitle.Text = txtTitle;
            newLiveFeedCall.lblFeed.Text = txtMessage;
            newLiveFeedCall.ShowDialog();
            return buttin_id;

        }


        private void LiveFeed_Load(object sender, EventArgs e)
        {

            try
            {

                string url = "http://165.232.121.9/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<LandlordModel> landlords = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("landlord/");
                consumeApi.Wait();


                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<LandlordModel>>();
                    displaydata.Wait();

                    landlords = displaydata.Result;

                    foreach (var landlord in landlords)
                    {
                        foreach (var property in landlord.property)
                        {
                            foreach (var unit in property.unit)
                            {
                                //foreach (var tenant in unit.tenant)
                                //{
                                //    tenant_name = tenant.first_name;
                                //}

                                string tenant_number = "";
                                string moneyin = "";
                                int money = 0;
                                int moneyout = 0;




                                foreach (var transactions in unit.mpesa)
                                {
                                    moneyin = transactions.amount;
                                    for (int i = 0; i < moneyin.Length; i++)
                                    {
                                        if (char.IsDigit(moneyin[i]))
                                            money += moneyin[i];
                                    }
                                    datagridViewTransactions.Rows.Add(new object[]
                                    {
                                    transactions.mpesa_code,
                                    transactions.amount,
                                    transactions.first_name,
                                    transactions.second_name,
                                    transactions.phone_number,
                                    transactions.current_date,
                                    transactions.current_time,
                                    transactions.account_number,
                                    unit.name
                                    });
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        /**  private void btnOk_Click(object sender, EventArgs e)
          {
              buttin_id = "1";
              newLiveFeedCall.Dispose();
          }
          private void btnCancel_Click(object sender, EventArgs e)
          {
              buttin_id = "2";
              newLiveFeedCall.Dispose();
          }
        */
    }
}
