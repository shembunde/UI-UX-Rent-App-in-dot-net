﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class FormDashboard : Form
    {
        private bool isCollapsed;
        public FormDashboard()
        {
            InitializeComponent();
        }

        void HideMenu()
        {
            foreach(var pnl in pnlMenu.Controls.OfType<Panel>())
            {
                pnl.Height = 45;
            }
        }
        void ShowSubMenu(Panel pnl)
        {
            pnl.Height = pnl.MaximumSize.Height;
        }

        private void labelDashboard_Click(object sender, EventArgs e)
        {
            var lbl = (Label)sender;

            foreach (var item in lbl.Parent.Controls)
            {
                if (item.GetType() != typeof(Label)) continue;
                var curlbl = (Label)item;
                curlbl.Font = lblIdle.Font;
                curlbl.ForeColor = lblIdle.ForeColor;
            }

            lbl.Font = lblActive.Font;
            lbl.ForeColor = lblActive.ForeColor;


            pages.SetPage(lbl.Text);
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
