﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class BestProperties : Form
    {
        public BestProperties()
        {
            InitializeComponent();
        }

        static BestProperties newBestTenantCall;
        static string buttin_id;

        public static string ShowBox(String txtMessage)
        {
            newBestTenantCall = new BestProperties();
            newBestTenantCall.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newBestTenantCall = new BestProperties();
            newBestTenantCall.ShowDialog();
            return buttin_id;

        }
    }
}
