﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentApp.Model;

namespace RentApp
{
    public partial class PeriodicReport : Form
    {
        public PeriodicReport()
        {
            InitializeComponent();
        }

        static PeriodicReport newPeriodicReport;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newPeriodicReport = new PeriodicReport();
            newPeriodicReport.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newPeriodicReport = new PeriodicReport();
            newPeriodicReport.ShowDialog();
            return buttin_id;

        }



        private void bunifuButton21_Click(object sender, EventArgs e)
        {
          
        }

        private void bunifuLabel6_Click(object sender, EventArgs e)
        {

        }

        private void PeriodicReport_Load(object sender, EventArgs e)
        {


            //try
            //{

            //    string url = "http://165.232.121.9/properties/";

            //    HttpClient client = new HttpClient();

            //    IEnumerable<LandlordModel> landlords = null;
            //    client.BaseAddress = new Uri(url);
            //    var consumeApi = client.GetAsync("landlord/");
            //    consumeApi.Wait();


            //    var readdata = consumeApi.Result;
            //    if (readdata.IsSuccessStatusCode)
            //    {
            //        var displaydata = readdata.Content.ReadAsAsync<IList<LandlordModel>>();
            //        displaydata.Wait();

            //        landlords = displaydata.Result;

            //        foreach (var landlord in landlords)
            //        {
            //            foreach (var property in landlord.property)
            //            {
            //                foreach (var unit in property.unit)
            //                {
            //                    string tenant_number = "";
            //                    string moneyin = "";
            //                    int money = 0;
            //                    int moneyout = 0;

            //                    foreach (var tenant in unit.tenants)
            //                    {
            //                        tenant_number = tenant.phone_number;
            //                        datagridViewReports.Rows.Add(new object[]
            //                        {
            //                        tenant.first_name,
            //                        tenant.second_name,
            //                        tenant.third_name,
            //                        tenant.kra_pin,
            //                        tenant.email,
            //                        tenant.phone_number,
            //                        tenant.id_number,
            //                        unit.name,
            //                        unit.id
            //                        });

            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

          

        }

        private void bunifuTextBox1_TextChanged(object sender, EventArgs e)
        {



            try
            {

                string url = "http://165.232.121.9/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<LandlordModel> landlords = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("landlord/");
                consumeApi.Wait();


                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<LandlordModel>>();
                    displaydata.Wait();

                    landlords = displaydata.Result;

                    foreach (var landlord in landlords)
                    {
                        foreach (var property in landlord.property)
                        {
                            foreach (var unit in property.unit)
                            {
                                string tenant_number = "";
                                string moneyin = "";
                                int money = 0;
                                int moneyout = 0;

                                foreach (var tenant in unit.tenants)
                                {
                                    tenant_number = tenant.phone_number;
                                    datagridViewReports.Rows.Add(new object[]
                                    {
                                    tenant.first_name,
                                    tenant.second_name,
                                    tenant.third_name,
                                    tenant.kra_pin,
                                    tenant.email,
                                    tenant.phone_number,
                                    tenant.id_number,
                                    unit.name,
                                    unit.id
                                    });

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



            BindingSource bs = new BindingSource();
            bs.DataSource = datagridViewReports.DataSource;
            bs.Filter = "first_name like '%" + bunifuTextBox1.Text + "%'";
            datagridViewReports.DataSource = bs.DataSource;

            //if (e.KeyCode == Keys.Enter)

            //{

            //    if (string.IsNullOrEmpty(bunifuTextBox1.Text))

            //        bs.Filter = string.Empty;
            //    else
            //        bs.Filter = string.Format("{0}='{1}'", bunifuTextBox3.Text, bunifuTextBox1.Text);
            //}


        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
           
        }

        private void bunifuTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            //BindingSource bs = new BindingSource();
            //bs.DataSource = datagridViewReports.DataSource;
            //if (e.KeyCode == Keys.Enter)

            //{

            //    if (string.IsNullOrEmpty(bunifuTextBox1.Text))

            //        bs.Filter = string.Empty;
            //    else
            //        bs.Filter = string.Format("{0}='{1}'", bunifuTextBox3.Text, bunifuTextBox1.Text);
            //}

        }
    }
}
