﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class Expenses : Form
    {
        public Expenses()
        {
            InitializeComponent();
        }

        static Expenses newBestTenantCall;
        static string buttin_id;
       

        public static string ShowBox(String txtMessage)
        {
            newBestTenantCall = new Expenses();
            newBestTenantCall.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newBestTenantCall = new Expenses();
            newBestTenantCall.ShowDialog();
            return buttin_id;

        }

    }
}
