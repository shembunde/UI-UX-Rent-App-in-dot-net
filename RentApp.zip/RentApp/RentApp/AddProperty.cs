﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Security.Policy;
using RentApp.Model;

namespace RentApp
{
    public partial class AddProperty : Form
    {
        public AddProperty()
        {
            InitializeComponent();
        }
        HttpClient client = new HttpClient();

        private async void bunifuButton21_Click(object sender, EventArgs e)
        {
            try
            {

                var url = "http://165.232.121.9/create_property/";
                

                var property = new propertyModel()
                {
                    name = textboxName.Text,
                    address = textboxAddress.Text,
                    county = textboxCounty.Text,
                    Landlord = textboxLandlord.Text
                 //   textBoxID = textBoxID,text

                };

                var json = JsonConvert.SerializeObject(property);
                var data = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url, data);

                if (response.IsSuccessStatusCode)
                {
                    textboxName.Clear();
                    textboxAddress.Clear();
                    textboxCounty.Clear();
                    textboxLandlord.Clear();
                  //  textBoxID.Clear();


                    RentApp app = new RentApp();
                    app.loadData();
                }
                else
                {
                    MessageBox.Show("Something went wrong");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AddProperty_Load(object sender, EventArgs e)
        {
            textboxName.Text = RentApp.propertyId;
        }
    }
}
