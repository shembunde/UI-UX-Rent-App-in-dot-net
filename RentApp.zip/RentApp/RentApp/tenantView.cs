﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class tenantView : Form
    {
        public tenantView()
        {
            InitializeComponent();
        }

        static tenantView newtenantView;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newtenantView = new tenantView();
            newtenantView.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newtenantView = new tenantView();
            newtenantView.ShowDialog();
            return buttin_id;

        }

    }
}
