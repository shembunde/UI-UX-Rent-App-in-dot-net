﻿namespace RentApp
{
    partial class FormProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProperty));
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuPanel1 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuPanel3 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuIconButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.textBoxlandLord = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textBoxCounty = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textBoxAddress = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textBoxName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuPanel2 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuPanel4 = new Bunifu.UI.WinForms.BunifuPanel();
            this.textNumberOfTenants = new Bunifu.UI.WinForms.BunifuTextBox();
            this.TextNumberOFUnits = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuIconButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuIconButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.dataGridViewProperties = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.propertyModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bunifuPanel1.SuspendLayout();
            this.bunifuPanel3.SuspendLayout();
            this.bunifuPanel2.SuspendLayout();
            this.bunifuPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.propertyModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuPanel1
            // 
            this.bunifuPanel1.BackgroundColor = System.Drawing.Color.Transparent;
            this.bunifuPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel1.BackgroundImage")));
            this.bunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel1.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel1.BorderRadius = 3;
            this.bunifuPanel1.BorderThickness = 1;
            this.bunifuPanel1.Controls.Add(this.bunifuPanel3);
            this.bunifuPanel1.Controls.Add(this.bunifuPanel2);
            this.bunifuPanel1.Controls.Add(this.dataGridViewProperties);
            this.bunifuPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuPanel1.Name = "bunifuPanel1";
            this.bunifuPanel1.ShowBorders = true;
            this.bunifuPanel1.Size = new System.Drawing.Size(1266, 729);
            this.bunifuPanel1.TabIndex = 0;
            // 
            // bunifuPanel3
            // 
            this.bunifuPanel3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(150)))), ((int)(((byte)(190)))));
            this.bunifuPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel3.BackgroundImage")));
            this.bunifuPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel3.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel3.BorderRadius = 23;
            this.bunifuPanel3.BorderThickness = 1;
            this.bunifuPanel3.Controls.Add(this.bunifuIconButton1);
            this.bunifuPanel3.Controls.Add(this.bunifuLabel1);
            this.bunifuPanel3.Controls.Add(this.textBoxlandLord);
            this.bunifuPanel3.Controls.Add(this.textBoxCounty);
            this.bunifuPanel3.Controls.Add(this.textBoxAddress);
            this.bunifuPanel3.Controls.Add(this.textBoxName);
            this.bunifuPanel3.Location = new System.Drawing.Point(908, 326);
            this.bunifuPanel3.Name = "bunifuPanel3";
            this.bunifuPanel3.ShowBorders = true;
            this.bunifuPanel3.Size = new System.Drawing.Size(355, 400);
            this.bunifuPanel3.TabIndex = 3;
            // 
            // bunifuIconButton1
            // 
            this.bunifuIconButton1.AllowAnimations = true;
            this.bunifuIconButton1.AllowBorderColorChanges = true;
            this.bunifuIconButton1.AllowMouseEffects = true;
            this.bunifuIconButton1.AnimationSpeed = 200;
            this.bunifuIconButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton1.BackgroundColor = System.Drawing.Color.LimeGreen;
            this.bunifuIconButton1.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuIconButton1.BorderRadius = 1;
            this.bunifuIconButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton1.BorderThickness = 1;
            this.bunifuIconButton1.ColorContrastOnClick = 30;
            this.bunifuIconButton1.ColorContrastOnHover = 30;
            this.bunifuIconButton1.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuIconButton1.CustomizableEdges = borderEdges1;
            this.bunifuIconButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuIconButton1.Image")));
            this.bunifuIconButton1.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton1.Location = new System.Drawing.Point(145, 323);
            this.bunifuIconButton1.Name = "bunifuIconButton1";
            this.bunifuIconButton1.RoundBorders = true;
            this.bunifuIconButton1.ShowBorders = true;
            this.bunifuIconButton1.Size = new System.Drawing.Size(60, 60);
            this.bunifuIconButton1.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton1.TabIndex = 5;
            this.bunifuIconButton1.Click += new System.EventHandler(this.bunifuIconButton1_Click);
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(47, 26);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(101, 21);
            this.bunifuLabel1.TabIndex = 4;
            this.bunifuLabel1.Text = "Add Property";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // textBoxlandLord
            // 
            this.textBoxlandLord.AcceptsReturn = false;
            this.textBoxlandLord.AcceptsTab = false;
            this.textBoxlandLord.AnimationSpeed = 200;
            this.textBoxlandLord.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textBoxlandLord.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textBoxlandLord.AutoSizeHeight = true;
            this.textBoxlandLord.BackColor = System.Drawing.Color.Transparent;
            this.textBoxlandLord.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textBoxlandLord.BackgroundImage")));
            this.textBoxlandLord.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textBoxlandLord.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textBoxlandLord.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textBoxlandLord.BorderColorIdle = System.Drawing.Color.Silver;
            this.textBoxlandLord.BorderRadius = 23;
            this.textBoxlandLord.BorderThickness = 1;
            this.textBoxlandLord.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textBoxlandLord.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxlandLord.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textBoxlandLord.DefaultText = "";
            this.textBoxlandLord.FillColor = System.Drawing.Color.White;
            this.textBoxlandLord.HideSelection = true;
            this.textBoxlandLord.IconLeft = null;
            this.textBoxlandLord.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxlandLord.IconPadding = 10;
            this.textBoxlandLord.IconRight = null;
            this.textBoxlandLord.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxlandLord.Lines = new string[0];
            this.textBoxlandLord.Location = new System.Drawing.Point(47, 259);
            this.textBoxlandLord.MaxLength = 32767;
            this.textBoxlandLord.MinimumSize = new System.Drawing.Size(1, 1);
            this.textBoxlandLord.Modified = false;
            this.textBoxlandLord.Multiline = false;
            this.textBoxlandLord.Name = "textBoxlandLord";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxlandLord.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textBoxlandLord.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxlandLord.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxlandLord.OnIdleState = stateProperties4;
            this.textBoxlandLord.Padding = new System.Windows.Forms.Padding(3);
            this.textBoxlandLord.PasswordChar = '\0';
            this.textBoxlandLord.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.textBoxlandLord.PlaceholderText = "Landlord";
            this.textBoxlandLord.ReadOnly = false;
            this.textBoxlandLord.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxlandLord.SelectedText = "";
            this.textBoxlandLord.SelectionLength = 0;
            this.textBoxlandLord.SelectionStart = 0;
            this.textBoxlandLord.ShortcutsEnabled = true;
            this.textBoxlandLord.Size = new System.Drawing.Size(260, 39);
            this.textBoxlandLord.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textBoxlandLord.TabIndex = 3;
            this.textBoxlandLord.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBoxlandLord.TextMarginBottom = 0;
            this.textBoxlandLord.TextMarginLeft = 3;
            this.textBoxlandLord.TextMarginTop = 1;
            this.textBoxlandLord.TextPlaceholder = "Landlord";
            this.textBoxlandLord.UseSystemPasswordChar = false;
            this.textBoxlandLord.WordWrap = true;
            // 
            // textBoxCounty
            // 
            this.textBoxCounty.AcceptsReturn = false;
            this.textBoxCounty.AcceptsTab = false;
            this.textBoxCounty.AnimationSpeed = 200;
            this.textBoxCounty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textBoxCounty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textBoxCounty.AutoSizeHeight = true;
            this.textBoxCounty.BackColor = System.Drawing.Color.Transparent;
            this.textBoxCounty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textBoxCounty.BackgroundImage")));
            this.textBoxCounty.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textBoxCounty.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textBoxCounty.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textBoxCounty.BorderColorIdle = System.Drawing.Color.Silver;
            this.textBoxCounty.BorderRadius = 23;
            this.textBoxCounty.BorderThickness = 1;
            this.textBoxCounty.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textBoxCounty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxCounty.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textBoxCounty.DefaultText = "";
            this.textBoxCounty.FillColor = System.Drawing.Color.White;
            this.textBoxCounty.HideSelection = true;
            this.textBoxCounty.IconLeft = null;
            this.textBoxCounty.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxCounty.IconPadding = 10;
            this.textBoxCounty.IconRight = null;
            this.textBoxCounty.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxCounty.Lines = new string[0];
            this.textBoxCounty.Location = new System.Drawing.Point(47, 200);
            this.textBoxCounty.MaxLength = 32767;
            this.textBoxCounty.MinimumSize = new System.Drawing.Size(1, 1);
            this.textBoxCounty.Modified = false;
            this.textBoxCounty.Multiline = false;
            this.textBoxCounty.Name = "textBoxCounty";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxCounty.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textBoxCounty.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxCounty.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxCounty.OnIdleState = stateProperties8;
            this.textBoxCounty.Padding = new System.Windows.Forms.Padding(3);
            this.textBoxCounty.PasswordChar = '\0';
            this.textBoxCounty.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.textBoxCounty.PlaceholderText = "County";
            this.textBoxCounty.ReadOnly = false;
            this.textBoxCounty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxCounty.SelectedText = "";
            this.textBoxCounty.SelectionLength = 0;
            this.textBoxCounty.SelectionStart = 0;
            this.textBoxCounty.ShortcutsEnabled = true;
            this.textBoxCounty.Size = new System.Drawing.Size(260, 39);
            this.textBoxCounty.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textBoxCounty.TabIndex = 2;
            this.textBoxCounty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBoxCounty.TextMarginBottom = 0;
            this.textBoxCounty.TextMarginLeft = 3;
            this.textBoxCounty.TextMarginTop = 1;
            this.textBoxCounty.TextPlaceholder = "County";
            this.textBoxCounty.UseSystemPasswordChar = false;
            this.textBoxCounty.WordWrap = true;
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.AcceptsReturn = false;
            this.textBoxAddress.AcceptsTab = false;
            this.textBoxAddress.AnimationSpeed = 200;
            this.textBoxAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textBoxAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textBoxAddress.AutoSizeHeight = true;
            this.textBoxAddress.BackColor = System.Drawing.Color.Transparent;
            this.textBoxAddress.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textBoxAddress.BackgroundImage")));
            this.textBoxAddress.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textBoxAddress.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textBoxAddress.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textBoxAddress.BorderColorIdle = System.Drawing.Color.Silver;
            this.textBoxAddress.BorderRadius = 23;
            this.textBoxAddress.BorderThickness = 1;
            this.textBoxAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textBoxAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxAddress.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textBoxAddress.DefaultText = "";
            this.textBoxAddress.FillColor = System.Drawing.Color.White;
            this.textBoxAddress.HideSelection = true;
            this.textBoxAddress.IconLeft = null;
            this.textBoxAddress.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxAddress.IconPadding = 10;
            this.textBoxAddress.IconRight = null;
            this.textBoxAddress.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxAddress.Lines = new string[0];
            this.textBoxAddress.Location = new System.Drawing.Point(47, 138);
            this.textBoxAddress.MaxLength = 32767;
            this.textBoxAddress.MinimumSize = new System.Drawing.Size(1, 1);
            this.textBoxAddress.Modified = false;
            this.textBoxAddress.Multiline = false;
            this.textBoxAddress.Name = "textBoxAddress";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxAddress.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textBoxAddress.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxAddress.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxAddress.OnIdleState = stateProperties12;
            this.textBoxAddress.Padding = new System.Windows.Forms.Padding(3);
            this.textBoxAddress.PasswordChar = '\0';
            this.textBoxAddress.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.textBoxAddress.PlaceholderText = "Address";
            this.textBoxAddress.ReadOnly = false;
            this.textBoxAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxAddress.SelectedText = "";
            this.textBoxAddress.SelectionLength = 0;
            this.textBoxAddress.SelectionStart = 0;
            this.textBoxAddress.ShortcutsEnabled = true;
            this.textBoxAddress.Size = new System.Drawing.Size(260, 39);
            this.textBoxAddress.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textBoxAddress.TabIndex = 1;
            this.textBoxAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBoxAddress.TextMarginBottom = 0;
            this.textBoxAddress.TextMarginLeft = 3;
            this.textBoxAddress.TextMarginTop = 1;
            this.textBoxAddress.TextPlaceholder = "Address";
            this.textBoxAddress.UseSystemPasswordChar = false;
            this.textBoxAddress.WordWrap = true;
            // 
            // textBoxName
            // 
            this.textBoxName.AcceptsReturn = false;
            this.textBoxName.AcceptsTab = false;
            this.textBoxName.AnimationSpeed = 200;
            this.textBoxName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textBoxName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textBoxName.AutoSizeHeight = true;
            this.textBoxName.BackColor = System.Drawing.Color.Transparent;
            this.textBoxName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textBoxName.BackgroundImage")));
            this.textBoxName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textBoxName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textBoxName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textBoxName.BorderColorIdle = System.Drawing.Color.Silver;
            this.textBoxName.BorderRadius = 23;
            this.textBoxName.BorderThickness = 1;
            this.textBoxName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textBoxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textBoxName.DefaultText = "";
            this.textBoxName.FillColor = System.Drawing.Color.White;
            this.textBoxName.HideSelection = true;
            this.textBoxName.IconLeft = null;
            this.textBoxName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxName.IconPadding = 10;
            this.textBoxName.IconRight = null;
            this.textBoxName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxName.Lines = new string[0];
            this.textBoxName.Location = new System.Drawing.Point(47, 79);
            this.textBoxName.MaxLength = 32767;
            this.textBoxName.MinimumSize = new System.Drawing.Size(1, 1);
            this.textBoxName.Modified = false;
            this.textBoxName.Multiline = false;
            this.textBoxName.Name = "textBoxName";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxName.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textBoxName.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxName.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textBoxName.OnIdleState = stateProperties16;
            this.textBoxName.Padding = new System.Windows.Forms.Padding(3);
            this.textBoxName.PasswordChar = '\0';
            this.textBoxName.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.textBoxName.PlaceholderText = "Name";
            this.textBoxName.ReadOnly = false;
            this.textBoxName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBoxName.SelectedText = "";
            this.textBoxName.SelectionLength = 0;
            this.textBoxName.SelectionStart = 0;
            this.textBoxName.ShortcutsEnabled = true;
            this.textBoxName.Size = new System.Drawing.Size(260, 39);
            this.textBoxName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textBoxName.TabIndex = 0;
            this.textBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBoxName.TextMarginBottom = 0;
            this.textBoxName.TextMarginLeft = 3;
            this.textBoxName.TextMarginTop = 1;
            this.textBoxName.TextPlaceholder = "Name";
            this.textBoxName.UseSystemPasswordChar = false;
            this.textBoxName.WordWrap = true;
            // 
            // bunifuPanel2
            // 
            this.bunifuPanel2.BackgroundColor = System.Drawing.Color.White;
            this.bunifuPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel2.BackgroundImage")));
            this.bunifuPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel2.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel2.BorderRadius = 3;
            this.bunifuPanel2.BorderThickness = 1;
            this.bunifuPanel2.Controls.Add(this.bunifuPanel4);
            this.bunifuPanel2.Location = new System.Drawing.Point(889, 0);
            this.bunifuPanel2.Name = "bunifuPanel2";
            this.bunifuPanel2.ShowBorders = true;
            this.bunifuPanel2.Size = new System.Drawing.Size(377, 311);
            this.bunifuPanel2.TabIndex = 2;
            // 
            // bunifuPanel4
            // 
            this.bunifuPanel4.BackgroundColor = System.Drawing.Color.IndianRed;
            this.bunifuPanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel4.BackgroundImage")));
            this.bunifuPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel4.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel4.BorderRadius = 23;
            this.bunifuPanel4.BorderThickness = 1;
            this.bunifuPanel4.Controls.Add(this.textNumberOfTenants);
            this.bunifuPanel4.Controls.Add(this.TextNumberOFUnits);
            this.bunifuPanel4.Controls.Add(this.textName);
            this.bunifuPanel4.Controls.Add(this.bunifuIconButton2);
            this.bunifuPanel4.Controls.Add(this.bunifuIconButton3);
            this.bunifuPanel4.Location = new System.Drawing.Point(66, 3);
            this.bunifuPanel4.Name = "bunifuPanel4";
            this.bunifuPanel4.ShowBorders = true;
            this.bunifuPanel4.Size = new System.Drawing.Size(260, 305);
            this.bunifuPanel4.TabIndex = 2;
            // 
            // textNumberOfTenants
            // 
            this.textNumberOfTenants.AcceptsReturn = false;
            this.textNumberOfTenants.AcceptsTab = false;
            this.textNumberOfTenants.AnimationSpeed = 200;
            this.textNumberOfTenants.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textNumberOfTenants.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textNumberOfTenants.AutoSizeHeight = true;
            this.textNumberOfTenants.BackColor = System.Drawing.Color.Transparent;
            this.textNumberOfTenants.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textNumberOfTenants.BackgroundImage")));
            this.textNumberOfTenants.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textNumberOfTenants.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textNumberOfTenants.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textNumberOfTenants.BorderColorIdle = System.Drawing.Color.Silver;
            this.textNumberOfTenants.BorderRadius = 23;
            this.textNumberOfTenants.BorderThickness = 1;
            this.textNumberOfTenants.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textNumberOfTenants.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textNumberOfTenants.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textNumberOfTenants.DefaultText = "";
            this.textNumberOfTenants.FillColor = System.Drawing.Color.White;
            this.textNumberOfTenants.HideSelection = true;
            this.textNumberOfTenants.IconLeft = null;
            this.textNumberOfTenants.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textNumberOfTenants.IconPadding = 10;
            this.textNumberOfTenants.IconRight = null;
            this.textNumberOfTenants.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textNumberOfTenants.Lines = new string[0];
            this.textNumberOfTenants.Location = new System.Drawing.Point(16, 150);
            this.textNumberOfTenants.MaxLength = 32767;
            this.textNumberOfTenants.MinimumSize = new System.Drawing.Size(1, 1);
            this.textNumberOfTenants.Modified = false;
            this.textNumberOfTenants.Multiline = false;
            this.textNumberOfTenants.Name = "textNumberOfTenants";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textNumberOfTenants.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textNumberOfTenants.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textNumberOfTenants.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textNumberOfTenants.OnIdleState = stateProperties20;
            this.textNumberOfTenants.Padding = new System.Windows.Forms.Padding(3);
            this.textNumberOfTenants.PasswordChar = '\0';
            this.textNumberOfTenants.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textNumberOfTenants.PlaceholderText = "Number OF Tenants";
            this.textNumberOfTenants.ReadOnly = true;
            this.textNumberOfTenants.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textNumberOfTenants.SelectedText = "";
            this.textNumberOfTenants.SelectionLength = 0;
            this.textNumberOfTenants.SelectionStart = 0;
            this.textNumberOfTenants.ShortcutsEnabled = true;
            this.textNumberOfTenants.Size = new System.Drawing.Size(186, 39);
            this.textNumberOfTenants.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textNumberOfTenants.TabIndex = 10;
            this.textNumberOfTenants.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textNumberOfTenants.TextMarginBottom = 0;
            this.textNumberOfTenants.TextMarginLeft = 3;
            this.textNumberOfTenants.TextMarginTop = 1;
            this.textNumberOfTenants.TextPlaceholder = "Number OF Tenants";
            this.textNumberOfTenants.UseSystemPasswordChar = false;
            this.textNumberOfTenants.WordWrap = true;
            // 
            // TextNumberOFUnits
            // 
            this.TextNumberOFUnits.AcceptsReturn = false;
            this.TextNumberOFUnits.AcceptsTab = false;
            this.TextNumberOFUnits.AnimationSpeed = 200;
            this.TextNumberOFUnits.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextNumberOFUnits.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextNumberOFUnits.AutoSizeHeight = true;
            this.TextNumberOFUnits.BackColor = System.Drawing.Color.Transparent;
            this.TextNumberOFUnits.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextNumberOFUnits.BackgroundImage")));
            this.TextNumberOFUnits.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.TextNumberOFUnits.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.TextNumberOFUnits.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.TextNumberOFUnits.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextNumberOFUnits.BorderRadius = 23;
            this.TextNumberOFUnits.BorderThickness = 1;
            this.TextNumberOFUnits.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextNumberOFUnits.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextNumberOFUnits.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.TextNumberOFUnits.DefaultText = "";
            this.TextNumberOFUnits.FillColor = System.Drawing.Color.White;
            this.TextNumberOFUnits.HideSelection = true;
            this.TextNumberOFUnits.IconLeft = null;
            this.TextNumberOFUnits.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextNumberOFUnits.IconPadding = 10;
            this.TextNumberOFUnits.IconRight = null;
            this.TextNumberOFUnits.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextNumberOFUnits.Lines = new string[0];
            this.TextNumberOFUnits.Location = new System.Drawing.Point(16, 93);
            this.TextNumberOFUnits.MaxLength = 32767;
            this.TextNumberOFUnits.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextNumberOFUnits.Modified = false;
            this.TextNumberOFUnits.Multiline = false;
            this.TextNumberOFUnits.Name = "TextNumberOFUnits";
            stateProperties21.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextNumberOFUnits.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.TextNumberOFUnits.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextNumberOFUnits.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextNumberOFUnits.OnIdleState = stateProperties24;
            this.TextNumberOFUnits.Padding = new System.Windows.Forms.Padding(3);
            this.TextNumberOFUnits.PasswordChar = '\0';
            this.TextNumberOFUnits.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextNumberOFUnits.PlaceholderText = "TextNumberOfUnits";
            this.TextNumberOFUnits.ReadOnly = true;
            this.TextNumberOFUnits.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextNumberOFUnits.SelectedText = "";
            this.TextNumberOFUnits.SelectionLength = 0;
            this.TextNumberOFUnits.SelectionStart = 0;
            this.TextNumberOFUnits.ShortcutsEnabled = true;
            this.TextNumberOFUnits.Size = new System.Drawing.Size(186, 39);
            this.TextNumberOFUnits.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.TextNumberOFUnits.TabIndex = 9;
            this.TextNumberOFUnits.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextNumberOFUnits.TextMarginBottom = 0;
            this.TextNumberOFUnits.TextMarginLeft = 3;
            this.TextNumberOFUnits.TextMarginTop = 1;
            this.TextNumberOFUnits.TextPlaceholder = "TextNumberOfUnits";
            this.TextNumberOFUnits.UseSystemPasswordChar = false;
            this.TextNumberOFUnits.WordWrap = true;
            // 
            // textName
            // 
            this.textName.AcceptsReturn = false;
            this.textName.AcceptsTab = false;
            this.textName.AnimationSpeed = 200;
            this.textName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textName.AutoSizeHeight = true;
            this.textName.BackColor = System.Drawing.Color.Transparent;
            this.textName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textName.BackgroundImage")));
            this.textName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textName.BorderColorIdle = System.Drawing.Color.Silver;
            this.textName.BorderRadius = 23;
            this.textName.BorderThickness = 1;
            this.textName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textName.DefaultText = "";
            this.textName.FillColor = System.Drawing.Color.White;
            this.textName.HideSelection = true;
            this.textName.IconLeft = null;
            this.textName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textName.IconPadding = 10;
            this.textName.IconRight = null;
            this.textName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textName.Lines = new string[0];
            this.textName.Location = new System.Drawing.Point(17, 36);
            this.textName.MaxLength = 32767;
            this.textName.MinimumSize = new System.Drawing.Size(1, 1);
            this.textName.Modified = false;
            this.textName.Multiline = false;
            this.textName.Name = "textName";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textName.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textName.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textName.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textName.OnIdleState = stateProperties28;
            this.textName.Padding = new System.Windows.Forms.Padding(3);
            this.textName.PasswordChar = '\0';
            this.textName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textName.PlaceholderText = "Propert yName";
            this.textName.ReadOnly = true;
            this.textName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textName.SelectedText = "";
            this.textName.SelectionLength = 0;
            this.textName.SelectionStart = 0;
            this.textName.ShortcutsEnabled = true;
            this.textName.Size = new System.Drawing.Size(186, 39);
            this.textName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textName.TabIndex = 8;
            this.textName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textName.TextMarginBottom = 0;
            this.textName.TextMarginLeft = 3;
            this.textName.TextMarginTop = 1;
            this.textName.TextPlaceholder = "Propert yName";
            this.textName.UseSystemPasswordChar = false;
            this.textName.WordWrap = true;
            // 
            // bunifuIconButton2
            // 
            this.bunifuIconButton2.AllowAnimations = true;
            this.bunifuIconButton2.AllowBorderColorChanges = true;
            this.bunifuIconButton2.AllowMouseEffects = true;
            this.bunifuIconButton2.AnimationSpeed = 200;
            this.bunifuIconButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton2.BackgroundColor = System.Drawing.Color.Crimson;
            this.bunifuIconButton2.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuIconButton2.BorderRadius = 1;
            this.bunifuIconButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton2.BorderThickness = 1;
            this.bunifuIconButton2.ColorContrastOnClick = 30;
            this.bunifuIconButton2.ColorContrastOnHover = 30;
            this.bunifuIconButton2.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.bunifuIconButton2.CustomizableEdges = borderEdges2;
            this.bunifuIconButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuIconButton2.Image")));
            this.bunifuIconButton2.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton2.Location = new System.Drawing.Point(166, 216);
            this.bunifuIconButton2.Name = "bunifuIconButton2";
            this.bunifuIconButton2.RoundBorders = true;
            this.bunifuIconButton2.ShowBorders = true;
            this.bunifuIconButton2.Size = new System.Drawing.Size(60, 60);
            this.bunifuIconButton2.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton2.TabIndex = 6;
            // 
            // bunifuIconButton3
            // 
            this.bunifuIconButton3.AllowAnimations = true;
            this.bunifuIconButton3.AllowBorderColorChanges = true;
            this.bunifuIconButton3.AllowMouseEffects = true;
            this.bunifuIconButton3.AnimationSpeed = 200;
            this.bunifuIconButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton3.BackgroundColor = System.Drawing.Color.SteelBlue;
            this.bunifuIconButton3.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuIconButton3.BorderRadius = 1;
            this.bunifuIconButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton3.BorderThickness = 1;
            this.bunifuIconButton3.ColorContrastOnClick = 30;
            this.bunifuIconButton3.ColorContrastOnHover = 30;
            this.bunifuIconButton3.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.bunifuIconButton3.CustomizableEdges = borderEdges3;
            this.bunifuIconButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuIconButton3.Image")));
            this.bunifuIconButton3.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton3.Location = new System.Drawing.Point(32, 214);
            this.bunifuIconButton3.Name = "bunifuIconButton3";
            this.bunifuIconButton3.RoundBorders = true;
            this.bunifuIconButton3.ShowBorders = true;
            this.bunifuIconButton3.Size = new System.Drawing.Size(60, 60);
            this.bunifuIconButton3.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton3.TabIndex = 7;
            // 
            // dataGridViewProperties
            // 
            this.dataGridViewProperties.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewProperties.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewProperties.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProperties.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewProperties.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridViewProperties.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewProperties.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewProperties.ColumnHeadersHeight = 40;
            this.dataGridViewProperties.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dataGridViewProperties.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewProperties.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewProperties.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dataGridViewProperties.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewProperties.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dataGridViewProperties.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dataGridViewProperties.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dataGridViewProperties.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewProperties.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridViewProperties.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dataGridViewProperties.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridViewProperties.CurrentTheme.Name = null;
            this.dataGridViewProperties.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dataGridViewProperties.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewProperties.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewProperties.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dataGridViewProperties.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewProperties.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewProperties.EnableHeadersVisualStyles = false;
            this.dataGridViewProperties.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dataGridViewProperties.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dataGridViewProperties.HeaderBgColor = System.Drawing.Color.Empty;
            this.dataGridViewProperties.HeaderForeColor = System.Drawing.Color.White;
            this.dataGridViewProperties.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewProperties.Name = "dataGridViewProperties";
            this.dataGridViewProperties.RowHeadersVisible = false;
            this.dataGridViewProperties.RowTemplate.Height = 40;
            this.dataGridViewProperties.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProperties.Size = new System.Drawing.Size(889, 726);
            this.dataGridViewProperties.TabIndex = 1;
            this.dataGridViewProperties.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dataGridViewProperties.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProperties_CellContentClick);
            // 
            // propertyModelBindingSource
            // 
            // 
            // FormProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1269, 741);
            this.Controls.Add(this.bunifuPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormProperty";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormProperty_Load);
            this.bunifuPanel1.ResumeLayout(false);
            this.bunifuPanel3.ResumeLayout(false);
            this.bunifuPanel3.PerformLayout();
            this.bunifuPanel2.ResumeLayout(false);
            this.bunifuPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.propertyModelBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel1;
        private Bunifu.UI.WinForms.BunifuDataGridView dataGridViewProperties;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel3;
        private Bunifu.UI.WinForms.BunifuTextBox textBoxName;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel2;
        private Bunifu.UI.WinForms.BunifuTextBox textBoxlandLord;
        private Bunifu.UI.WinForms.BunifuTextBox textBoxCounty;
        private Bunifu.UI.WinForms.BunifuTextBox textBoxAddress;
        private System.Windows.Forms.BindingSource propertyModelBindingSource;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton3;
        private Bunifu.UI.WinForms.BunifuTextBox textNumberOfTenants;
        private Bunifu.UI.WinForms.BunifuTextBox TextNumberOFUnits;
        private Bunifu.UI.WinForms.BunifuTextBox textName;
    }
}

