﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class MaintenanceView : Form
    {
        public MaintenanceView()
        {
            InitializeComponent();
        }

        static MaintenanceView newMaintenanceView;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newMaintenanceView = new MaintenanceView();
            newMaintenanceView.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newMaintenanceView = new MaintenanceView();
            newMaintenanceView.ShowDialog();
            return buttin_id;

        }
    }
}
