﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Security.Policy;
using RentApp.Model;

namespace RentApp
{
    public partial class AddUnits : Form
    {
        public AddUnits()
        {
            InitializeComponent();
        }


        HttpClient client = new HttpClient();

        static AddUnits newAddProperty;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newAddProperty = new AddUnits();
            newAddProperty.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newAddProperty = new AddUnits();
            newAddProperty.ShowDialog();
            return buttin_id;

        }

        private async void bunifuButton21_Click(object sender, EventArgs e)
        {
            try
            {

            var url = "http://165.232.121.9/properties/create_units/";
            var unit = new unitModel()
                {
                    name = textboxunit.Text,
                    property = int.Parse(textboxProperty.Text),
                    deposit = textboxdeposit.Text,
                    rent = textboxrent.Text,
                    house_type = textboxhousetype.Text,
                    no_of_bedrooms = int.Parse(textboxBedrooms.Text),
                    no_of_bathrooms = int.Parse(textboxbathrooms.Text),
                    balcon = textboxbalcon.Text,
                    floor = textboxfloor.Text,
                    square_foot = textboxSquareFoot.Text,
                };

                var json = JsonConvert.SerializeObject(unit);
                var data = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url, data);

                if (response.IsSuccessStatusCode)
                {
                    textboxunit.Clear();
                    textboxProperty.Clear();
                    textboxdeposit.Clear();
                    textboxrent.Clear();
                    textboxhousetype.Clear();
                    textboxBedrooms.Clear();
                    textboxbathrooms.Clear();
                    textboxbalcon.Clear();
                    textboxfloor.Clear();
                    textboxSquareFoot.Clear();

                    RentApp app = new RentApp();
                    app.loadData();
                }
                else
                {
                    MessageBox.Show("Something went wrong");
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void AddUnits_Load(object sender, EventArgs e)
        {
            textboxProperty.Text = RentApp.propertyId;
        }
    }
}
