﻿namespace RentApp
{
    partial class RentApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentApp));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges15 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges16 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges17 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges18 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges19 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges20 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges23 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges24 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges25 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges26 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges27 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation1 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges28 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges29 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges30 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges31 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges32 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges35 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges36 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges37 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges38 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges39 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges40 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges34 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges33 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            this.bunifuPanel5 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuButton223 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton220 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton221 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton222 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton224 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuPanel4 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuButton215 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton27 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton28 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton213 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton214 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuPanel3 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuButton230 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton229 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton212 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton29 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton210 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuButton4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuSeparator1 = new Bunifu.UI.WinForms.BunifuSeparator();
            this.buttonProperties = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pnlMenu = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuPanel2 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuButton6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuColorTransition1 = new Bunifu.UI.WinForms.BunifuColorTransition(this.components);
            this.bunifuButton22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton23 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton24 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton26 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuPanel1 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuPanel6 = new Bunifu.UI.WinForms.BunifuPanel();
            this.bunifuPages1 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.PageView = new System.Windows.Forms.TabPage();
            this.bunifuButton216 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.datagridViewTenants = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.first_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.second_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kra_pin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phone_number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listProperty = new System.Windows.Forms.TabPage();
            this.bunifuButton211 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton217 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.datagridViewOccupiedUnits = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.name_property = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.county = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.first_name_property = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maintenance = new System.Windows.Forms.TabPage();
            this.bunifuButton218 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.datagridViewMaintenance = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.maint_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.payments = new System.Windows.Forms.TabPage();
            this.bunifuButton25 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.datagridViewTransactions = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.mpesa_code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.current_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.current_time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PeriodicReports = new System.Windows.Forms.TabPage();
            this.showlords = new System.Windows.Forms.TabPage();
            this.zones = new System.Windows.Forms.TabPage();
            this.bunifuIconButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.zoneDataGridView = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuLabel9 = new Bunifu.UI.WinForms.BunifuLabel();
            this.complete = new System.Windows.Forms.TabPage();
            this.bunifuButton225 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel10 = new Bunifu.UI.WinForms.BunifuLabel();
            this.datagridViewComplete = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.name_complete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.description_complete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status_complete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount_complete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.incomplete = new System.Windows.Forms.TabPage();
            this.bunifuButton226 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel11 = new Bunifu.UI.WinForms.BunifuLabel();
            this.datagridViewIncomplete = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.name_incomplete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.description_incomplete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status_incomplete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount_incomplete = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.occupied = new System.Windows.Forms.TabPage();
            this.bunifuButton227 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuDataGridView1 = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.name_occupied = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deposit_occ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rent_occ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hse_type_occ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.no_of_bed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.notOccupied = new System.Windows.Forms.TabPage();
            this.datagridViewNotOccupiedUnits = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.unita_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.property_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_deposit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_rent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_house_type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_no_of_bedrooms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_no_of_bathrooms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_tenants_count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.units_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuButton219 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton228 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.VacancyPosition = new System.Windows.Forms.TabPage();
            this.bunifuLabel12 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuDataGridView2 = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.name_pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address_pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rent_pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.house_type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.bunifuLabel13 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuDataGridView3 = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.name_ms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apart_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phne_number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email_ms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.messages_ms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amenity = new System.Windows.Forms.TabPage();
            this.bunifuDataGridView4 = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.utilities = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.security = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.garbage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuLabel14 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuIconButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuIconButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.unitModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.unitModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.propertyModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bunifuPanel5.SuspendLayout();
            this.bunifuPanel4.SuspendLayout();
            this.bunifuPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlMenu.SuspendLayout();
            this.bunifuPanel2.SuspendLayout();
            this.bunifuPanel1.SuspendLayout();
            this.bunifuPanel6.SuspendLayout();
            this.bunifuPages1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.PageView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewTenants)).BeginInit();
            this.listProperty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewOccupiedUnits)).BeginInit();
            this.maintenance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewMaintenance)).BeginInit();
            this.payments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewTransactions)).BeginInit();
            this.zones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zoneDataGridView)).BeginInit();
            this.complete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewComplete)).BeginInit();
            this.incomplete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewIncomplete)).BeginInit();
            this.occupied.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView1)).BeginInit();
            this.notOccupied.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewNotOccupiedUnits)).BeginInit();
            this.VacancyPosition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView2)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView3)).BeginInit();
            this.amenity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitModelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.propertyModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuPanel5
            // 
            this.bunifuPanel5.BackgroundColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel5.BackgroundImage")));
            this.bunifuPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel5.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel5.BorderRadius = 3;
            this.bunifuPanel5.BorderThickness = 0;
            this.bunifuPanel5.Controls.Add(this.bunifuButton223);
            this.bunifuPanel5.Controls.Add(this.bunifuButton220);
            this.bunifuPanel5.Controls.Add(this.bunifuButton221);
            this.bunifuPanel5.Controls.Add(this.bunifuButton222);
            this.bunifuPanel5.Controls.Add(this.bunifuButton224);
            this.bunifuPanel5.Location = new System.Drawing.Point(294, 11);
            this.bunifuPanel5.Name = "bunifuPanel5";
            this.bunifuPanel5.ShowBorders = true;
            this.bunifuPanel5.Size = new System.Drawing.Size(255, 243);
            this.bunifuPanel5.TabIndex = 6;
            // 
            // bunifuButton223
            // 
            this.bunifuButton223.AllowAnimations = true;
            this.bunifuButton223.AllowMouseEffects = true;
            this.bunifuButton223.AllowToggling = false;
            this.bunifuButton223.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton223.AnimationSpeed = 200;
            this.bunifuButton223.AutoGenerateColors = false;
            this.bunifuButton223.AutoRoundBorders = false;
            this.bunifuButton223.AutoSizeLeftIcon = true;
            this.bunifuButton223.AutoSizeRightIcon = true;
            this.bunifuButton223.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton223.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton223.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton223.BackgroundImage")));
            this.bunifuButton223.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton223.ButtonText = "List (Property)";
            this.bunifuButton223.ButtonTextMarginLeft = 0;
            this.bunifuButton223.ColorContrastOnClick = 45;
            this.bunifuButton223.ColorContrastOnHover = 45;
            this.bunifuButton223.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton223.CustomizableEdges = borderEdges1;
            this.bunifuButton223.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton223.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton223.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton223.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton223.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton223.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton223.ForeColor = System.Drawing.Color.White;
            this.bunifuButton223.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton223.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton223.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton223.IconMarginLeft = 11;
            this.bunifuButton223.IconPadding = 10;
            this.bunifuButton223.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton223.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton223.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton223.IconSize = 25;
            this.bunifuButton223.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton223.IdleBorderRadius = 1;
            this.bunifuButton223.IdleBorderThickness = 1;
            this.bunifuButton223.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton223.IdleIconLeftImage = null;
            this.bunifuButton223.IdleIconRightImage = null;
            this.bunifuButton223.IndicateFocus = false;
            this.bunifuButton223.Location = new System.Drawing.Point(6, 48);
            this.bunifuButton223.Name = "bunifuButton223";
            this.bunifuButton223.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton223.OnDisabledState.BorderRadius = 1;
            this.bunifuButton223.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton223.OnDisabledState.BorderThickness = 1;
            this.bunifuButton223.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton223.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton223.OnDisabledState.IconLeftImage = null;
            this.bunifuButton223.OnDisabledState.IconRightImage = null;
            this.bunifuButton223.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton223.onHoverState.BorderRadius = 1;
            this.bunifuButton223.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton223.onHoverState.BorderThickness = 1;
            this.bunifuButton223.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton223.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton223.onHoverState.IconLeftImage = null;
            this.bunifuButton223.onHoverState.IconRightImage = null;
            this.bunifuButton223.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton223.OnIdleState.BorderRadius = 1;
            this.bunifuButton223.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton223.OnIdleState.BorderThickness = 1;
            this.bunifuButton223.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton223.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton223.OnIdleState.IconLeftImage = null;
            this.bunifuButton223.OnIdleState.IconRightImage = null;
            this.bunifuButton223.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton223.OnPressedState.BorderRadius = 1;
            this.bunifuButton223.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton223.OnPressedState.BorderThickness = 1;
            this.bunifuButton223.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton223.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton223.OnPressedState.IconLeftImage = null;
            this.bunifuButton223.OnPressedState.IconRightImage = null;
            this.bunifuButton223.Size = new System.Drawing.Size(252, 45);
            this.bunifuButton223.TabIndex = 1;
            this.bunifuButton223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton223.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton223.TextMarginLeft = 0;
            this.bunifuButton223.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton223.UseDefaultRadiusAndThickness = true;
            this.bunifuButton223.Click += new System.EventHandler(this.bunifuButton223_Click);
            // 
            // bunifuButton220
            // 
            this.bunifuButton220.AllowAnimations = true;
            this.bunifuButton220.AllowMouseEffects = true;
            this.bunifuButton220.AllowToggling = false;
            this.bunifuButton220.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton220.AnimationSpeed = 200;
            this.bunifuButton220.AutoGenerateColors = false;
            this.bunifuButton220.AutoRoundBorders = false;
            this.bunifuButton220.AutoSizeLeftIcon = true;
            this.bunifuButton220.AutoSizeRightIcon = true;
            this.bunifuButton220.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton220.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton220.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton220.BackgroundImage")));
            this.bunifuButton220.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton220.ButtonText = "Add/Edit (Status)";
            this.bunifuButton220.ButtonTextMarginLeft = 0;
            this.bunifuButton220.ColorContrastOnClick = 45;
            this.bunifuButton220.ColorContrastOnHover = 45;
            this.bunifuButton220.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.bunifuButton220.CustomizableEdges = borderEdges2;
            this.bunifuButton220.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton220.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton220.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton220.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton220.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton220.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton220.ForeColor = System.Drawing.Color.White;
            this.bunifuButton220.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton220.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton220.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton220.IconMarginLeft = 11;
            this.bunifuButton220.IconPadding = 10;
            this.bunifuButton220.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton220.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton220.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton220.IconSize = 25;
            this.bunifuButton220.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton220.IdleBorderRadius = 1;
            this.bunifuButton220.IdleBorderThickness = 1;
            this.bunifuButton220.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton220.IdleIconLeftImage = null;
            this.bunifuButton220.IdleIconRightImage = null;
            this.bunifuButton220.IndicateFocus = false;
            this.bunifuButton220.Location = new System.Drawing.Point(3, 194);
            this.bunifuButton220.Name = "bunifuButton220";
            this.bunifuButton220.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton220.OnDisabledState.BorderRadius = 1;
            this.bunifuButton220.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton220.OnDisabledState.BorderThickness = 1;
            this.bunifuButton220.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton220.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton220.OnDisabledState.IconLeftImage = null;
            this.bunifuButton220.OnDisabledState.IconRightImage = null;
            this.bunifuButton220.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton220.onHoverState.BorderRadius = 1;
            this.bunifuButton220.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton220.onHoverState.BorderThickness = 1;
            this.bunifuButton220.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton220.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton220.onHoverState.IconLeftImage = null;
            this.bunifuButton220.onHoverState.IconRightImage = null;
            this.bunifuButton220.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton220.OnIdleState.BorderRadius = 1;
            this.bunifuButton220.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton220.OnIdleState.BorderThickness = 1;
            this.bunifuButton220.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton220.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton220.OnIdleState.IconLeftImage = null;
            this.bunifuButton220.OnIdleState.IconRightImage = null;
            this.bunifuButton220.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton220.OnPressedState.BorderRadius = 1;
            this.bunifuButton220.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton220.OnPressedState.BorderThickness = 1;
            this.bunifuButton220.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton220.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton220.OnPressedState.IconLeftImage = null;
            this.bunifuButton220.OnPressedState.IconRightImage = null;
            this.bunifuButton220.Size = new System.Drawing.Size(252, 45);
            this.bunifuButton220.TabIndex = 4;
            this.bunifuButton220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton220.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton220.TextMarginLeft = 0;
            this.bunifuButton220.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton220.UseDefaultRadiusAndThickness = true;
            this.bunifuButton220.Click += new System.EventHandler(this.bunifuButton220_Click);
            // 
            // bunifuButton221
            // 
            this.bunifuButton221.AllowAnimations = true;
            this.bunifuButton221.AllowMouseEffects = true;
            this.bunifuButton221.AllowToggling = false;
            this.bunifuButton221.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton221.AnimationSpeed = 200;
            this.bunifuButton221.AutoGenerateColors = false;
            this.bunifuButton221.AutoRoundBorders = false;
            this.bunifuButton221.AutoSizeLeftIcon = true;
            this.bunifuButton221.AutoSizeRightIcon = true;
            this.bunifuButton221.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton221.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton221.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton221.BackgroundImage")));
            this.bunifuButton221.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton221.ButtonText = "Not Occupied";
            this.bunifuButton221.ButtonTextMarginLeft = 0;
            this.bunifuButton221.ColorContrastOnClick = 45;
            this.bunifuButton221.ColorContrastOnHover = 45;
            this.bunifuButton221.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.bunifuButton221.CustomizableEdges = borderEdges3;
            this.bunifuButton221.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton221.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton221.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton221.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton221.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton221.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton221.ForeColor = System.Drawing.Color.White;
            this.bunifuButton221.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton221.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton221.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton221.IconMarginLeft = 11;
            this.bunifuButton221.IconPadding = 10;
            this.bunifuButton221.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton221.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton221.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton221.IconSize = 25;
            this.bunifuButton221.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton221.IdleBorderRadius = 1;
            this.bunifuButton221.IdleBorderThickness = 1;
            this.bunifuButton221.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton221.IdleIconLeftImage = null;
            this.bunifuButton221.IdleIconRightImage = null;
            this.bunifuButton221.IndicateFocus = false;
            this.bunifuButton221.Location = new System.Drawing.Point(5, 146);
            this.bunifuButton221.Name = "bunifuButton221";
            this.bunifuButton221.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton221.OnDisabledState.BorderRadius = 1;
            this.bunifuButton221.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton221.OnDisabledState.BorderThickness = 1;
            this.bunifuButton221.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton221.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton221.OnDisabledState.IconLeftImage = null;
            this.bunifuButton221.OnDisabledState.IconRightImage = null;
            this.bunifuButton221.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton221.onHoverState.BorderRadius = 1;
            this.bunifuButton221.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton221.onHoverState.BorderThickness = 1;
            this.bunifuButton221.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton221.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton221.onHoverState.IconLeftImage = null;
            this.bunifuButton221.onHoverState.IconRightImage = null;
            this.bunifuButton221.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton221.OnIdleState.BorderRadius = 1;
            this.bunifuButton221.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton221.OnIdleState.BorderThickness = 1;
            this.bunifuButton221.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton221.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton221.OnIdleState.IconLeftImage = null;
            this.bunifuButton221.OnIdleState.IconRightImage = null;
            this.bunifuButton221.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton221.OnPressedState.BorderRadius = 1;
            this.bunifuButton221.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton221.OnPressedState.BorderThickness = 1;
            this.bunifuButton221.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton221.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton221.OnPressedState.IconLeftImage = null;
            this.bunifuButton221.OnPressedState.IconRightImage = null;
            this.bunifuButton221.Size = new System.Drawing.Size(252, 45);
            this.bunifuButton221.TabIndex = 3;
            this.bunifuButton221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton221.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton221.TextMarginLeft = 0;
            this.bunifuButton221.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton221.UseDefaultRadiusAndThickness = true;
            this.bunifuButton221.Click += new System.EventHandler(this.bunifuButton221_Click);
            // 
            // bunifuButton222
            // 
            this.bunifuButton222.AllowAnimations = true;
            this.bunifuButton222.AllowMouseEffects = true;
            this.bunifuButton222.AllowToggling = false;
            this.bunifuButton222.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton222.AnimationSpeed = 200;
            this.bunifuButton222.AutoGenerateColors = false;
            this.bunifuButton222.AutoRoundBorders = false;
            this.bunifuButton222.AutoSizeLeftIcon = true;
            this.bunifuButton222.AutoSizeRightIcon = true;
            this.bunifuButton222.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton222.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton222.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton222.BackgroundImage")));
            this.bunifuButton222.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton222.ButtonText = "Occupied Units";
            this.bunifuButton222.ButtonTextMarginLeft = 0;
            this.bunifuButton222.ColorContrastOnClick = 45;
            this.bunifuButton222.ColorContrastOnHover = 45;
            this.bunifuButton222.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.bunifuButton222.CustomizableEdges = borderEdges4;
            this.bunifuButton222.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton222.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton222.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton222.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton222.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton222.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton222.ForeColor = System.Drawing.Color.White;
            this.bunifuButton222.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton222.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton222.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton222.IconMarginLeft = 11;
            this.bunifuButton222.IconPadding = 10;
            this.bunifuButton222.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton222.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton222.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton222.IconSize = 25;
            this.bunifuButton222.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton222.IdleBorderRadius = 1;
            this.bunifuButton222.IdleBorderThickness = 1;
            this.bunifuButton222.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton222.IdleIconLeftImage = null;
            this.bunifuButton222.IdleIconRightImage = null;
            this.bunifuButton222.IndicateFocus = false;
            this.bunifuButton222.Location = new System.Drawing.Point(6, 97);
            this.bunifuButton222.Name = "bunifuButton222";
            this.bunifuButton222.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton222.OnDisabledState.BorderRadius = 1;
            this.bunifuButton222.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton222.OnDisabledState.BorderThickness = 1;
            this.bunifuButton222.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton222.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton222.OnDisabledState.IconLeftImage = null;
            this.bunifuButton222.OnDisabledState.IconRightImage = null;
            this.bunifuButton222.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton222.onHoverState.BorderRadius = 1;
            this.bunifuButton222.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton222.onHoverState.BorderThickness = 1;
            this.bunifuButton222.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton222.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton222.onHoverState.IconLeftImage = null;
            this.bunifuButton222.onHoverState.IconRightImage = null;
            this.bunifuButton222.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton222.OnIdleState.BorderRadius = 1;
            this.bunifuButton222.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton222.OnIdleState.BorderThickness = 1;
            this.bunifuButton222.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton222.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton222.OnIdleState.IconLeftImage = null;
            this.bunifuButton222.OnIdleState.IconRightImage = null;
            this.bunifuButton222.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton222.OnPressedState.BorderRadius = 1;
            this.bunifuButton222.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton222.OnPressedState.BorderThickness = 1;
            this.bunifuButton222.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton222.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton222.OnPressedState.IconLeftImage = null;
            this.bunifuButton222.OnPressedState.IconRightImage = null;
            this.bunifuButton222.Size = new System.Drawing.Size(252, 45);
            this.bunifuButton222.TabIndex = 2;
            this.bunifuButton222.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton222.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton222.TextMarginLeft = 0;
            this.bunifuButton222.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton222.UseDefaultRadiusAndThickness = true;
            this.bunifuButton222.Click += new System.EventHandler(this.bunifuButton222_Click);
            // 
            // bunifuButton224
            // 
            this.bunifuButton224.AllowAnimations = true;
            this.bunifuButton224.AllowMouseEffects = true;
            this.bunifuButton224.AllowToggling = false;
            this.bunifuButton224.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton224.AnimationSpeed = 200;
            this.bunifuButton224.AutoGenerateColors = false;
            this.bunifuButton224.AutoRoundBorders = false;
            this.bunifuButton224.AutoSizeLeftIcon = true;
            this.bunifuButton224.AutoSizeRightIcon = true;
            this.bunifuButton224.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton224.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton224.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton224.BackgroundImage")));
            this.bunifuButton224.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton224.ButtonText = "Property";
            this.bunifuButton224.ButtonTextMarginLeft = 0;
            this.bunifuButton224.ColorContrastOnClick = 45;
            this.bunifuButton224.ColorContrastOnHover = 45;
            this.bunifuButton224.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.bunifuButton224.CustomizableEdges = borderEdges5;
            this.bunifuButton224.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton224.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton224.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton224.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton224.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton224.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.bunifuButton224.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuButton224.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton224.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton224.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton224.IconMarginLeft = 11;
            this.bunifuButton224.IconPadding = 10;
            this.bunifuButton224.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton224.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton224.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton224.IconSize = 25;
            this.bunifuButton224.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton224.IdleBorderRadius = 1;
            this.bunifuButton224.IdleBorderThickness = 1;
            this.bunifuButton224.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton224.IdleIconLeftImage = null;
            this.bunifuButton224.IdleIconRightImage = null;
            this.bunifuButton224.IndicateFocus = false;
            this.bunifuButton224.Location = new System.Drawing.Point(6, 0);
            this.bunifuButton224.Name = "bunifuButton224";
            this.bunifuButton224.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton224.OnDisabledState.BorderRadius = 1;
            this.bunifuButton224.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton224.OnDisabledState.BorderThickness = 1;
            this.bunifuButton224.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton224.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton224.OnDisabledState.IconLeftImage = null;
            this.bunifuButton224.OnDisabledState.IconRightImage = null;
            this.bunifuButton224.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton224.onHoverState.BorderRadius = 1;
            this.bunifuButton224.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton224.onHoverState.BorderThickness = 1;
            this.bunifuButton224.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton224.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton224.onHoverState.IconLeftImage = null;
            this.bunifuButton224.onHoverState.IconRightImage = null;
            this.bunifuButton224.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton224.OnIdleState.BorderRadius = 1;
            this.bunifuButton224.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton224.OnIdleState.BorderThickness = 1;
            this.bunifuButton224.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton224.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuButton224.OnIdleState.IconLeftImage = null;
            this.bunifuButton224.OnIdleState.IconRightImage = null;
            this.bunifuButton224.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton224.OnPressedState.BorderRadius = 1;
            this.bunifuButton224.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton224.OnPressedState.BorderThickness = 1;
            this.bunifuButton224.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton224.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton224.OnPressedState.IconLeftImage = null;
            this.bunifuButton224.OnPressedState.IconRightImage = null;
            this.bunifuButton224.Size = new System.Drawing.Size(246, 39);
            this.bunifuButton224.TabIndex = 0;
            this.bunifuButton224.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton224.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton224.TextMarginLeft = 0;
            this.bunifuButton224.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton224.UseDefaultRadiusAndThickness = true;
            this.bunifuButton224.Click += new System.EventHandler(this.bunifuButton224_Click);
            // 
            // bunifuPanel4
            // 
            this.bunifuPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuPanel4.BackgroundColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel4.BackgroundImage")));
            this.bunifuPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel4.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel4.BorderRadius = 3;
            this.bunifuPanel4.BorderThickness = 0;
            this.bunifuPanel4.Controls.Add(this.bunifuButton215);
            this.bunifuPanel4.Controls.Add(this.bunifuButton27);
            this.bunifuPanel4.Controls.Add(this.bunifuButton28);
            this.bunifuPanel4.Controls.Add(this.bunifuButton213);
            this.bunifuPanel4.Controls.Add(this.bunifuButton214);
            this.bunifuPanel4.Location = new System.Drawing.Point(870, 14);
            this.bunifuPanel4.Name = "bunifuPanel4";
            this.bunifuPanel4.ShowBorders = true;
            this.bunifuPanel4.Size = new System.Drawing.Size(240, 243);
            this.bunifuPanel4.TabIndex = 8;
            // 
            // bunifuButton215
            // 
            this.bunifuButton215.AllowAnimations = true;
            this.bunifuButton215.AllowMouseEffects = true;
            this.bunifuButton215.AllowToggling = false;
            this.bunifuButton215.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuButton215.AnimationSpeed = 200;
            this.bunifuButton215.AutoGenerateColors = false;
            this.bunifuButton215.AutoRoundBorders = false;
            this.bunifuButton215.AutoSizeLeftIcon = true;
            this.bunifuButton215.AutoSizeRightIcon = true;
            this.bunifuButton215.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton215.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton215.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton215.BackgroundImage")));
            this.bunifuButton215.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton215.ButtonText = "Payments";
            this.bunifuButton215.ButtonTextMarginLeft = 0;
            this.bunifuButton215.ColorContrastOnClick = 45;
            this.bunifuButton215.ColorContrastOnHover = 45;
            this.bunifuButton215.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.bunifuButton215.CustomizableEdges = borderEdges6;
            this.bunifuButton215.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton215.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton215.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton215.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton215.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton215.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton215.ForeColor = System.Drawing.Color.White;
            this.bunifuButton215.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton215.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton215.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton215.IconMarginLeft = 11;
            this.bunifuButton215.IconPadding = 10;
            this.bunifuButton215.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton215.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton215.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton215.IconSize = 25;
            this.bunifuButton215.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton215.IdleBorderRadius = 1;
            this.bunifuButton215.IdleBorderThickness = 1;
            this.bunifuButton215.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton215.IdleIconLeftImage = null;
            this.bunifuButton215.IdleIconRightImage = null;
            this.bunifuButton215.IndicateFocus = false;
            this.bunifuButton215.Location = new System.Drawing.Point(5, 194);
            this.bunifuButton215.Name = "bunifuButton215";
            this.bunifuButton215.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton215.OnDisabledState.BorderRadius = 1;
            this.bunifuButton215.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton215.OnDisabledState.BorderThickness = 1;
            this.bunifuButton215.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton215.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton215.OnDisabledState.IconLeftImage = null;
            this.bunifuButton215.OnDisabledState.IconRightImage = null;
            this.bunifuButton215.onHoverState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton215.onHoverState.BorderRadius = 1;
            this.bunifuButton215.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton215.onHoverState.BorderThickness = 1;
            this.bunifuButton215.onHoverState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton215.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton215.onHoverState.IconLeftImage = null;
            this.bunifuButton215.onHoverState.IconRightImage = null;
            this.bunifuButton215.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton215.OnIdleState.BorderRadius = 1;
            this.bunifuButton215.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton215.OnIdleState.BorderThickness = 1;
            this.bunifuButton215.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton215.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton215.OnIdleState.IconLeftImage = null;
            this.bunifuButton215.OnIdleState.IconRightImage = null;
            this.bunifuButton215.OnPressedState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton215.OnPressedState.BorderRadius = 1;
            this.bunifuButton215.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton215.OnPressedState.BorderThickness = 1;
            this.bunifuButton215.OnPressedState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton215.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton215.OnPressedState.IconLeftImage = null;
            this.bunifuButton215.OnPressedState.IconRightImage = null;
            this.bunifuButton215.Size = new System.Drawing.Size(235, 45);
            this.bunifuButton215.TabIndex = 4;
            this.bunifuButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton215.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton215.TextMarginLeft = 0;
            this.bunifuButton215.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton215.UseDefaultRadiusAndThickness = true;
            this.bunifuButton215.Click += new System.EventHandler(this.bunifuButton215_Click);
            // 
            // bunifuButton27
            // 
            this.bunifuButton27.AllowAnimations = true;
            this.bunifuButton27.AllowMouseEffects = true;
            this.bunifuButton27.AllowToggling = false;
            this.bunifuButton27.AnimationSpeed = 200;
            this.bunifuButton27.AutoGenerateColors = false;
            this.bunifuButton27.AutoRoundBorders = false;
            this.bunifuButton27.AutoSizeLeftIcon = true;
            this.bunifuButton27.AutoSizeRightIcon = true;
            this.bunifuButton27.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton27.BackColor1 = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton27.BackgroundImage")));
            this.bunifuButton27.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton27.ButtonText = "Transaction";
            this.bunifuButton27.ButtonTextMarginLeft = 0;
            this.bunifuButton27.ColorContrastOnClick = 45;
            this.bunifuButton27.ColorContrastOnHover = 45;
            this.bunifuButton27.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges7.BottomLeft = true;
            borderEdges7.BottomRight = true;
            borderEdges7.TopLeft = true;
            borderEdges7.TopRight = true;
            this.bunifuButton27.CustomizableEdges = borderEdges7;
            this.bunifuButton27.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton27.DisabledBorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.DisabledFillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.DisabledForecolor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuButton27.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton27.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.bunifuButton27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuButton27.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton27.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton27.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton27.IconMarginLeft = 11;
            this.bunifuButton27.IconPadding = 10;
            this.bunifuButton27.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton27.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton27.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton27.IconSize = 25;
            this.bunifuButton27.IdleBorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.IdleBorderRadius = 1;
            this.bunifuButton27.IdleBorderThickness = 1;
            this.bunifuButton27.IdleFillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.IdleIconLeftImage = null;
            this.bunifuButton27.IdleIconRightImage = null;
            this.bunifuButton27.IndicateFocus = false;
            this.bunifuButton27.Location = new System.Drawing.Point(0, 0);
            this.bunifuButton27.Name = "bunifuButton27";
            this.bunifuButton27.OnDisabledState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnDisabledState.BorderRadius = 0;
            this.bunifuButton27.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton27.OnDisabledState.BorderThickness = 0;
            this.bunifuButton27.OnDisabledState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnDisabledState.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnDisabledState.IconLeftImage = null;
            this.bunifuButton27.OnDisabledState.IconRightImage = null;
            this.bunifuButton27.onHoverState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.onHoverState.BorderRadius = 0;
            this.bunifuButton27.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton27.onHoverState.BorderThickness = 0;
            this.bunifuButton27.onHoverState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton27.onHoverState.IconLeftImage = null;
            this.bunifuButton27.onHoverState.IconRightImage = null;
            this.bunifuButton27.OnIdleState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnIdleState.BorderRadius = 0;
            this.bunifuButton27.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton27.OnIdleState.BorderThickness = 0;
            this.bunifuButton27.OnIdleState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuButton27.OnIdleState.IconLeftImage = null;
            this.bunifuButton27.OnIdleState.IconRightImage = null;
            this.bunifuButton27.OnPressedState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnPressedState.BorderRadius = 0;
            this.bunifuButton27.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton27.OnPressedState.BorderThickness = 0;
            this.bunifuButton27.OnPressedState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuButton27.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton27.OnPressedState.IconLeftImage = null;
            this.bunifuButton27.OnPressedState.IconRightImage = null;
            this.bunifuButton27.Size = new System.Drawing.Size(240, 36);
            this.bunifuButton27.TabIndex = 0;
            this.bunifuButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton27.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton27.TextMarginLeft = 0;
            this.bunifuButton27.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton27.UseDefaultRadiusAndThickness = true;
            this.bunifuButton27.Click += new System.EventHandler(this.bunifuButton27_Click);
            // 
            // bunifuButton28
            // 
            this.bunifuButton28.AllowAnimations = true;
            this.bunifuButton28.AllowMouseEffects = true;
            this.bunifuButton28.AllowToggling = false;
            this.bunifuButton28.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuButton28.AnimationSpeed = 200;
            this.bunifuButton28.AutoGenerateColors = false;
            this.bunifuButton28.AutoRoundBorders = false;
            this.bunifuButton28.AutoSizeLeftIcon = true;
            this.bunifuButton28.AutoSizeRightIcon = true;
            this.bunifuButton28.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton28.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton28.BackgroundImage")));
            this.bunifuButton28.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton28.ButtonText = "Zones";
            this.bunifuButton28.ButtonTextMarginLeft = 0;
            this.bunifuButton28.ColorContrastOnClick = 45;
            this.bunifuButton28.ColorContrastOnHover = 45;
            this.bunifuButton28.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges8.BottomLeft = true;
            borderEdges8.BottomRight = true;
            borderEdges8.TopLeft = true;
            borderEdges8.TopRight = true;
            this.bunifuButton28.CustomizableEdges = borderEdges8;
            this.bunifuButton28.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton28.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton28.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton28.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton28.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton28.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton28.ForeColor = System.Drawing.Color.White;
            this.bunifuButton28.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton28.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton28.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton28.IconMarginLeft = 11;
            this.bunifuButton28.IconPadding = 10;
            this.bunifuButton28.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton28.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton28.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton28.IconSize = 25;
            this.bunifuButton28.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton28.IdleBorderRadius = 1;
            this.bunifuButton28.IdleBorderThickness = 1;
            this.bunifuButton28.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton28.IdleIconLeftImage = null;
            this.bunifuButton28.IdleIconRightImage = null;
            this.bunifuButton28.IndicateFocus = false;
            this.bunifuButton28.Location = new System.Drawing.Point(3, 145);
            this.bunifuButton28.Name = "bunifuButton28";
            this.bunifuButton28.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton28.OnDisabledState.BorderRadius = 1;
            this.bunifuButton28.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton28.OnDisabledState.BorderThickness = 1;
            this.bunifuButton28.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton28.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton28.OnDisabledState.IconLeftImage = null;
            this.bunifuButton28.OnDisabledState.IconRightImage = null;
            this.bunifuButton28.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton28.onHoverState.BorderRadius = 1;
            this.bunifuButton28.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton28.onHoverState.BorderThickness = 1;
            this.bunifuButton28.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton28.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton28.onHoverState.IconLeftImage = null;
            this.bunifuButton28.onHoverState.IconRightImage = null;
            this.bunifuButton28.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton28.OnIdleState.BorderRadius = 1;
            this.bunifuButton28.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton28.OnIdleState.BorderThickness = 1;
            this.bunifuButton28.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton28.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton28.OnIdleState.IconLeftImage = null;
            this.bunifuButton28.OnIdleState.IconRightImage = null;
            this.bunifuButton28.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton28.OnPressedState.BorderRadius = 1;
            this.bunifuButton28.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton28.OnPressedState.BorderThickness = 1;
            this.bunifuButton28.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton28.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton28.OnPressedState.IconLeftImage = null;
            this.bunifuButton28.OnPressedState.IconRightImage = null;
            this.bunifuButton28.Size = new System.Drawing.Size(237, 45);
            this.bunifuButton28.TabIndex = 3;
            this.bunifuButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton28.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton28.TextMarginLeft = 0;
            this.bunifuButton28.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton28.UseDefaultRadiusAndThickness = true;
            this.bunifuButton28.Click += new System.EventHandler(this.bunifuButton28_Click);
            // 
            // bunifuButton213
            // 
            this.bunifuButton213.AllowAnimations = true;
            this.bunifuButton213.AllowMouseEffects = true;
            this.bunifuButton213.AllowToggling = false;
            this.bunifuButton213.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuButton213.AnimationSpeed = 200;
            this.bunifuButton213.AutoGenerateColors = false;
            this.bunifuButton213.AutoRoundBorders = false;
            this.bunifuButton213.AutoSizeLeftIcon = true;
            this.bunifuButton213.AutoSizeRightIcon = true;
            this.bunifuButton213.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton213.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton213.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton213.BackgroundImage")));
            this.bunifuButton213.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton213.ButtonText = "Amenity Management";
            this.bunifuButton213.ButtonTextMarginLeft = 0;
            this.bunifuButton213.ColorContrastOnClick = 45;
            this.bunifuButton213.ColorContrastOnHover = 45;
            this.bunifuButton213.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges9.BottomLeft = true;
            borderEdges9.BottomRight = true;
            borderEdges9.TopLeft = true;
            borderEdges9.TopRight = true;
            this.bunifuButton213.CustomizableEdges = borderEdges9;
            this.bunifuButton213.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton213.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton213.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton213.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton213.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton213.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton213.ForeColor = System.Drawing.Color.White;
            this.bunifuButton213.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton213.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton213.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton213.IconMarginLeft = 11;
            this.bunifuButton213.IconPadding = 10;
            this.bunifuButton213.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton213.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton213.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton213.IconSize = 25;
            this.bunifuButton213.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton213.IdleBorderRadius = 1;
            this.bunifuButton213.IdleBorderThickness = 1;
            this.bunifuButton213.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton213.IdleIconLeftImage = null;
            this.bunifuButton213.IdleIconRightImage = null;
            this.bunifuButton213.IndicateFocus = false;
            this.bunifuButton213.Location = new System.Drawing.Point(3, 97);
            this.bunifuButton213.Name = "bunifuButton213";
            this.bunifuButton213.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton213.OnDisabledState.BorderRadius = 1;
            this.bunifuButton213.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton213.OnDisabledState.BorderThickness = 1;
            this.bunifuButton213.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton213.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton213.OnDisabledState.IconLeftImage = null;
            this.bunifuButton213.OnDisabledState.IconRightImage = null;
            this.bunifuButton213.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton213.onHoverState.BorderRadius = 1;
            this.bunifuButton213.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton213.onHoverState.BorderThickness = 1;
            this.bunifuButton213.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton213.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton213.onHoverState.IconLeftImage = null;
            this.bunifuButton213.onHoverState.IconRightImage = null;
            this.bunifuButton213.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton213.OnIdleState.BorderRadius = 1;
            this.bunifuButton213.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton213.OnIdleState.BorderThickness = 1;
            this.bunifuButton213.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton213.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton213.OnIdleState.IconLeftImage = null;
            this.bunifuButton213.OnIdleState.IconRightImage = null;
            this.bunifuButton213.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton213.OnPressedState.BorderRadius = 1;
            this.bunifuButton213.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton213.OnPressedState.BorderThickness = 1;
            this.bunifuButton213.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton213.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton213.OnPressedState.IconLeftImage = null;
            this.bunifuButton213.OnPressedState.IconRightImage = null;
            this.bunifuButton213.Size = new System.Drawing.Size(234, 45);
            this.bunifuButton213.TabIndex = 2;
            this.bunifuButton213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton213.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton213.TextMarginLeft = 0;
            this.bunifuButton213.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton213.UseDefaultRadiusAndThickness = true;
            this.bunifuButton213.Click += new System.EventHandler(this.bunifuButton213_Click);
            // 
            // bunifuButton214
            // 
            this.bunifuButton214.AllowAnimations = true;
            this.bunifuButton214.AllowMouseEffects = true;
            this.bunifuButton214.AllowToggling = false;
            this.bunifuButton214.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuButton214.AnimationSpeed = 200;
            this.bunifuButton214.AutoGenerateColors = false;
            this.bunifuButton214.AutoRoundBorders = false;
            this.bunifuButton214.AutoSizeLeftIcon = true;
            this.bunifuButton214.AutoSizeRightIcon = true;
            this.bunifuButton214.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton214.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton214.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton214.BackgroundImage")));
            this.bunifuButton214.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton214.ButtonText = "Live Feeds (mpesa/bank)";
            this.bunifuButton214.ButtonTextMarginLeft = 0;
            this.bunifuButton214.ColorContrastOnClick = 45;
            this.bunifuButton214.ColorContrastOnHover = 45;
            this.bunifuButton214.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.bunifuButton214.CustomizableEdges = borderEdges10;
            this.bunifuButton214.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton214.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton214.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton214.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton214.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton214.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton214.ForeColor = System.Drawing.Color.White;
            this.bunifuButton214.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton214.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton214.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton214.IconMarginLeft = 11;
            this.bunifuButton214.IconPadding = 10;
            this.bunifuButton214.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton214.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton214.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton214.IconSize = 25;
            this.bunifuButton214.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton214.IdleBorderRadius = 1;
            this.bunifuButton214.IdleBorderThickness = 1;
            this.bunifuButton214.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton214.IdleIconLeftImage = null;
            this.bunifuButton214.IdleIconRightImage = null;
            this.bunifuButton214.IndicateFocus = false;
            this.bunifuButton214.Location = new System.Drawing.Point(3, 46);
            this.bunifuButton214.Name = "bunifuButton214";
            this.bunifuButton214.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton214.OnDisabledState.BorderRadius = 1;
            this.bunifuButton214.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton214.OnDisabledState.BorderThickness = 1;
            this.bunifuButton214.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton214.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton214.OnDisabledState.IconLeftImage = null;
            this.bunifuButton214.OnDisabledState.IconRightImage = null;
            this.bunifuButton214.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton214.onHoverState.BorderRadius = 1;
            this.bunifuButton214.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton214.onHoverState.BorderThickness = 1;
            this.bunifuButton214.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton214.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton214.onHoverState.IconLeftImage = null;
            this.bunifuButton214.onHoverState.IconRightImage = null;
            this.bunifuButton214.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton214.OnIdleState.BorderRadius = 1;
            this.bunifuButton214.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton214.OnIdleState.BorderThickness = 1;
            this.bunifuButton214.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton214.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton214.OnIdleState.IconLeftImage = null;
            this.bunifuButton214.OnIdleState.IconRightImage = null;
            this.bunifuButton214.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton214.OnPressedState.BorderRadius = 1;
            this.bunifuButton214.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton214.OnPressedState.BorderThickness = 1;
            this.bunifuButton214.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton214.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton214.OnPressedState.IconLeftImage = null;
            this.bunifuButton214.OnPressedState.IconRightImage = null;
            this.bunifuButton214.Size = new System.Drawing.Size(234, 45);
            this.bunifuButton214.TabIndex = 1;
            this.bunifuButton214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton214.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton214.TextMarginLeft = 0;
            this.bunifuButton214.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton214.UseDefaultRadiusAndThickness = true;
            this.bunifuButton214.Click += new System.EventHandler(this.bunifuButton214_Click);
            // 
            // bunifuPanel3
            // 
            this.bunifuPanel3.BackgroundColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel3.BackgroundImage")));
            this.bunifuPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel3.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel3.BorderRadius = 3;
            this.bunifuPanel3.BorderThickness = 0;
            this.bunifuPanel3.Controls.Add(this.bunifuButton230);
            this.bunifuPanel3.Controls.Add(this.bunifuButton229);
            this.bunifuPanel3.Controls.Add(this.bunifuButton212);
            this.bunifuPanel3.Controls.Add(this.bunifuButton29);
            this.bunifuPanel3.Controls.Add(this.bunifuButton210);
            this.bunifuPanel3.Location = new System.Drawing.Point(609, 11);
            this.bunifuPanel3.Name = "bunifuPanel3";
            this.bunifuPanel3.ShowBorders = true;
            this.bunifuPanel3.Size = new System.Drawing.Size(266, 243);
            this.bunifuPanel3.TabIndex = 7;
            // 
            // bunifuButton230
            // 
            this.bunifuButton230.AllowAnimations = true;
            this.bunifuButton230.AllowMouseEffects = true;
            this.bunifuButton230.AllowToggling = false;
            this.bunifuButton230.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton230.AnimationSpeed = 200;
            this.bunifuButton230.AutoGenerateColors = false;
            this.bunifuButton230.AutoRoundBorders = false;
            this.bunifuButton230.AutoSizeLeftIcon = true;
            this.bunifuButton230.AutoSizeRightIcon = true;
            this.bunifuButton230.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton230.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton230.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton230.BackgroundImage")));
            this.bunifuButton230.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton230.ButtonText = "Incomplete";
            this.bunifuButton230.ButtonTextMarginLeft = 0;
            this.bunifuButton230.ColorContrastOnClick = 45;
            this.bunifuButton230.ColorContrastOnHover = 45;
            this.bunifuButton230.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.bunifuButton230.CustomizableEdges = borderEdges11;
            this.bunifuButton230.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton230.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton230.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton230.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton230.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton230.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton230.ForeColor = System.Drawing.Color.White;
            this.bunifuButton230.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton230.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton230.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton230.IconMarginLeft = 11;
            this.bunifuButton230.IconPadding = 10;
            this.bunifuButton230.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton230.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton230.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton230.IconSize = 25;
            this.bunifuButton230.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton230.IdleBorderRadius = 1;
            this.bunifuButton230.IdleBorderThickness = 1;
            this.bunifuButton230.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton230.IdleIconLeftImage = null;
            this.bunifuButton230.IdleIconRightImage = null;
            this.bunifuButton230.IndicateFocus = false;
            this.bunifuButton230.Location = new System.Drawing.Point(3, 194);
            this.bunifuButton230.Name = "bunifuButton230";
            this.bunifuButton230.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton230.OnDisabledState.BorderRadius = 1;
            this.bunifuButton230.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton230.OnDisabledState.BorderThickness = 1;
            this.bunifuButton230.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton230.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton230.OnDisabledState.IconLeftImage = null;
            this.bunifuButton230.OnDisabledState.IconRightImage = null;
            this.bunifuButton230.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton230.onHoverState.BorderRadius = 1;
            this.bunifuButton230.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton230.onHoverState.BorderThickness = 1;
            this.bunifuButton230.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton230.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton230.onHoverState.IconLeftImage = null;
            this.bunifuButton230.onHoverState.IconRightImage = null;
            this.bunifuButton230.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton230.OnIdleState.BorderRadius = 1;
            this.bunifuButton230.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton230.OnIdleState.BorderThickness = 1;
            this.bunifuButton230.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton230.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton230.OnIdleState.IconLeftImage = null;
            this.bunifuButton230.OnIdleState.IconRightImage = null;
            this.bunifuButton230.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton230.OnPressedState.BorderRadius = 1;
            this.bunifuButton230.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton230.OnPressedState.BorderThickness = 1;
            this.bunifuButton230.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton230.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton230.OnPressedState.IconLeftImage = null;
            this.bunifuButton230.OnPressedState.IconRightImage = null;
            this.bunifuButton230.Size = new System.Drawing.Size(260, 45);
            this.bunifuButton230.TabIndex = 5;
            this.bunifuButton230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton230.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton230.TextMarginLeft = 0;
            this.bunifuButton230.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton230.UseDefaultRadiusAndThickness = true;
            this.bunifuButton230.Click += new System.EventHandler(this.bunifuButton230_Click);
            // 
            // bunifuButton229
            // 
            this.bunifuButton229.AllowAnimations = true;
            this.bunifuButton229.AllowMouseEffects = true;
            this.bunifuButton229.AllowToggling = false;
            this.bunifuButton229.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton229.AnimationSpeed = 200;
            this.bunifuButton229.AutoGenerateColors = false;
            this.bunifuButton229.AutoRoundBorders = false;
            this.bunifuButton229.AutoSizeLeftIcon = true;
            this.bunifuButton229.AutoSizeRightIcon = true;
            this.bunifuButton229.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton229.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton229.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton229.BackgroundImage")));
            this.bunifuButton229.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton229.ButtonText = "Complete";
            this.bunifuButton229.ButtonTextMarginLeft = 0;
            this.bunifuButton229.ColorContrastOnClick = 45;
            this.bunifuButton229.ColorContrastOnHover = 45;
            this.bunifuButton229.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.bunifuButton229.CustomizableEdges = borderEdges12;
            this.bunifuButton229.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton229.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton229.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton229.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton229.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton229.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton229.ForeColor = System.Drawing.Color.White;
            this.bunifuButton229.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton229.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton229.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton229.IconMarginLeft = 11;
            this.bunifuButton229.IconPadding = 10;
            this.bunifuButton229.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton229.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton229.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton229.IconSize = 25;
            this.bunifuButton229.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton229.IdleBorderRadius = 1;
            this.bunifuButton229.IdleBorderThickness = 1;
            this.bunifuButton229.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton229.IdleIconLeftImage = null;
            this.bunifuButton229.IdleIconRightImage = null;
            this.bunifuButton229.IndicateFocus = false;
            this.bunifuButton229.Location = new System.Drawing.Point(3, 146);
            this.bunifuButton229.Name = "bunifuButton229";
            this.bunifuButton229.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton229.OnDisabledState.BorderRadius = 1;
            this.bunifuButton229.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton229.OnDisabledState.BorderThickness = 1;
            this.bunifuButton229.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton229.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton229.OnDisabledState.IconLeftImage = null;
            this.bunifuButton229.OnDisabledState.IconRightImage = null;
            this.bunifuButton229.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton229.onHoverState.BorderRadius = 1;
            this.bunifuButton229.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton229.onHoverState.BorderThickness = 1;
            this.bunifuButton229.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton229.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton229.onHoverState.IconLeftImage = null;
            this.bunifuButton229.onHoverState.IconRightImage = null;
            this.bunifuButton229.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton229.OnIdleState.BorderRadius = 1;
            this.bunifuButton229.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton229.OnIdleState.BorderThickness = 1;
            this.bunifuButton229.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton229.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton229.OnIdleState.IconLeftImage = null;
            this.bunifuButton229.OnIdleState.IconRightImage = null;
            this.bunifuButton229.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton229.OnPressedState.BorderRadius = 1;
            this.bunifuButton229.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton229.OnPressedState.BorderThickness = 1;
            this.bunifuButton229.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton229.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton229.OnPressedState.IconLeftImage = null;
            this.bunifuButton229.OnPressedState.IconRightImage = null;
            this.bunifuButton229.Size = new System.Drawing.Size(262, 45);
            this.bunifuButton229.TabIndex = 4;
            this.bunifuButton229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton229.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton229.TextMarginLeft = 0;
            this.bunifuButton229.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton229.UseDefaultRadiusAndThickness = true;
            this.bunifuButton229.Click += new System.EventHandler(this.bunifuButton229_Click);
            // 
            // bunifuButton212
            // 
            this.bunifuButton212.AllowAnimations = true;
            this.bunifuButton212.AllowMouseEffects = true;
            this.bunifuButton212.AllowToggling = false;
            this.bunifuButton212.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton212.AnimationSpeed = 200;
            this.bunifuButton212.AutoGenerateColors = false;
            this.bunifuButton212.AutoRoundBorders = false;
            this.bunifuButton212.AutoSizeLeftIcon = true;
            this.bunifuButton212.AutoSizeRightIcon = true;
            this.bunifuButton212.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton212.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton212.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton212.BackgroundImage")));
            this.bunifuButton212.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton212.ButtonText = "Maintenance Portal";
            this.bunifuButton212.ButtonTextMarginLeft = 0;
            this.bunifuButton212.ColorContrastOnClick = 45;
            this.bunifuButton212.ColorContrastOnHover = 45;
            this.bunifuButton212.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges13.BottomLeft = true;
            borderEdges13.BottomRight = true;
            borderEdges13.TopLeft = true;
            borderEdges13.TopRight = true;
            this.bunifuButton212.CustomizableEdges = borderEdges13;
            this.bunifuButton212.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton212.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton212.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton212.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton212.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton212.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.bunifuButton212.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuButton212.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton212.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton212.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton212.IconMarginLeft = 11;
            this.bunifuButton212.IconPadding = 10;
            this.bunifuButton212.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton212.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton212.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton212.IconSize = 25;
            this.bunifuButton212.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton212.IdleBorderRadius = 1;
            this.bunifuButton212.IdleBorderThickness = 1;
            this.bunifuButton212.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton212.IdleIconLeftImage = null;
            this.bunifuButton212.IdleIconRightImage = null;
            this.bunifuButton212.IndicateFocus = false;
            this.bunifuButton212.Location = new System.Drawing.Point(3, 3);
            this.bunifuButton212.Name = "bunifuButton212";
            this.bunifuButton212.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton212.OnDisabledState.BorderRadius = 1;
            this.bunifuButton212.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton212.OnDisabledState.BorderThickness = 1;
            this.bunifuButton212.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton212.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton212.OnDisabledState.IconLeftImage = null;
            this.bunifuButton212.OnDisabledState.IconRightImage = null;
            this.bunifuButton212.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton212.onHoverState.BorderRadius = 1;
            this.bunifuButton212.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton212.onHoverState.BorderThickness = 1;
            this.bunifuButton212.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton212.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton212.onHoverState.IconLeftImage = null;
            this.bunifuButton212.onHoverState.IconRightImage = null;
            this.bunifuButton212.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton212.OnIdleState.BorderRadius = 1;
            this.bunifuButton212.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton212.OnIdleState.BorderThickness = 1;
            this.bunifuButton212.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton212.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuButton212.OnIdleState.IconLeftImage = null;
            this.bunifuButton212.OnIdleState.IconRightImage = null;
            this.bunifuButton212.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton212.OnPressedState.BorderRadius = 1;
            this.bunifuButton212.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton212.OnPressedState.BorderThickness = 1;
            this.bunifuButton212.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton212.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton212.OnPressedState.IconLeftImage = null;
            this.bunifuButton212.OnPressedState.IconRightImage = null;
            this.bunifuButton212.Size = new System.Drawing.Size(263, 39);
            this.bunifuButton212.TabIndex = 0;
            this.bunifuButton212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton212.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton212.TextMarginLeft = 0;
            this.bunifuButton212.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton212.UseDefaultRadiusAndThickness = true;
            this.bunifuButton212.Click += new System.EventHandler(this.bunifuButton212_Click);
            // 
            // bunifuButton29
            // 
            this.bunifuButton29.AllowAnimations = true;
            this.bunifuButton29.AllowMouseEffects = true;
            this.bunifuButton29.AllowToggling = false;
            this.bunifuButton29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton29.AnimationSpeed = 200;
            this.bunifuButton29.AutoGenerateColors = false;
            this.bunifuButton29.AutoRoundBorders = false;
            this.bunifuButton29.AutoSizeLeftIcon = true;
            this.bunifuButton29.AutoSizeRightIcon = true;
            this.bunifuButton29.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton29.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton29.BackgroundImage")));
            this.bunifuButton29.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton29.ButtonText = "Maintenance Reports";
            this.bunifuButton29.ButtonTextMarginLeft = 0;
            this.bunifuButton29.ColorContrastOnClick = 45;
            this.bunifuButton29.ColorContrastOnHover = 45;
            this.bunifuButton29.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges14.BottomLeft = true;
            borderEdges14.BottomRight = true;
            borderEdges14.TopLeft = true;
            borderEdges14.TopRight = true;
            this.bunifuButton29.CustomizableEdges = borderEdges14;
            this.bunifuButton29.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton29.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton29.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton29.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton29.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton29.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton29.ForeColor = System.Drawing.Color.White;
            this.bunifuButton29.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton29.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton29.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton29.IconMarginLeft = 11;
            this.bunifuButton29.IconPadding = 10;
            this.bunifuButton29.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton29.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton29.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton29.IconSize = 25;
            this.bunifuButton29.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton29.IdleBorderRadius = 1;
            this.bunifuButton29.IdleBorderThickness = 1;
            this.bunifuButton29.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton29.IdleIconLeftImage = null;
            this.bunifuButton29.IdleIconRightImage = null;
            this.bunifuButton29.IndicateFocus = false;
            this.bunifuButton29.Location = new System.Drawing.Point(3, 97);
            this.bunifuButton29.Name = "bunifuButton29";
            this.bunifuButton29.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton29.OnDisabledState.BorderRadius = 1;
            this.bunifuButton29.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton29.OnDisabledState.BorderThickness = 1;
            this.bunifuButton29.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton29.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton29.OnDisabledState.IconLeftImage = null;
            this.bunifuButton29.OnDisabledState.IconRightImage = null;
            this.bunifuButton29.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton29.onHoverState.BorderRadius = 1;
            this.bunifuButton29.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton29.onHoverState.BorderThickness = 1;
            this.bunifuButton29.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton29.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton29.onHoverState.IconLeftImage = null;
            this.bunifuButton29.onHoverState.IconRightImage = null;
            this.bunifuButton29.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton29.OnIdleState.BorderRadius = 1;
            this.bunifuButton29.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton29.OnIdleState.BorderThickness = 1;
            this.bunifuButton29.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton29.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton29.OnIdleState.IconLeftImage = null;
            this.bunifuButton29.OnIdleState.IconRightImage = null;
            this.bunifuButton29.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton29.OnPressedState.BorderRadius = 1;
            this.bunifuButton29.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton29.OnPressedState.BorderThickness = 1;
            this.bunifuButton29.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton29.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton29.OnPressedState.IconLeftImage = null;
            this.bunifuButton29.OnPressedState.IconRightImage = null;
            this.bunifuButton29.Size = new System.Drawing.Size(263, 45);
            this.bunifuButton29.TabIndex = 3;
            this.bunifuButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton29.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton29.TextMarginLeft = 0;
            this.bunifuButton29.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton29.UseDefaultRadiusAndThickness = true;
            this.bunifuButton29.Click += new System.EventHandler(this.bunifuButton29_Click);
            // 
            // bunifuButton210
            // 
            this.bunifuButton210.AllowAnimations = true;
            this.bunifuButton210.AllowMouseEffects = true;
            this.bunifuButton210.AllowToggling = false;
            this.bunifuButton210.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton210.AnimationSpeed = 200;
            this.bunifuButton210.AutoGenerateColors = false;
            this.bunifuButton210.AutoRoundBorders = false;
            this.bunifuButton210.AutoSizeLeftIcon = true;
            this.bunifuButton210.AutoSizeRightIcon = true;
            this.bunifuButton210.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton210.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton210.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton210.BackgroundImage")));
            this.bunifuButton210.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton210.ButtonText = "Requests (Add)";
            this.bunifuButton210.ButtonTextMarginLeft = 0;
            this.bunifuButton210.ColorContrastOnClick = 45;
            this.bunifuButton210.ColorContrastOnHover = 45;
            this.bunifuButton210.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges15.BottomLeft = true;
            borderEdges15.BottomRight = true;
            borderEdges15.TopLeft = true;
            borderEdges15.TopRight = true;
            this.bunifuButton210.CustomizableEdges = borderEdges15;
            this.bunifuButton210.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton210.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton210.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton210.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton210.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton210.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton210.ForeColor = System.Drawing.Color.White;
            this.bunifuButton210.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton210.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton210.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton210.IconMarginLeft = 11;
            this.bunifuButton210.IconPadding = 10;
            this.bunifuButton210.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton210.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton210.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton210.IconSize = 25;
            this.bunifuButton210.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton210.IdleBorderRadius = 1;
            this.bunifuButton210.IdleBorderThickness = 1;
            this.bunifuButton210.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton210.IdleIconLeftImage = null;
            this.bunifuButton210.IdleIconRightImage = null;
            this.bunifuButton210.IndicateFocus = false;
            this.bunifuButton210.Location = new System.Drawing.Point(3, 48);
            this.bunifuButton210.Name = "bunifuButton210";
            this.bunifuButton210.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton210.OnDisabledState.BorderRadius = 1;
            this.bunifuButton210.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton210.OnDisabledState.BorderThickness = 1;
            this.bunifuButton210.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton210.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton210.OnDisabledState.IconLeftImage = null;
            this.bunifuButton210.OnDisabledState.IconRightImage = null;
            this.bunifuButton210.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton210.onHoverState.BorderRadius = 1;
            this.bunifuButton210.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton210.onHoverState.BorderThickness = 1;
            this.bunifuButton210.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton210.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton210.onHoverState.IconLeftImage = null;
            this.bunifuButton210.onHoverState.IconRightImage = null;
            this.bunifuButton210.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton210.OnIdleState.BorderRadius = 1;
            this.bunifuButton210.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton210.OnIdleState.BorderThickness = 1;
            this.bunifuButton210.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton210.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton210.OnIdleState.IconLeftImage = null;
            this.bunifuButton210.OnIdleState.IconRightImage = null;
            this.bunifuButton210.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton210.OnPressedState.BorderRadius = 1;
            this.bunifuButton210.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton210.OnPressedState.BorderThickness = 1;
            this.bunifuButton210.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton210.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton210.OnPressedState.IconLeftImage = null;
            this.bunifuButton210.OnPressedState.IconRightImage = null;
            this.bunifuButton210.Size = new System.Drawing.Size(263, 45);
            this.bunifuButton210.TabIndex = 2;
            this.bunifuButton210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton210.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton210.TextMarginLeft = 0;
            this.bunifuButton210.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton210.UseDefaultRadiusAndThickness = true;
            this.bunifuButton210.Click += new System.EventHandler(this.bunifuButton210_Click);
            // 
            // bunifuButton4
            // 
            this.bunifuButton4.AllowAnimations = true;
            this.bunifuButton4.AllowMouseEffects = true;
            this.bunifuButton4.AllowToggling = false;
            this.bunifuButton4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton4.AnimationSpeed = 200;
            this.bunifuButton4.AutoGenerateColors = false;
            this.bunifuButton4.AutoRoundBorders = false;
            this.bunifuButton4.AutoSizeLeftIcon = true;
            this.bunifuButton4.AutoSizeRightIcon = true;
            this.bunifuButton4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton4.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.BackgroundImage")));
            this.bunifuButton4.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.ButtonText = "Ranking";
            this.bunifuButton4.ButtonTextMarginLeft = 0;
            this.bunifuButton4.ColorContrastOnClick = 45;
            this.bunifuButton4.ColorContrastOnHover = 45;
            this.bunifuButton4.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges16.BottomLeft = true;
            borderEdges16.BottomRight = true;
            borderEdges16.TopLeft = true;
            borderEdges16.TopRight = true;
            this.bunifuButton4.CustomizableEdges = borderEdges16;
            this.bunifuButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton4.DisabledFillColor = System.Drawing.Color.Empty;
            this.bunifuButton4.DisabledForecolor = System.Drawing.Color.Empty;
            this.bunifuButton4.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuButton4.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.IconLeft")));
            this.bunifuButton4.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton4.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton4.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton4.IconMarginLeft = 11;
            this.bunifuButton4.IconPadding = 10;
            this.bunifuButton4.IconRight = null;
            this.bunifuButton4.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton4.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton4.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton4.IconSize = 25;
            this.bunifuButton4.IdleBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton4.IdleBorderRadius = 0;
            this.bunifuButton4.IdleBorderThickness = 0;
            this.bunifuButton4.IdleFillColor = System.Drawing.Color.Empty;
            this.bunifuButton4.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.IdleIconLeftImage")));
            this.bunifuButton4.IdleIconRightImage = null;
            this.bunifuButton4.IndicateFocus = false;
            this.bunifuButton4.Location = new System.Drawing.Point(6, 3);
            this.bunifuButton4.Name = "bunifuButton4";
            this.bunifuButton4.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton4.OnDisabledState.BorderRadius = 15;
            this.bunifuButton4.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.OnDisabledState.BorderThickness = 0;
            this.bunifuButton4.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton4.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton4.OnDisabledState.IconLeftImage = null;
            this.bunifuButton4.OnDisabledState.IconRightImage = null;
            this.bunifuButton4.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton4.onHoverState.BorderRadius = 15;
            this.bunifuButton4.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.onHoverState.BorderThickness = 0;
            this.bunifuButton4.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton4.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton4.onHoverState.IconLeftImage = null;
            this.bunifuButton4.onHoverState.IconRightImage = null;
            this.bunifuButton4.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.bunifuButton4.OnIdleState.BorderRadius = 15;
            this.bunifuButton4.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.OnIdleState.BorderThickness = 0;
            this.bunifuButton4.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuButton4.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton4.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.OnIdleState.IconLeftImage")));
            this.bunifuButton4.OnIdleState.IconRightImage = null;
            this.bunifuButton4.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton4.OnPressedState.BorderRadius = 15;
            this.bunifuButton4.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.OnPressedState.BorderThickness = 0;
            this.bunifuButton4.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton4.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton4.OnPressedState.IconLeftImage = null;
            this.bunifuButton4.OnPressedState.IconRightImage = null;
            this.bunifuButton4.Size = new System.Drawing.Size(179, 39);
            this.bunifuButton4.TabIndex = 6;
            this.bunifuButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton4.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton4.TextMarginLeft = 0;
            this.bunifuButton4.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton4.UseDefaultRadiusAndThickness = true;
            this.bunifuButton4.Click += new System.EventHandler(this.bunifuButton4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(22, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(122, 70);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuButton3
            // 
            this.bunifuButton3.AllowAnimations = true;
            this.bunifuButton3.AllowMouseEffects = true;
            this.bunifuButton3.AllowToggling = false;
            this.bunifuButton3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton3.AnimationSpeed = 200;
            this.bunifuButton3.AutoGenerateColors = false;
            this.bunifuButton3.AutoRoundBorders = false;
            this.bunifuButton3.AutoSizeLeftIcon = true;
            this.bunifuButton3.AutoSizeRightIcon = true;
            this.bunifuButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.BackgroundImage")));
            this.bunifuButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.ButtonText = "Periodic Reports";
            this.bunifuButton3.ButtonTextMarginLeft = 0;
            this.bunifuButton3.ColorContrastOnClick = 45;
            this.bunifuButton3.ColorContrastOnHover = 45;
            this.bunifuButton3.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges17.BottomLeft = true;
            borderEdges17.BottomRight = true;
            borderEdges17.TopLeft = true;
            borderEdges17.TopRight = true;
            this.bunifuButton3.CustomizableEdges = borderEdges17;
            this.bunifuButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton3.DisabledFillColor = System.Drawing.Color.Empty;
            this.bunifuButton3.DisabledForecolor = System.Drawing.Color.Empty;
            this.bunifuButton3.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.IconLeft")));
            this.bunifuButton3.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton3.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton3.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton3.IconMarginLeft = 11;
            this.bunifuButton3.IconPadding = 10;
            this.bunifuButton3.IconRight = null;
            this.bunifuButton3.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton3.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton3.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton3.IconSize = 25;
            this.bunifuButton3.IdleBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton3.IdleBorderRadius = 0;
            this.bunifuButton3.IdleBorderThickness = 0;
            this.bunifuButton3.IdleFillColor = System.Drawing.Color.Empty;
            this.bunifuButton3.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.IdleIconLeftImage")));
            this.bunifuButton3.IdleIconRightImage = null;
            this.bunifuButton3.IndicateFocus = false;
            this.bunifuButton3.Location = new System.Drawing.Point(16, 264);
            this.bunifuButton3.Name = "bunifuButton3";
            this.bunifuButton3.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton3.OnDisabledState.BorderRadius = 15;
            this.bunifuButton3.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.OnDisabledState.BorderThickness = 0;
            this.bunifuButton3.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton3.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton3.OnDisabledState.IconLeftImage = null;
            this.bunifuButton3.OnDisabledState.IconRightImage = null;
            this.bunifuButton3.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton3.onHoverState.BorderRadius = 15;
            this.bunifuButton3.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.onHoverState.BorderThickness = 0;
            this.bunifuButton3.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton3.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.onHoverState.IconLeftImage = null;
            this.bunifuButton3.onHoverState.IconRightImage = null;
            this.bunifuButton3.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.bunifuButton3.OnIdleState.BorderRadius = 15;
            this.bunifuButton3.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.OnIdleState.BorderThickness = 0;
            this.bunifuButton3.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuButton3.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.OnIdleState.IconLeftImage")));
            this.bunifuButton3.OnIdleState.IconRightImage = null;
            this.bunifuButton3.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton3.OnPressedState.BorderRadius = 15;
            this.bunifuButton3.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.OnPressedState.BorderThickness = 0;
            this.bunifuButton3.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton3.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.OnPressedState.IconLeftImage = null;
            this.bunifuButton3.OnPressedState.IconRightImage = null;
            this.bunifuButton3.Size = new System.Drawing.Size(187, 39);
            this.bunifuButton3.TabIndex = 5;
            this.bunifuButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton3.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton3.TextMarginLeft = 0;
            this.bunifuButton3.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton3.UseDefaultRadiusAndThickness = true;
            this.bunifuButton3.Click += new System.EventHandler(this.bunifuButton3_Click);
            // 
            // bunifuButton5
            // 
            this.bunifuButton5.AllowAnimations = true;
            this.bunifuButton5.AllowMouseEffects = true;
            this.bunifuButton5.AllowToggling = false;
            this.bunifuButton5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton5.AnimationSpeed = 200;
            this.bunifuButton5.AutoGenerateColors = false;
            this.bunifuButton5.AutoRoundBorders = false;
            this.bunifuButton5.AutoSizeLeftIcon = true;
            this.bunifuButton5.AutoSizeRightIcon = true;
            this.bunifuButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton5.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton5.BackgroundImage")));
            this.bunifuButton5.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton5.ButtonText = "Messages";
            this.bunifuButton5.ButtonTextMarginLeft = 0;
            this.bunifuButton5.ColorContrastOnClick = 45;
            this.bunifuButton5.ColorContrastOnHover = 45;
            this.bunifuButton5.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges18.BottomLeft = true;
            borderEdges18.BottomRight = true;
            borderEdges18.TopLeft = true;
            borderEdges18.TopRight = true;
            this.bunifuButton5.CustomizableEdges = borderEdges18;
            this.bunifuButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton5.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton5.DisabledFillColor = System.Drawing.Color.Empty;
            this.bunifuButton5.DisabledForecolor = System.Drawing.Color.Empty;
            this.bunifuButton5.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton5.ForeColor = System.Drawing.Color.White;
            this.bunifuButton5.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuButton5.IconLeft")));
            this.bunifuButton5.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton5.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton5.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton5.IconMarginLeft = 11;
            this.bunifuButton5.IconPadding = 10;
            this.bunifuButton5.IconRight = null;
            this.bunifuButton5.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton5.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton5.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton5.IconSize = 25;
            this.bunifuButton5.IdleBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton5.IdleBorderRadius = 0;
            this.bunifuButton5.IdleBorderThickness = 0;
            this.bunifuButton5.IdleFillColor = System.Drawing.Color.Empty;
            this.bunifuButton5.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton5.IdleIconLeftImage")));
            this.bunifuButton5.IdleIconRightImage = null;
            this.bunifuButton5.IndicateFocus = false;
            this.bunifuButton5.Location = new System.Drawing.Point(16, 361);
            this.bunifuButton5.Name = "bunifuButton5";
            this.bunifuButton5.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton5.OnDisabledState.BorderRadius = 15;
            this.bunifuButton5.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton5.OnDisabledState.BorderThickness = 0;
            this.bunifuButton5.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton5.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton5.OnDisabledState.IconLeftImage = null;
            this.bunifuButton5.OnDisabledState.IconRightImage = null;
            this.bunifuButton5.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton5.onHoverState.BorderRadius = 15;
            this.bunifuButton5.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton5.onHoverState.BorderThickness = 0;
            this.bunifuButton5.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton5.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton5.onHoverState.IconLeftImage = null;
            this.bunifuButton5.onHoverState.IconRightImage = null;
            this.bunifuButton5.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.bunifuButton5.OnIdleState.BorderRadius = 15;
            this.bunifuButton5.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton5.OnIdleState.BorderThickness = 0;
            this.bunifuButton5.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuButton5.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton5.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton5.OnIdleState.IconLeftImage")));
            this.bunifuButton5.OnIdleState.IconRightImage = null;
            this.bunifuButton5.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton5.OnPressedState.BorderRadius = 15;
            this.bunifuButton5.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton5.OnPressedState.BorderThickness = 0;
            this.bunifuButton5.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton5.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton5.OnPressedState.IconLeftImage = null;
            this.bunifuButton5.OnPressedState.IconRightImage = null;
            this.bunifuButton5.Size = new System.Drawing.Size(187, 39);
            this.bunifuButton5.TabIndex = 7;
            this.bunifuButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton5.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton5.TextMarginLeft = 0;
            this.bunifuButton5.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton5.UseDefaultRadiusAndThickness = true;
            this.bunifuButton5.Click += new System.EventHandler(this.bunifuButton5_Click);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuSeparator1.BackgroundImage")));
            this.bunifuSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuSeparator1.DashCap = Bunifu.UI.WinForms.BunifuSeparator.CapStyles.Round;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.Silver;
            this.bunifuSeparator1.LineStyle = Bunifu.UI.WinForms.BunifuSeparator.LineStyles.Solid;
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(14, 111);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Orientation = Bunifu.UI.WinForms.BunifuSeparator.LineOrientation.Horizontal;
            this.bunifuSeparator1.Size = new System.Drawing.Size(143, 19);
            this.bunifuSeparator1.TabIndex = 2;
            // 
            // buttonProperties
            // 
            this.buttonProperties.AllowAnimations = true;
            this.buttonProperties.AllowMouseEffects = true;
            this.buttonProperties.AllowToggling = false;
            this.buttonProperties.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonProperties.AnimationSpeed = 200;
            this.buttonProperties.AutoGenerateColors = false;
            this.buttonProperties.AutoRoundBorders = false;
            this.buttonProperties.AutoSizeLeftIcon = true;
            this.buttonProperties.AutoSizeRightIcon = true;
            this.buttonProperties.BackColor = System.Drawing.Color.Transparent;
            this.buttonProperties.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.buttonProperties.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonProperties.BackgroundImage")));
            this.buttonProperties.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.buttonProperties.ButtonText = "Vacancy Positions";
            this.buttonProperties.ButtonTextMarginLeft = 0;
            this.buttonProperties.ColorContrastOnClick = 45;
            this.buttonProperties.ColorContrastOnHover = 45;
            this.buttonProperties.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges19.BottomLeft = true;
            borderEdges19.BottomRight = true;
            borderEdges19.TopLeft = true;
            borderEdges19.TopRight = true;
            this.buttonProperties.CustomizableEdges = borderEdges19;
            this.buttonProperties.DialogResult = System.Windows.Forms.DialogResult.None;
            this.buttonProperties.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.buttonProperties.DisabledFillColor = System.Drawing.Color.Empty;
            this.buttonProperties.DisabledForecolor = System.Drawing.Color.Empty;
            this.buttonProperties.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.buttonProperties.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.buttonProperties.ForeColor = System.Drawing.Color.White;
            this.buttonProperties.IconLeft = ((System.Drawing.Image)(resources.GetObject("buttonProperties.IconLeft")));
            this.buttonProperties.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonProperties.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.buttonProperties.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.buttonProperties.IconMarginLeft = 11;
            this.buttonProperties.IconPadding = 10;
            this.buttonProperties.IconRight = null;
            this.buttonProperties.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonProperties.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.buttonProperties.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.buttonProperties.IconSize = 25;
            this.buttonProperties.IdleBorderColor = System.Drawing.Color.Empty;
            this.buttonProperties.IdleBorderRadius = 0;
            this.buttonProperties.IdleBorderThickness = 0;
            this.buttonProperties.IdleFillColor = System.Drawing.Color.Empty;
            this.buttonProperties.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("buttonProperties.IdleIconLeftImage")));
            this.buttonProperties.IdleIconRightImage = null;
            this.buttonProperties.IndicateFocus = false;
            this.buttonProperties.Location = new System.Drawing.Point(14, 213);
            this.buttonProperties.Name = "buttonProperties";
            this.buttonProperties.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.buttonProperties.OnDisabledState.BorderRadius = 15;
            this.buttonProperties.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.buttonProperties.OnDisabledState.BorderThickness = 0;
            this.buttonProperties.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.buttonProperties.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.buttonProperties.OnDisabledState.IconLeftImage = null;
            this.buttonProperties.OnDisabledState.IconRightImage = null;
            this.buttonProperties.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.buttonProperties.onHoverState.BorderRadius = 15;
            this.buttonProperties.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.buttonProperties.onHoverState.BorderThickness = 0;
            this.buttonProperties.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.buttonProperties.onHoverState.ForeColor = System.Drawing.Color.White;
            this.buttonProperties.onHoverState.IconLeftImage = null;
            this.buttonProperties.onHoverState.IconRightImage = null;
            this.buttonProperties.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.buttonProperties.OnIdleState.BorderRadius = 15;
            this.buttonProperties.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.buttonProperties.OnIdleState.BorderThickness = 0;
            this.buttonProperties.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.buttonProperties.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.buttonProperties.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("buttonProperties.OnIdleState.IconLeftImage")));
            this.buttonProperties.OnIdleState.IconRightImage = null;
            this.buttonProperties.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.buttonProperties.OnPressedState.BorderRadius = 15;
            this.buttonProperties.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.buttonProperties.OnPressedState.BorderThickness = 0;
            this.buttonProperties.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.buttonProperties.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.buttonProperties.OnPressedState.IconLeftImage = null;
            this.buttonProperties.OnPressedState.IconRightImage = null;
            this.buttonProperties.Size = new System.Drawing.Size(187, 39);
            this.buttonProperties.TabIndex = 4;
            this.buttonProperties.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.buttonProperties.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.buttonProperties.TextMarginLeft = 0;
            this.buttonProperties.TextPadding = new System.Windows.Forms.Padding(0);
            this.buttonProperties.UseDefaultRadiusAndThickness = true;
            this.buttonProperties.Click += new System.EventHandler(this.buttonProperties_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(12, 587);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(189, 91);
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pnlMenu
            // 
            this.pnlMenu.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.pnlMenu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlMenu.BackgroundImage")));
            this.pnlMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMenu.BorderColor = System.Drawing.Color.Transparent;
            this.pnlMenu.BorderRadius = 3;
            this.pnlMenu.BorderThickness = 1;
            this.pnlMenu.Controls.Add(this.bunifuLabel1);
            this.pnlMenu.Controls.Add(this.bunifuPanel2);
            this.pnlMenu.Controls.Add(this.pictureBox2);
            this.pnlMenu.Controls.Add(this.buttonProperties);
            this.pnlMenu.Controls.Add(this.bunifuSeparator1);
            this.pnlMenu.Controls.Add(this.bunifuButton5);
            this.pnlMenu.Controls.Add(this.bunifuButton3);
            this.pnlMenu.Controls.Add(this.pictureBox1);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.ShowBorders = true;
            this.pnlMenu.Size = new System.Drawing.Size(217, 955);
            this.pnlMenu.TabIndex = 15;
            this.pnlMenu.Click += new System.EventHandler(this.pnlMenu_Click);
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Lucida Calligraphy", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuLabel1.Location = new System.Drawing.Point(12, 136);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(173, 41);
            this.bunifuLabel1.TabIndex = 10;
            this.bunifuLabel1.Text = "Parrallex";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuPanel2
            // 
            this.bunifuPanel2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel2.BackgroundImage")));
            this.bunifuPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuPanel2.BorderRadius = 3;
            this.bunifuPanel2.BorderThickness = 0;
            this.bunifuPanel2.Controls.Add(this.bunifuButton6);
            this.bunifuPanel2.Controls.Add(this.bunifuButton2);
            this.bunifuPanel2.Controls.Add(this.bunifuButton1);
            this.bunifuPanel2.Controls.Add(this.bunifuButton4);
            this.bunifuPanel2.Location = new System.Drawing.Point(12, 309);
            this.bunifuPanel2.Name = "bunifuPanel2";
            this.bunifuPanel2.ShowBorders = true;
            this.bunifuPanel2.Size = new System.Drawing.Size(187, 46);
            this.bunifuPanel2.TabIndex = 9;
            // 
            // bunifuButton6
            // 
            this.bunifuButton6.AllowAnimations = true;
            this.bunifuButton6.AllowMouseEffects = true;
            this.bunifuButton6.AllowToggling = false;
            this.bunifuButton6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton6.AnimationSpeed = 200;
            this.bunifuButton6.AutoGenerateColors = false;
            this.bunifuButton6.AutoRoundBorders = false;
            this.bunifuButton6.AutoSizeLeftIcon = true;
            this.bunifuButton6.AutoSizeRightIcon = true;
            this.bunifuButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton6.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton6.BackgroundImage")));
            this.bunifuButton6.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.ButtonText = "Properties";
            this.bunifuButton6.ButtonTextMarginLeft = 0;
            this.bunifuButton6.ColorContrastOnClick = 45;
            this.bunifuButton6.ColorContrastOnHover = 45;
            this.bunifuButton6.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges20.BottomLeft = true;
            borderEdges20.BottomRight = true;
            borderEdges20.TopLeft = true;
            borderEdges20.TopRight = true;
            this.bunifuButton6.CustomizableEdges = borderEdges20;
            this.bunifuButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton6.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton6.DisabledFillColor = System.Drawing.Color.Empty;
            this.bunifuButton6.DisabledForecolor = System.Drawing.Color.Empty;
            this.bunifuButton6.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton6.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuButton6.IconLeft")));
            this.bunifuButton6.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton6.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton6.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton6.IconMarginLeft = 11;
            this.bunifuButton6.IconPadding = 10;
            this.bunifuButton6.IconRight = null;
            this.bunifuButton6.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton6.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton6.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton6.IconSize = 25;
            this.bunifuButton6.IdleBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton6.IdleBorderRadius = 0;
            this.bunifuButton6.IdleBorderThickness = 0;
            this.bunifuButton6.IdleFillColor = System.Drawing.Color.Empty;
            this.bunifuButton6.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton6.IdleIconLeftImage")));
            this.bunifuButton6.IdleIconRightImage = null;
            this.bunifuButton6.IndicateFocus = false;
            this.bunifuButton6.Location = new System.Drawing.Point(15, 94);
            this.bunifuButton6.Name = "bunifuButton6";
            this.bunifuButton6.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton6.OnDisabledState.BorderRadius = 15;
            this.bunifuButton6.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.OnDisabledState.BorderThickness = 0;
            this.bunifuButton6.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton6.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton6.OnDisabledState.IconLeftImage = null;
            this.bunifuButton6.OnDisabledState.IconRightImage = null;
            this.bunifuButton6.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton6.onHoverState.BorderRadius = 15;
            this.bunifuButton6.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.onHoverState.BorderThickness = 0;
            this.bunifuButton6.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton6.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.onHoverState.IconLeftImage = null;
            this.bunifuButton6.onHoverState.IconRightImage = null;
            this.bunifuButton6.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.bunifuButton6.OnIdleState.BorderRadius = 15;
            this.bunifuButton6.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.OnIdleState.BorderThickness = 0;
            this.bunifuButton6.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuButton6.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton6.OnIdleState.IconLeftImage")));
            this.bunifuButton6.OnIdleState.IconRightImage = null;
            this.bunifuButton6.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton6.OnPressedState.BorderRadius = 15;
            this.bunifuButton6.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.OnPressedState.BorderThickness = 0;
            this.bunifuButton6.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton6.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.OnPressedState.IconLeftImage = null;
            this.bunifuButton6.OnPressedState.IconRightImage = null;
            this.bunifuButton6.Size = new System.Drawing.Size(158, 35);
            this.bunifuButton6.TabIndex = 9;
            this.bunifuButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton6.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton6.TextMarginLeft = 0;
            this.bunifuButton6.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton6.UseDefaultRadiusAndThickness = true;
            this.bunifuButton6.Click += new System.EventHandler(this.bunifuButton6_Click);
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowAnimations = true;
            this.bunifuButton2.AllowMouseEffects = true;
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.AutoRoundBorders = false;
            this.bunifuButton2.AutoSizeLeftIcon = true;
            this.bunifuButton2.AutoSizeRightIcon = true;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "Expenses";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges21.BottomLeft = true;
            borderEdges21.BottomRight = true;
            borderEdges21.TopLeft = true;
            borderEdges21.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges21;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.Empty;
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.Empty;
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.IconLeft")));
            this.bunifuButton2.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton2.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRight = null;
            this.bunifuButton2.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton2.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton2.IconSize = 25;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton2.IdleBorderRadius = 0;
            this.bunifuButton2.IdleBorderThickness = 0;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.Empty;
            this.bunifuButton2.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.IdleIconLeftImage")));
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(15, 135);
            this.bunifuButton2.Name = "bunifuButton2";
            this.bunifuButton2.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton2.OnDisabledState.BorderRadius = 15;
            this.bunifuButton2.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnDisabledState.BorderThickness = 0;
            this.bunifuButton2.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.OnDisabledState.IconLeftImage = null;
            this.bunifuButton2.OnDisabledState.IconRightImage = null;
            this.bunifuButton2.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton2.onHoverState.BorderRadius = 15;
            this.bunifuButton2.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.onHoverState.BorderThickness = 0;
            this.bunifuButton2.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton2.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.onHoverState.IconLeftImage = null;
            this.bunifuButton2.onHoverState.IconRightImage = null;
            this.bunifuButton2.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.bunifuButton2.OnIdleState.BorderRadius = 15;
            this.bunifuButton2.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnIdleState.BorderThickness = 0;
            this.bunifuButton2.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuButton2.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.OnIdleState.IconLeftImage")));
            this.bunifuButton2.OnIdleState.IconRightImage = null;
            this.bunifuButton2.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton2.OnPressedState.BorderRadius = 15;
            this.bunifuButton2.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnPressedState.BorderThickness = 0;
            this.bunifuButton2.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton2.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnPressedState.IconLeftImage = null;
            this.bunifuButton2.OnPressedState.IconRightImage = null;
            this.bunifuButton2.Size = new System.Drawing.Size(158, 35);
            this.bunifuButton2.TabIndex = 8;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowAnimations = true;
            this.bunifuButton1.AllowMouseEffects = true;
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = false;
            this.bunifuButton1.AutoRoundBorders = false;
            this.bunifuButton1.AutoSizeLeftIcon = true;
            this.bunifuButton1.AutoSizeRightIcon = true;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "Tenants";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges22.BottomLeft = true;
            borderEdges22.BottomRight = true;
            borderEdges22.TopLeft = true;
            borderEdges22.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges22;
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.Empty;
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.Empty;
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.IconLeft")));
            this.bunifuButton1.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRight = null;
            this.bunifuButton1.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton1.IconSize = 25;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton1.IdleBorderRadius = 0;
            this.bunifuButton1.IdleBorderThickness = 0;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.Empty;
            this.bunifuButton1.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.IdleIconLeftImage")));
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(15, 48);
            this.bunifuButton1.Name = "bunifuButton1";
            this.bunifuButton1.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton1.OnDisabledState.BorderRadius = 15;
            this.bunifuButton1.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnDisabledState.BorderThickness = 0;
            this.bunifuButton1.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.OnDisabledState.IconLeftImage = null;
            this.bunifuButton1.OnDisabledState.IconRightImage = null;
            this.bunifuButton1.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton1.onHoverState.BorderRadius = 15;
            this.bunifuButton1.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.onHoverState.BorderThickness = 0;
            this.bunifuButton1.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.bunifuButton1.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.onHoverState.IconLeftImage = null;
            this.bunifuButton1.onHoverState.IconRightImage = null;
            this.bunifuButton1.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(24)))), ((int)(((byte)(157)))));
            this.bunifuButton1.OnIdleState.BorderRadius = 15;
            this.bunifuButton1.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnIdleState.BorderThickness = 0;
            this.bunifuButton1.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(27)))), ((int)(((byte)(67)))));
            this.bunifuButton1.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.OnIdleState.IconLeftImage")));
            this.bunifuButton1.OnIdleState.IconRightImage = null;
            this.bunifuButton1.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton1.OnPressedState.BorderRadius = 15;
            this.bunifuButton1.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnPressedState.BorderThickness = 0;
            this.bunifuButton1.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton1.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.OnPressedState.IconLeftImage = null;
            this.bunifuButton1.OnPressedState.IconRightImage = null;
            this.bunifuButton1.Size = new System.Drawing.Size(158, 40);
            this.bunifuButton1.TabIndex = 7;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuButton1.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton1.UseDefaultRadiusAndThickness = true;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // bunifuColorTransition1
            // 
            this.bunifuColorTransition1.AutoTransition = false;
            this.bunifuColorTransition1.ColorArray = new System.Drawing.Color[] {
        System.Drawing.Color.Purple,
        System.Drawing.Color.LightBlue,
        System.Drawing.Color.Orange};
            this.bunifuColorTransition1.EndColor = System.Drawing.Color.White;
            this.bunifuColorTransition1.Interval = 10;
            this.bunifuColorTransition1.ProgessValue = 0;
            this.bunifuColorTransition1.StartColor = System.Drawing.Color.White;
            this.bunifuColorTransition1.TransitionControl = null;
            // 
            // bunifuButton22
            // 
            this.bunifuButton22.AllowAnimations = true;
            this.bunifuButton22.AllowMouseEffects = true;
            this.bunifuButton22.AllowToggling = false;
            this.bunifuButton22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton22.AnimationSpeed = 200;
            this.bunifuButton22.AutoGenerateColors = false;
            this.bunifuButton22.AutoRoundBorders = false;
            this.bunifuButton22.AutoSizeLeftIcon = true;
            this.bunifuButton22.AutoSizeRightIcon = true;
            this.bunifuButton22.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton22.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton22.BackgroundImage")));
            this.bunifuButton22.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.ButtonText = "Tenant profile";
            this.bunifuButton22.ButtonTextMarginLeft = 0;
            this.bunifuButton22.ColorContrastOnClick = 45;
            this.bunifuButton22.ColorContrastOnHover = 45;
            this.bunifuButton22.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges23.BottomLeft = true;
            borderEdges23.BottomRight = true;
            borderEdges23.TopLeft = true;
            borderEdges23.TopRight = true;
            this.bunifuButton22.CustomizableEdges = borderEdges23;
            this.bunifuButton22.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton22.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton22.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton22.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton22.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton22.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton22.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton22.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton22.IconMarginLeft = 11;
            this.bunifuButton22.IconPadding = 10;
            this.bunifuButton22.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton22.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton22.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton22.IconSize = 25;
            this.bunifuButton22.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton22.IdleBorderRadius = 1;
            this.bunifuButton22.IdleBorderThickness = 1;
            this.bunifuButton22.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton22.IdleIconLeftImage = null;
            this.bunifuButton22.IdleIconRightImage = null;
            this.bunifuButton22.IndicateFocus = false;
            this.bunifuButton22.Location = new System.Drawing.Point(4, 48);
            this.bunifuButton22.Name = "bunifuButton22";
            this.bunifuButton22.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton22.OnDisabledState.BorderRadius = 1;
            this.bunifuButton22.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.OnDisabledState.BorderThickness = 1;
            this.bunifuButton22.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton22.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton22.OnDisabledState.IconLeftImage = null;
            this.bunifuButton22.OnDisabledState.IconRightImage = null;
            this.bunifuButton22.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton22.onHoverState.BorderRadius = 1;
            this.bunifuButton22.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.onHoverState.BorderThickness = 1;
            this.bunifuButton22.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton22.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.onHoverState.IconLeftImage = null;
            this.bunifuButton22.onHoverState.IconRightImage = null;
            this.bunifuButton22.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton22.OnIdleState.BorderRadius = 1;
            this.bunifuButton22.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.OnIdleState.BorderThickness = 1;
            this.bunifuButton22.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton22.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.OnIdleState.IconLeftImage = null;
            this.bunifuButton22.OnIdleState.IconRightImage = null;
            this.bunifuButton22.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton22.OnPressedState.BorderRadius = 1;
            this.bunifuButton22.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.OnPressedState.BorderThickness = 1;
            this.bunifuButton22.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton22.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.OnPressedState.IconLeftImage = null;
            this.bunifuButton22.OnPressedState.IconRightImage = null;
            this.bunifuButton22.Size = new System.Drawing.Size(272, 45);
            this.bunifuButton22.TabIndex = 1;
            this.bunifuButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton22.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton22.TextMarginLeft = 0;
            this.bunifuButton22.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton22.UseDefaultRadiusAndThickness = true;
            this.bunifuButton22.Click += new System.EventHandler(this.bunifuButton22_Click);
            // 
            // bunifuButton23
            // 
            this.bunifuButton23.AllowAnimations = true;
            this.bunifuButton23.AllowMouseEffects = true;
            this.bunifuButton23.AllowToggling = false;
            this.bunifuButton23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton23.AnimationSpeed = 200;
            this.bunifuButton23.AutoGenerateColors = false;
            this.bunifuButton23.AutoRoundBorders = false;
            this.bunifuButton23.AutoSizeLeftIcon = true;
            this.bunifuButton23.AutoSizeRightIcon = true;
            this.bunifuButton23.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton23.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton23.BackgroundImage")));
            this.bunifuButton23.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton23.ButtonText = "Tenant (Status)";
            this.bunifuButton23.ButtonTextMarginLeft = 0;
            this.bunifuButton23.ColorContrastOnClick = 45;
            this.bunifuButton23.ColorContrastOnHover = 45;
            this.bunifuButton23.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges24.BottomLeft = true;
            borderEdges24.BottomRight = true;
            borderEdges24.TopLeft = true;
            borderEdges24.TopRight = true;
            this.bunifuButton23.CustomizableEdges = borderEdges24;
            this.bunifuButton23.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton23.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton23.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton23.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton23.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton23.ForeColor = System.Drawing.Color.White;
            this.bunifuButton23.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton23.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton23.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton23.IconMarginLeft = 11;
            this.bunifuButton23.IconPadding = 10;
            this.bunifuButton23.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton23.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton23.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton23.IconSize = 25;
            this.bunifuButton23.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton23.IdleBorderRadius = 1;
            this.bunifuButton23.IdleBorderThickness = 1;
            this.bunifuButton23.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton23.IdleIconLeftImage = null;
            this.bunifuButton23.IdleIconRightImage = null;
            this.bunifuButton23.IndicateFocus = false;
            this.bunifuButton23.Location = new System.Drawing.Point(5, 96);
            this.bunifuButton23.Name = "bunifuButton23";
            this.bunifuButton23.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton23.OnDisabledState.BorderRadius = 1;
            this.bunifuButton23.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton23.OnDisabledState.BorderThickness = 1;
            this.bunifuButton23.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton23.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton23.OnDisabledState.IconLeftImage = null;
            this.bunifuButton23.OnDisabledState.IconRightImage = null;
            this.bunifuButton23.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton23.onHoverState.BorderRadius = 1;
            this.bunifuButton23.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton23.onHoverState.BorderThickness = 1;
            this.bunifuButton23.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton23.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton23.onHoverState.IconLeftImage = null;
            this.bunifuButton23.onHoverState.IconRightImage = null;
            this.bunifuButton23.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton23.OnIdleState.BorderRadius = 1;
            this.bunifuButton23.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton23.OnIdleState.BorderThickness = 1;
            this.bunifuButton23.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton23.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton23.OnIdleState.IconLeftImage = null;
            this.bunifuButton23.OnIdleState.IconRightImage = null;
            this.bunifuButton23.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton23.OnPressedState.BorderRadius = 1;
            this.bunifuButton23.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton23.OnPressedState.BorderThickness = 1;
            this.bunifuButton23.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton23.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton23.OnPressedState.IconLeftImage = null;
            this.bunifuButton23.OnPressedState.IconRightImage = null;
            this.bunifuButton23.Size = new System.Drawing.Size(272, 45);
            this.bunifuButton23.TabIndex = 2;
            this.bunifuButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton23.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton23.TextMarginLeft = 0;
            this.bunifuButton23.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton23.UseDefaultRadiusAndThickness = true;
            this.bunifuButton23.Click += new System.EventHandler(this.bunifuButton23_Click);
            // 
            // bunifuButton24
            // 
            this.bunifuButton24.AllowAnimations = true;
            this.bunifuButton24.AllowMouseEffects = true;
            this.bunifuButton24.AllowToggling = false;
            this.bunifuButton24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton24.AnimationSpeed = 200;
            this.bunifuButton24.AutoGenerateColors = false;
            this.bunifuButton24.AutoRoundBorders = false;
            this.bunifuButton24.AutoSizeLeftIcon = true;
            this.bunifuButton24.AutoSizeRightIcon = true;
            this.bunifuButton24.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton24.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton24.BackgroundImage")));
            this.bunifuButton24.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton24.ButtonText = "Add tenant";
            this.bunifuButton24.ButtonTextMarginLeft = 0;
            this.bunifuButton24.ColorContrastOnClick = 45;
            this.bunifuButton24.ColorContrastOnHover = 45;
            this.bunifuButton24.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges25.BottomLeft = true;
            borderEdges25.BottomRight = true;
            borderEdges25.TopLeft = true;
            borderEdges25.TopRight = true;
            this.bunifuButton24.CustomizableEdges = borderEdges25;
            this.bunifuButton24.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton24.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton24.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton24.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton24.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton24.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton24.ForeColor = System.Drawing.Color.White;
            this.bunifuButton24.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton24.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton24.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton24.IconMarginLeft = 11;
            this.bunifuButton24.IconPadding = 10;
            this.bunifuButton24.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton24.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton24.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton24.IconSize = 25;
            this.bunifuButton24.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton24.IdleBorderRadius = 1;
            this.bunifuButton24.IdleBorderThickness = 1;
            this.bunifuButton24.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton24.IdleIconLeftImage = null;
            this.bunifuButton24.IdleIconRightImage = null;
            this.bunifuButton24.IndicateFocus = false;
            this.bunifuButton24.Location = new System.Drawing.Point(5, 145);
            this.bunifuButton24.Name = "bunifuButton24";
            this.bunifuButton24.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton24.OnDisabledState.BorderRadius = 1;
            this.bunifuButton24.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton24.OnDisabledState.BorderThickness = 1;
            this.bunifuButton24.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton24.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton24.OnDisabledState.IconLeftImage = null;
            this.bunifuButton24.OnDisabledState.IconRightImage = null;
            this.bunifuButton24.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton24.onHoverState.BorderRadius = 1;
            this.bunifuButton24.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton24.onHoverState.BorderThickness = 1;
            this.bunifuButton24.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton24.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton24.onHoverState.IconLeftImage = null;
            this.bunifuButton24.onHoverState.IconRightImage = null;
            this.bunifuButton24.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton24.OnIdleState.BorderRadius = 1;
            this.bunifuButton24.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton24.OnIdleState.BorderThickness = 1;
            this.bunifuButton24.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton24.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton24.OnIdleState.IconLeftImage = null;
            this.bunifuButton24.OnIdleState.IconRightImage = null;
            this.bunifuButton24.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton24.OnPressedState.BorderRadius = 1;
            this.bunifuButton24.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton24.OnPressedState.BorderThickness = 1;
            this.bunifuButton24.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton24.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton24.OnPressedState.IconLeftImage = null;
            this.bunifuButton24.OnPressedState.IconRightImage = null;
            this.bunifuButton24.Size = new System.Drawing.Size(272, 45);
            this.bunifuButton24.TabIndex = 3;
            this.bunifuButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton24.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton24.TextMarginLeft = 0;
            this.bunifuButton24.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton24.UseDefaultRadiusAndThickness = true;
            this.bunifuButton24.Click += new System.EventHandler(this.bunifuButton24_Click);
            // 
            // bunifuButton21
            // 
            this.bunifuButton21.AllowAnimations = true;
            this.bunifuButton21.AllowMouseEffects = true;
            this.bunifuButton21.AllowToggling = false;
            this.bunifuButton21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton21.AnimationSpeed = 200;
            this.bunifuButton21.AutoGenerateColors = false;
            this.bunifuButton21.AutoRoundBorders = false;
            this.bunifuButton21.AutoSizeLeftIcon = true;
            this.bunifuButton21.AutoSizeRightIcon = true;
            this.bunifuButton21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton21.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton21.BackgroundImage")));
            this.bunifuButton21.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.ButtonText = "Tenant Portal";
            this.bunifuButton21.ButtonTextMarginLeft = 0;
            this.bunifuButton21.ColorContrastOnClick = 45;
            this.bunifuButton21.ColorContrastOnHover = 45;
            this.bunifuButton21.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges26.BottomLeft = true;
            borderEdges26.BottomRight = true;
            borderEdges26.TopLeft = true;
            borderEdges26.TopRight = true;
            this.bunifuButton21.CustomizableEdges = borderEdges26;
            this.bunifuButton21.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton21.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton21.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton21.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton21.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton21.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.bunifuButton21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(248)))), ((int)(((byte)(255)))));
            this.bunifuButton21.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton21.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton21.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton21.IconMarginLeft = 11;
            this.bunifuButton21.IconPadding = 10;
            this.bunifuButton21.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton21.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton21.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton21.IconSize = 25;
            this.bunifuButton21.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton21.IdleBorderRadius = 1;
            this.bunifuButton21.IdleBorderThickness = 1;
            this.bunifuButton21.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton21.IdleIconLeftImage = null;
            this.bunifuButton21.IdleIconRightImage = null;
            this.bunifuButton21.IndicateFocus = false;
            this.bunifuButton21.Location = new System.Drawing.Point(5, 3);
            this.bunifuButton21.Name = "bunifuButton21";
            this.bunifuButton21.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton21.OnDisabledState.BorderRadius = 1;
            this.bunifuButton21.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnDisabledState.BorderThickness = 1;
            this.bunifuButton21.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton21.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton21.OnDisabledState.IconLeftImage = null;
            this.bunifuButton21.OnDisabledState.IconRightImage = null;
            this.bunifuButton21.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton21.onHoverState.BorderRadius = 1;
            this.bunifuButton21.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.onHoverState.BorderThickness = 1;
            this.bunifuButton21.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton21.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.onHoverState.IconLeftImage = null;
            this.bunifuButton21.onHoverState.IconRightImage = null;
            this.bunifuButton21.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton21.OnIdleState.BorderRadius = 1;
            this.bunifuButton21.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnIdleState.BorderThickness = 1;
            this.bunifuButton21.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuButton21.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(248)))), ((int)(((byte)(255)))));
            this.bunifuButton21.OnIdleState.IconLeftImage = null;
            this.bunifuButton21.OnIdleState.IconRightImage = null;
            this.bunifuButton21.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton21.OnPressedState.BorderRadius = 1;
            this.bunifuButton21.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnPressedState.BorderThickness = 1;
            this.bunifuButton21.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton21.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.OnPressedState.IconLeftImage = null;
            this.bunifuButton21.OnPressedState.IconRightImage = null;
            this.bunifuButton21.Size = new System.Drawing.Size(271, 42);
            this.bunifuButton21.TabIndex = 0;
            this.bunifuButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton21.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton21.TextMarginLeft = 0;
            this.bunifuButton21.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton21.UseDefaultRadiusAndThickness = true;
            this.bunifuButton21.Click += new System.EventHandler(this.bunifuButton21_Click_1);
            // 
            // bunifuButton26
            // 
            this.bunifuButton26.AllowAnimations = true;
            this.bunifuButton26.AllowMouseEffects = true;
            this.bunifuButton26.AllowToggling = false;
            this.bunifuButton26.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuButton26.AnimationSpeed = 200;
            this.bunifuButton26.AutoGenerateColors = false;
            this.bunifuButton26.AutoRoundBorders = false;
            this.bunifuButton26.AutoSizeLeftIcon = true;
            this.bunifuButton26.AutoSizeRightIcon = true;
            this.bunifuButton26.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton26.BackColor1 = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton26.BackgroundImage")));
            this.bunifuButton26.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton26.ButtonText = "Contact Tenant";
            this.bunifuButton26.ButtonTextMarginLeft = 0;
            this.bunifuButton26.ColorContrastOnClick = 45;
            this.bunifuButton26.ColorContrastOnHover = 45;
            this.bunifuButton26.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges27.BottomLeft = true;
            borderEdges27.BottomRight = true;
            borderEdges27.TopLeft = true;
            borderEdges27.TopRight = true;
            this.bunifuButton26.CustomizableEdges = borderEdges27;
            this.bunifuButton26.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton26.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton26.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton26.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton26.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton26.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton26.ForeColor = System.Drawing.Color.White;
            this.bunifuButton26.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton26.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton26.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton26.IconMarginLeft = 11;
            this.bunifuButton26.IconPadding = 10;
            this.bunifuButton26.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton26.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton26.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton26.IconSize = 25;
            this.bunifuButton26.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton26.IdleBorderRadius = 1;
            this.bunifuButton26.IdleBorderThickness = 1;
            this.bunifuButton26.IdleFillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton26.IdleIconLeftImage = null;
            this.bunifuButton26.IdleIconRightImage = null;
            this.bunifuButton26.IndicateFocus = false;
            this.bunifuButton26.Location = new System.Drawing.Point(5, 194);
            this.bunifuButton26.Name = "bunifuButton26";
            this.bunifuButton26.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton26.OnDisabledState.BorderRadius = 1;
            this.bunifuButton26.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton26.OnDisabledState.BorderThickness = 1;
            this.bunifuButton26.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton26.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton26.OnDisabledState.IconLeftImage = null;
            this.bunifuButton26.OnDisabledState.IconRightImage = null;
            this.bunifuButton26.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton26.onHoverState.BorderRadius = 1;
            this.bunifuButton26.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton26.onHoverState.BorderThickness = 1;
            this.bunifuButton26.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton26.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton26.onHoverState.IconLeftImage = null;
            this.bunifuButton26.onHoverState.IconRightImage = null;
            this.bunifuButton26.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton26.OnIdleState.BorderRadius = 1;
            this.bunifuButton26.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton26.OnIdleState.BorderThickness = 1;
            this.bunifuButton26.OnIdleState.FillColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuButton26.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton26.OnIdleState.IconLeftImage = null;
            this.bunifuButton26.OnIdleState.IconRightImage = null;
            this.bunifuButton26.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton26.OnPressedState.BorderRadius = 1;
            this.bunifuButton26.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton26.OnPressedState.BorderThickness = 1;
            this.bunifuButton26.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton26.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton26.OnPressedState.IconLeftImage = null;
            this.bunifuButton26.OnPressedState.IconRightImage = null;
            this.bunifuButton26.Size = new System.Drawing.Size(272, 45);
            this.bunifuButton26.TabIndex = 5;
            this.bunifuButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton26.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton26.TextMarginLeft = 0;
            this.bunifuButton26.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton26.UseDefaultRadiusAndThickness = true;
            this.bunifuButton26.Click += new System.EventHandler(this.bunifuButton26_Click);
            // 
            // bunifuPanel1
            // 
            this.bunifuPanel1.BackgroundColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel1.BackgroundImage")));
            this.bunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel1.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel1.BorderRadius = 3;
            this.bunifuPanel1.BorderThickness = 0;
            this.bunifuPanel1.Controls.Add(this.bunifuButton26);
            this.bunifuPanel1.Controls.Add(this.bunifuButton21);
            this.bunifuPanel1.Controls.Add(this.bunifuButton24);
            this.bunifuPanel1.Controls.Add(this.bunifuButton23);
            this.bunifuPanel1.Controls.Add(this.bunifuButton22);
            this.bunifuPanel1.Location = new System.Drawing.Point(3, 8);
            this.bunifuPanel1.Name = "bunifuPanel1";
            this.bunifuPanel1.ShowBorders = true;
            this.bunifuPanel1.Size = new System.Drawing.Size(279, 243);
            this.bunifuPanel1.TabIndex = 0;
            // 
            // bunifuPanel6
            // 
            this.bunifuPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuPanel6.BackgroundColor = System.Drawing.Color.LightSkyBlue;
            this.bunifuPanel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel6.BackgroundImage")));
            this.bunifuPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel6.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel6.BorderRadius = 3;
            this.bunifuPanel6.BorderThickness = 1;
            this.bunifuPanel6.Controls.Add(this.bunifuPanel4);
            this.bunifuPanel6.Controls.Add(this.bunifuPanel3);
            this.bunifuPanel6.Controls.Add(this.bunifuPanel1);
            this.bunifuPanel6.Controls.Add(this.bunifuPanel5);
            this.bunifuPanel6.Location = new System.Drawing.Point(223, 20);
            this.bunifuPanel6.Name = "bunifuPanel6";
            this.bunifuPanel6.ShowBorders = true;
            this.bunifuPanel6.Size = new System.Drawing.Size(1146, 260);
            this.bunifuPanel6.TabIndex = 18;
            // 
            // bunifuPages1
            // 
            this.bunifuPages1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages1.AllowTransitions = false;
            this.bunifuPages1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuPages1.Controls.Add(this.tabPage1);
            this.bunifuPages1.Controls.Add(this.PageView);
            this.bunifuPages1.Controls.Add(this.listProperty);
            this.bunifuPages1.Controls.Add(this.maintenance);
            this.bunifuPages1.Controls.Add(this.payments);
            this.bunifuPages1.Controls.Add(this.PeriodicReports);
            this.bunifuPages1.Controls.Add(this.showlords);
            this.bunifuPages1.Controls.Add(this.zones);
            this.bunifuPages1.Controls.Add(this.complete);
            this.bunifuPages1.Controls.Add(this.incomplete);
            this.bunifuPages1.Controls.Add(this.occupied);
            this.bunifuPages1.Controls.Add(this.notOccupied);
            this.bunifuPages1.Controls.Add(this.VacancyPosition);
            this.bunifuPages1.Controls.Add(this.tabPage2);
            this.bunifuPages1.Controls.Add(this.amenity);
            this.bunifuPages1.Location = new System.Drawing.Point(219, 321);
            this.bunifuPages1.Multiline = true;
            this.bunifuPages1.Name = "bunifuPages1";
            this.bunifuPages1.Page = this.zones;
            this.bunifuPages1.PageIndex = 7;
            this.bunifuPages1.PageName = "zones";
            this.bunifuPages1.PageTitle = "Zones";
            this.bunifuPages1.SelectedIndex = 0;
            this.bunifuPages1.Size = new System.Drawing.Size(1213, 622);
            this.bunifuPages1.TabIndex = 20;
            animation1.AnimateOnlyDifferences = false;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.bunifuPages1.Transition = animation1;
            this.bunifuPages1.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.bunifuLabel4);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1205, 596);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Welcome Page";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Showcard Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.Location = new System.Drawing.Point(310, 301);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(797, 79);
            this.bunifuLabel4.TabIndex = 0;
            this.bunifuLabel4.Text = "Welcome to Parrallex";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuLabel4.Click += new System.EventHandler(this.bunifuLabel4_Click);
            // 
            // PageView
            // 
            this.PageView.Controls.Add(this.bunifuButton216);
            this.PageView.Controls.Add(this.bunifuLabel2);
            this.PageView.Controls.Add(this.datagridViewTenants);
            this.PageView.Location = new System.Drawing.Point(4, 4);
            this.PageView.Name = "PageView";
            this.PageView.Padding = new System.Windows.Forms.Padding(3);
            this.PageView.Size = new System.Drawing.Size(1205, 596);
            this.PageView.TabIndex = 0;
            this.PageView.Text = "TenantStatus";
            this.PageView.UseVisualStyleBackColor = true;
            // 
            // bunifuButton216
            // 
            this.bunifuButton216.AllowAnimations = true;
            this.bunifuButton216.AllowMouseEffects = true;
            this.bunifuButton216.AllowToggling = false;
            this.bunifuButton216.AnimationSpeed = 200;
            this.bunifuButton216.AutoGenerateColors = false;
            this.bunifuButton216.AutoRoundBorders = false;
            this.bunifuButton216.AutoSizeLeftIcon = true;
            this.bunifuButton216.AutoSizeRightIcon = true;
            this.bunifuButton216.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton216.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton216.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton216.BackgroundImage")));
            this.bunifuButton216.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton216.ButtonText = "Export To Excel";
            this.bunifuButton216.ButtonTextMarginLeft = 0;
            this.bunifuButton216.ColorContrastOnClick = 45;
            this.bunifuButton216.ColorContrastOnHover = 45;
            this.bunifuButton216.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges28.BottomLeft = true;
            borderEdges28.BottomRight = true;
            borderEdges28.TopLeft = true;
            borderEdges28.TopRight = true;
            this.bunifuButton216.CustomizableEdges = borderEdges28;
            this.bunifuButton216.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton216.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton216.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton216.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton216.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton216.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton216.ForeColor = System.Drawing.Color.White;
            this.bunifuButton216.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton216.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton216.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton216.IconMarginLeft = 11;
            this.bunifuButton216.IconPadding = 10;
            this.bunifuButton216.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton216.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton216.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton216.IconSize = 25;
            this.bunifuButton216.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton216.IdleBorderRadius = 1;
            this.bunifuButton216.IdleBorderThickness = 1;
            this.bunifuButton216.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton216.IdleIconLeftImage = null;
            this.bunifuButton216.IdleIconRightImage = null;
            this.bunifuButton216.IndicateFocus = false;
            this.bunifuButton216.Location = new System.Drawing.Point(1050, 0);
            this.bunifuButton216.Name = "bunifuButton216";
            this.bunifuButton216.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton216.OnDisabledState.BorderRadius = 1;
            this.bunifuButton216.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton216.OnDisabledState.BorderThickness = 1;
            this.bunifuButton216.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton216.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton216.OnDisabledState.IconLeftImage = null;
            this.bunifuButton216.OnDisabledState.IconRightImage = null;
            this.bunifuButton216.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton216.onHoverState.BorderRadius = 1;
            this.bunifuButton216.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton216.onHoverState.BorderThickness = 1;
            this.bunifuButton216.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton216.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton216.onHoverState.IconLeftImage = null;
            this.bunifuButton216.onHoverState.IconRightImage = null;
            this.bunifuButton216.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton216.OnIdleState.BorderRadius = 1;
            this.bunifuButton216.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton216.OnIdleState.BorderThickness = 1;
            this.bunifuButton216.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton216.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton216.OnIdleState.IconLeftImage = null;
            this.bunifuButton216.OnIdleState.IconRightImage = null;
            this.bunifuButton216.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton216.OnPressedState.BorderRadius = 1;
            this.bunifuButton216.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton216.OnPressedState.BorderThickness = 1;
            this.bunifuButton216.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton216.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton216.OnPressedState.IconLeftImage = null;
            this.bunifuButton216.OnPressedState.IconRightImage = null;
            this.bunifuButton216.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton216.TabIndex = 4;
            this.bunifuButton216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton216.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton216.TextMarginLeft = 0;
            this.bunifuButton216.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton216.UseDefaultRadiusAndThickness = true;
            this.bunifuButton216.Click += new System.EventHandler(this.bunifuButton216_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.Location = new System.Drawing.Point(3, 6);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(117, 25);
            this.bunifuLabel2.TabIndex = 2;
            this.bunifuLabel2.Text = "Tenant Status";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // datagridViewTenants
            // 
            this.datagridViewTenants.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.datagridViewTenants.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.datagridViewTenants.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewTenants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewTenants.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewTenants.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewTenants.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewTenants.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.datagridViewTenants.ColumnHeadersHeight = 40;
            this.datagridViewTenants.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.first_name,
            this.second_name,
            this.kra_pin,
            this.email,
            this.phone_number,
            this.id_number,
            this.unit,
            this.id_unit});
            this.datagridViewTenants.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewTenants.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewTenants.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewTenants.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewTenants.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewTenants.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewTenants.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewTenants.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewTenants.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewTenants.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewTenants.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewTenants.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewTenants.CurrentTheme.Name = null;
            this.datagridViewTenants.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewTenants.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewTenants.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewTenants.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewTenants.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewTenants.DefaultCellStyle = dataGridViewCellStyle3;
            this.datagridViewTenants.EnableHeadersVisualStyles = false;
            this.datagridViewTenants.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewTenants.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewTenants.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewTenants.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewTenants.Location = new System.Drawing.Point(6, 34);
            this.datagridViewTenants.Name = "datagridViewTenants";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewTenants.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.datagridViewTenants.RowHeadersVisible = false;
            this.datagridViewTenants.RowTemplate.Height = 40;
            this.datagridViewTenants.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewTenants.Size = new System.Drawing.Size(1193, 643);
            this.datagridViewTenants.TabIndex = 1;
            this.datagridViewTenants.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.datagridViewTenants.Click += new System.EventHandler(this.datagridViewTenants_Click);
            // 
            // first_name
            // 
            this.first_name.HeaderText = "First Name";
            this.first_name.Name = "first_name";
            // 
            // second_name
            // 
            this.second_name.HeaderText = "Second Name";
            this.second_name.Name = "second_name";
            // 
            // kra_pin
            // 
            this.kra_pin.HeaderText = "KRA PIN";
            this.kra_pin.Name = "kra_pin";
            // 
            // email
            // 
            this.email.HeaderText = "Email";
            this.email.Name = "email";
            // 
            // phone_number
            // 
            this.phone_number.HeaderText = "Phone Number";
            this.phone_number.Name = "phone_number";
            // 
            // id_number
            // 
            this.id_number.HeaderText = "ID Number";
            this.id_number.Name = "id_number";
            // 
            // unit
            // 
            this.unit.HeaderText = "Unit";
            this.unit.Name = "unit";
            // 
            // id_unit
            // 
            this.id_unit.HeaderText = "ID";
            this.id_unit.Name = "id_unit";
            // 
            // listProperty
            // 
            this.listProperty.Controls.Add(this.bunifuButton211);
            this.listProperty.Controls.Add(this.bunifuButton217);
            this.listProperty.Controls.Add(this.bunifuLabel3);
            this.listProperty.Controls.Add(this.datagridViewOccupiedUnits);
            this.listProperty.Location = new System.Drawing.Point(4, 4);
            this.listProperty.Name = "listProperty";
            this.listProperty.Padding = new System.Windows.Forms.Padding(3);
            this.listProperty.Size = new System.Drawing.Size(1205, 596);
            this.listProperty.TabIndex = 1;
            this.listProperty.Text = "listProperty";
            this.listProperty.UseVisualStyleBackColor = true;
            // 
            // bunifuButton211
            // 
            this.bunifuButton211.AllowAnimations = true;
            this.bunifuButton211.AllowMouseEffects = true;
            this.bunifuButton211.AllowToggling = false;
            this.bunifuButton211.AnimationSpeed = 200;
            this.bunifuButton211.AutoGenerateColors = false;
            this.bunifuButton211.AutoRoundBorders = false;
            this.bunifuButton211.AutoSizeLeftIcon = true;
            this.bunifuButton211.AutoSizeRightIcon = true;
            this.bunifuButton211.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton211.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton211.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton211.BackgroundImage")));
            this.bunifuButton211.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton211.ButtonText = "Refresh";
            this.bunifuButton211.ButtonTextMarginLeft = 0;
            this.bunifuButton211.ColorContrastOnClick = 45;
            this.bunifuButton211.ColorContrastOnHover = 45;
            this.bunifuButton211.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges29.BottomLeft = true;
            borderEdges29.BottomRight = true;
            borderEdges29.TopLeft = true;
            borderEdges29.TopRight = true;
            this.bunifuButton211.CustomizableEdges = borderEdges29;
            this.bunifuButton211.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton211.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton211.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton211.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton211.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton211.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton211.ForeColor = System.Drawing.Color.White;
            this.bunifuButton211.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton211.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton211.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton211.IconMarginLeft = 11;
            this.bunifuButton211.IconPadding = 10;
            this.bunifuButton211.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton211.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton211.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton211.IconSize = 25;
            this.bunifuButton211.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton211.IdleBorderRadius = 1;
            this.bunifuButton211.IdleBorderThickness = 1;
            this.bunifuButton211.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton211.IdleIconLeftImage = null;
            this.bunifuButton211.IdleIconRightImage = null;
            this.bunifuButton211.IndicateFocus = false;
            this.bunifuButton211.Location = new System.Drawing.Point(923, 3);
            this.bunifuButton211.Name = "bunifuButton211";
            this.bunifuButton211.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton211.OnDisabledState.BorderRadius = 1;
            this.bunifuButton211.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton211.OnDisabledState.BorderThickness = 1;
            this.bunifuButton211.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton211.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton211.OnDisabledState.IconLeftImage = null;
            this.bunifuButton211.OnDisabledState.IconRightImage = null;
            this.bunifuButton211.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton211.onHoverState.BorderRadius = 1;
            this.bunifuButton211.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton211.onHoverState.BorderThickness = 1;
            this.bunifuButton211.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton211.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton211.onHoverState.IconLeftImage = null;
            this.bunifuButton211.onHoverState.IconRightImage = null;
            this.bunifuButton211.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton211.OnIdleState.BorderRadius = 1;
            this.bunifuButton211.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton211.OnIdleState.BorderThickness = 1;
            this.bunifuButton211.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton211.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton211.OnIdleState.IconLeftImage = null;
            this.bunifuButton211.OnIdleState.IconRightImage = null;
            this.bunifuButton211.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton211.OnPressedState.BorderRadius = 1;
            this.bunifuButton211.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton211.OnPressedState.BorderThickness = 1;
            this.bunifuButton211.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton211.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton211.OnPressedState.IconLeftImage = null;
            this.bunifuButton211.OnPressedState.IconRightImage = null;
            this.bunifuButton211.Size = new System.Drawing.Size(111, 31);
            this.bunifuButton211.TabIndex = 6;
            this.bunifuButton211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton211.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton211.TextMarginLeft = 0;
            this.bunifuButton211.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton211.UseDefaultRadiusAndThickness = true;
            this.bunifuButton211.Click += new System.EventHandler(this.bunifuButton211_Click_1);
            // 
            // bunifuButton217
            // 
            this.bunifuButton217.AllowAnimations = true;
            this.bunifuButton217.AllowMouseEffects = true;
            this.bunifuButton217.AllowToggling = false;
            this.bunifuButton217.AnimationSpeed = 200;
            this.bunifuButton217.AutoGenerateColors = false;
            this.bunifuButton217.AutoRoundBorders = false;
            this.bunifuButton217.AutoSizeLeftIcon = true;
            this.bunifuButton217.AutoSizeRightIcon = true;
            this.bunifuButton217.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton217.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton217.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton217.BackgroundImage")));
            this.bunifuButton217.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton217.ButtonText = "Export To Excel";
            this.bunifuButton217.ButtonTextMarginLeft = 0;
            this.bunifuButton217.ColorContrastOnClick = 45;
            this.bunifuButton217.ColorContrastOnHover = 45;
            this.bunifuButton217.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges30.BottomLeft = true;
            borderEdges30.BottomRight = true;
            borderEdges30.TopLeft = true;
            borderEdges30.TopRight = true;
            this.bunifuButton217.CustomizableEdges = borderEdges30;
            this.bunifuButton217.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton217.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton217.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton217.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton217.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton217.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton217.ForeColor = System.Drawing.Color.White;
            this.bunifuButton217.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton217.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton217.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton217.IconMarginLeft = 11;
            this.bunifuButton217.IconPadding = 10;
            this.bunifuButton217.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton217.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton217.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton217.IconSize = 25;
            this.bunifuButton217.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton217.IdleBorderRadius = 1;
            this.bunifuButton217.IdleBorderThickness = 1;
            this.bunifuButton217.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton217.IdleIconLeftImage = null;
            this.bunifuButton217.IdleIconRightImage = null;
            this.bunifuButton217.IndicateFocus = false;
            this.bunifuButton217.Location = new System.Drawing.Point(1055, 0);
            this.bunifuButton217.Name = "bunifuButton217";
            this.bunifuButton217.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton217.OnDisabledState.BorderRadius = 1;
            this.bunifuButton217.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton217.OnDisabledState.BorderThickness = 1;
            this.bunifuButton217.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton217.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton217.OnDisabledState.IconLeftImage = null;
            this.bunifuButton217.OnDisabledState.IconRightImage = null;
            this.bunifuButton217.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton217.onHoverState.BorderRadius = 1;
            this.bunifuButton217.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton217.onHoverState.BorderThickness = 1;
            this.bunifuButton217.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton217.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton217.onHoverState.IconLeftImage = null;
            this.bunifuButton217.onHoverState.IconRightImage = null;
            this.bunifuButton217.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton217.OnIdleState.BorderRadius = 1;
            this.bunifuButton217.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton217.OnIdleState.BorderThickness = 1;
            this.bunifuButton217.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton217.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton217.OnIdleState.IconLeftImage = null;
            this.bunifuButton217.OnIdleState.IconRightImage = null;
            this.bunifuButton217.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton217.OnPressedState.BorderRadius = 1;
            this.bunifuButton217.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton217.OnPressedState.BorderThickness = 1;
            this.bunifuButton217.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton217.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton217.OnPressedState.IconLeftImage = null;
            this.bunifuButton217.OnPressedState.IconRightImage = null;
            this.bunifuButton217.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton217.TabIndex = 5;
            this.bunifuButton217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton217.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton217.TextMarginLeft = 0;
            this.bunifuButton217.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton217.UseDefaultRadiusAndThickness = true;
            this.bunifuButton217.Click += new System.EventHandler(this.bunifuButton217_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.Location = new System.Drawing.Point(21, 3);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(127, 21);
            this.bunifuLabel3.TabIndex = 2;
            this.bunifuLabel3.Text = "List Of Properties";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // datagridViewOccupiedUnits
            // 
            this.datagridViewOccupiedUnits.AllowCustomTheming = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.datagridViewOccupiedUnits.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.datagridViewOccupiedUnits.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewOccupiedUnits.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewOccupiedUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewOccupiedUnits.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewOccupiedUnits.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewOccupiedUnits.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.datagridViewOccupiedUnits.ColumnHeadersHeight = 40;
            this.datagridViewOccupiedUnits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_property,
            this.address,
            this.county,
            this.first_name_property,
            this.unit_count,
            this.id});
            this.datagridViewOccupiedUnits.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewOccupiedUnits.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewOccupiedUnits.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewOccupiedUnits.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewOccupiedUnits.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewOccupiedUnits.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewOccupiedUnits.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewOccupiedUnits.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewOccupiedUnits.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewOccupiedUnits.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewOccupiedUnits.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewOccupiedUnits.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewOccupiedUnits.CurrentTheme.Name = null;
            this.datagridViewOccupiedUnits.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewOccupiedUnits.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewOccupiedUnits.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewOccupiedUnits.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewOccupiedUnits.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewOccupiedUnits.DefaultCellStyle = dataGridViewCellStyle7;
            this.datagridViewOccupiedUnits.EnableHeadersVisualStyles = false;
            this.datagridViewOccupiedUnits.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewOccupiedUnits.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewOccupiedUnits.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewOccupiedUnits.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewOccupiedUnits.Location = new System.Drawing.Point(21, 36);
            this.datagridViewOccupiedUnits.Name = "datagridViewOccupiedUnits";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewOccupiedUnits.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.datagridViewOccupiedUnits.RowHeadersVisible = false;
            this.datagridViewOccupiedUnits.RowTemplate.Height = 40;
            this.datagridViewOccupiedUnits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewOccupiedUnits.Size = new System.Drawing.Size(1183, 608);
            this.datagridViewOccupiedUnits.TabIndex = 1;
            this.datagridViewOccupiedUnits.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.datagridViewOccupiedUnits.Click += new System.EventHandler(this.datagridViewOccupiedUnits_Click);
            // 
            // name_property
            // 
            this.name_property.HeaderText = "Name";
            this.name_property.Name = "name_property";
            // 
            // address
            // 
            this.address.HeaderText = "Address";
            this.address.Name = "address";
            // 
            // county
            // 
            this.county.HeaderText = "County";
            this.county.Name = "county";
            // 
            // first_name_property
            // 
            this.first_name_property.HeaderText = "First Name";
            this.first_name_property.Name = "first_name_property";
            // 
            // unit_count
            // 
            this.unit_count.HeaderText = "Unit";
            this.unit_count.Name = "unit_count";
            // 
            // id
            // 
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            // 
            // maintenance
            // 
            this.maintenance.Controls.Add(this.bunifuButton218);
            this.maintenance.Controls.Add(this.datagridViewMaintenance);
            this.maintenance.Controls.Add(this.bunifuLabel5);
            this.maintenance.Location = new System.Drawing.Point(4, 4);
            this.maintenance.Name = "maintenance";
            this.maintenance.Size = new System.Drawing.Size(1205, 596);
            this.maintenance.TabIndex = 3;
            this.maintenance.Text = "Maintenance";
            this.maintenance.UseVisualStyleBackColor = true;
            // 
            // bunifuButton218
            // 
            this.bunifuButton218.AllowAnimations = true;
            this.bunifuButton218.AllowMouseEffects = true;
            this.bunifuButton218.AllowToggling = false;
            this.bunifuButton218.AnimationSpeed = 200;
            this.bunifuButton218.AutoGenerateColors = false;
            this.bunifuButton218.AutoRoundBorders = false;
            this.bunifuButton218.AutoSizeLeftIcon = true;
            this.bunifuButton218.AutoSizeRightIcon = true;
            this.bunifuButton218.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton218.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton218.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton218.BackgroundImage")));
            this.bunifuButton218.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton218.ButtonText = "Export To Excel";
            this.bunifuButton218.ButtonTextMarginLeft = 0;
            this.bunifuButton218.ColorContrastOnClick = 45;
            this.bunifuButton218.ColorContrastOnHover = 45;
            this.bunifuButton218.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges31.BottomLeft = true;
            borderEdges31.BottomRight = true;
            borderEdges31.TopLeft = true;
            borderEdges31.TopRight = true;
            this.bunifuButton218.CustomizableEdges = borderEdges31;
            this.bunifuButton218.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton218.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton218.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton218.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton218.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton218.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton218.ForeColor = System.Drawing.Color.White;
            this.bunifuButton218.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton218.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton218.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton218.IconMarginLeft = 11;
            this.bunifuButton218.IconPadding = 10;
            this.bunifuButton218.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton218.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton218.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton218.IconSize = 25;
            this.bunifuButton218.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton218.IdleBorderRadius = 1;
            this.bunifuButton218.IdleBorderThickness = 1;
            this.bunifuButton218.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton218.IdleIconLeftImage = null;
            this.bunifuButton218.IdleIconRightImage = null;
            this.bunifuButton218.IndicateFocus = false;
            this.bunifuButton218.Location = new System.Drawing.Point(1060, 3);
            this.bunifuButton218.Name = "bunifuButton218";
            this.bunifuButton218.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton218.OnDisabledState.BorderRadius = 1;
            this.bunifuButton218.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton218.OnDisabledState.BorderThickness = 1;
            this.bunifuButton218.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton218.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton218.OnDisabledState.IconLeftImage = null;
            this.bunifuButton218.OnDisabledState.IconRightImage = null;
            this.bunifuButton218.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton218.onHoverState.BorderRadius = 1;
            this.bunifuButton218.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton218.onHoverState.BorderThickness = 1;
            this.bunifuButton218.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton218.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton218.onHoverState.IconLeftImage = null;
            this.bunifuButton218.onHoverState.IconRightImage = null;
            this.bunifuButton218.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton218.OnIdleState.BorderRadius = 1;
            this.bunifuButton218.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton218.OnIdleState.BorderThickness = 1;
            this.bunifuButton218.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton218.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton218.OnIdleState.IconLeftImage = null;
            this.bunifuButton218.OnIdleState.IconRightImage = null;
            this.bunifuButton218.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton218.OnPressedState.BorderRadius = 1;
            this.bunifuButton218.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton218.OnPressedState.BorderThickness = 1;
            this.bunifuButton218.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton218.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton218.OnPressedState.IconLeftImage = null;
            this.bunifuButton218.OnPressedState.IconRightImage = null;
            this.bunifuButton218.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton218.TabIndex = 9;
            this.bunifuButton218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton218.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton218.TextMarginLeft = 0;
            this.bunifuButton218.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton218.UseDefaultRadiusAndThickness = true;
            this.bunifuButton218.Click += new System.EventHandler(this.bunifuButton218_Click);
            // 
            // datagridViewMaintenance
            // 
            this.datagridViewMaintenance.AllowCustomTheming = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            this.datagridViewMaintenance.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.datagridViewMaintenance.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewMaintenance.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewMaintenance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewMaintenance.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewMaintenance.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewMaintenance.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.datagridViewMaintenance.ColumnHeadersHeight = 40;
            this.datagridViewMaintenance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maint_id,
            this.name,
            this.description,
            this.status,
            this.dataGridViewTextBoxColumn1});
            this.datagridViewMaintenance.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewMaintenance.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewMaintenance.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewMaintenance.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewMaintenance.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewMaintenance.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewMaintenance.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewMaintenance.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewMaintenance.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewMaintenance.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewMaintenance.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewMaintenance.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewMaintenance.CurrentTheme.Name = null;
            this.datagridViewMaintenance.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewMaintenance.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewMaintenance.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewMaintenance.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewMaintenance.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewMaintenance.DefaultCellStyle = dataGridViewCellStyle11;
            this.datagridViewMaintenance.EnableHeadersVisualStyles = false;
            this.datagridViewMaintenance.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewMaintenance.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewMaintenance.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewMaintenance.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewMaintenance.Location = new System.Drawing.Point(3, 43);
            this.datagridViewMaintenance.Name = "datagridViewMaintenance";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewMaintenance.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.datagridViewMaintenance.RowHeadersVisible = false;
            this.datagridViewMaintenance.RowTemplate.Height = 40;
            this.datagridViewMaintenance.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewMaintenance.Size = new System.Drawing.Size(1342, 601);
            this.datagridViewMaintenance.TabIndex = 8;
            this.datagridViewMaintenance.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.datagridViewMaintenance.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridViewMaintenance_CellClick);
            this.datagridViewMaintenance.Click += new System.EventHandler(this.datagridViewMaintenance_Click);
            // 
            // maint_id
            // 
            this.maint_id.HeaderText = "ID";
            this.maint_id.Name = "maint_id";
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            // 
            // description
            // 
            this.description.HeaderText = "Description";
            this.description.Name = "description";
            // 
            // status
            // 
            this.status.HeaderText = "Status";
            this.status.Name = "status";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AllowParentOverrides = false;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.Location = new System.Drawing.Point(3, 3);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(189, 30);
            this.bunifuLabel5.TabIndex = 7;
            this.bunifuLabel5.Text = "Maintenance Report";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // payments
            // 
            this.payments.Controls.Add(this.bunifuButton25);
            this.payments.Controls.Add(this.bunifuLabel6);
            this.payments.Controls.Add(this.datagridViewTransactions);
            this.payments.Location = new System.Drawing.Point(4, 4);
            this.payments.Name = "payments";
            this.payments.Size = new System.Drawing.Size(1205, 596);
            this.payments.TabIndex = 4;
            this.payments.Text = "Payments";
            this.payments.UseVisualStyleBackColor = true;
            // 
            // bunifuButton25
            // 
            this.bunifuButton25.AllowAnimations = true;
            this.bunifuButton25.AllowMouseEffects = true;
            this.bunifuButton25.AllowToggling = false;
            this.bunifuButton25.AnimationSpeed = 200;
            this.bunifuButton25.AutoGenerateColors = false;
            this.bunifuButton25.AutoRoundBorders = false;
            this.bunifuButton25.AutoSizeLeftIcon = true;
            this.bunifuButton25.AutoSizeRightIcon = true;
            this.bunifuButton25.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton25.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton25.BackgroundImage")));
            this.bunifuButton25.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton25.ButtonText = "Export To Excel";
            this.bunifuButton25.ButtonTextMarginLeft = 0;
            this.bunifuButton25.ColorContrastOnClick = 45;
            this.bunifuButton25.ColorContrastOnHover = 45;
            this.bunifuButton25.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges32.BottomLeft = true;
            borderEdges32.BottomRight = true;
            borderEdges32.TopLeft = true;
            borderEdges32.TopRight = true;
            this.bunifuButton25.CustomizableEdges = borderEdges32;
            this.bunifuButton25.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton25.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton25.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton25.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton25.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton25.ForeColor = System.Drawing.Color.White;
            this.bunifuButton25.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton25.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton25.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton25.IconMarginLeft = 11;
            this.bunifuButton25.IconPadding = 10;
            this.bunifuButton25.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton25.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton25.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton25.IconSize = 25;
            this.bunifuButton25.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton25.IdleBorderRadius = 1;
            this.bunifuButton25.IdleBorderThickness = 1;
            this.bunifuButton25.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton25.IdleIconLeftImage = null;
            this.bunifuButton25.IdleIconRightImage = null;
            this.bunifuButton25.IndicateFocus = false;
            this.bunifuButton25.Location = new System.Drawing.Point(1041, 8);
            this.bunifuButton25.Name = "bunifuButton25";
            this.bunifuButton25.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton25.OnDisabledState.BorderRadius = 1;
            this.bunifuButton25.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton25.OnDisabledState.BorderThickness = 1;
            this.bunifuButton25.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton25.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton25.OnDisabledState.IconLeftImage = null;
            this.bunifuButton25.OnDisabledState.IconRightImage = null;
            this.bunifuButton25.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton25.onHoverState.BorderRadius = 1;
            this.bunifuButton25.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton25.onHoverState.BorderThickness = 1;
            this.bunifuButton25.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton25.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton25.onHoverState.IconLeftImage = null;
            this.bunifuButton25.onHoverState.IconRightImage = null;
            this.bunifuButton25.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton25.OnIdleState.BorderRadius = 1;
            this.bunifuButton25.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton25.OnIdleState.BorderThickness = 1;
            this.bunifuButton25.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton25.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton25.OnIdleState.IconLeftImage = null;
            this.bunifuButton25.OnIdleState.IconRightImage = null;
            this.bunifuButton25.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton25.OnPressedState.BorderRadius = 1;
            this.bunifuButton25.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton25.OnPressedState.BorderThickness = 1;
            this.bunifuButton25.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton25.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton25.OnPressedState.IconLeftImage = null;
            this.bunifuButton25.OnPressedState.IconRightImage = null;
            this.bunifuButton25.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton25.TabIndex = 3;
            this.bunifuButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton25.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton25.TextMarginLeft = 0;
            this.bunifuButton25.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton25.UseDefaultRadiusAndThickness = true;
            this.bunifuButton25.Click += new System.EventHandler(this.bunifuButton25_Click);
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AllowParentOverrides = false;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel6.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel6.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel6.Location = new System.Drawing.Point(8, 8);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(84, 25);
            this.bunifuLabel6.TabIndex = 2;
            this.bunifuLabel6.Text = "Payments";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // datagridViewTransactions
            // 
            this.datagridViewTransactions.AllowCustomTheming = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            this.datagridViewTransactions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.datagridViewTransactions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewTransactions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewTransactions.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewTransactions.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewTransactions.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewTransactions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.datagridViewTransactions.ColumnHeadersHeight = 40;
            this.datagridViewTransactions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mpesa_code,
            this.amount,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.current_date,
            this.current_time,
            this.dataGridViewTextBoxColumn5});
            this.datagridViewTransactions.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewTransactions.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewTransactions.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewTransactions.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewTransactions.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewTransactions.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewTransactions.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewTransactions.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewTransactions.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewTransactions.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewTransactions.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewTransactions.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewTransactions.CurrentTheme.Name = null;
            this.datagridViewTransactions.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewTransactions.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewTransactions.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewTransactions.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewTransactions.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewTransactions.DefaultCellStyle = dataGridViewCellStyle15;
            this.datagridViewTransactions.EnableHeadersVisualStyles = false;
            this.datagridViewTransactions.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewTransactions.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewTransactions.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewTransactions.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewTransactions.Location = new System.Drawing.Point(7, 48);
            this.datagridViewTransactions.Name = "datagridViewTransactions";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewTransactions.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.datagridViewTransactions.RowHeadersVisible = false;
            this.datagridViewTransactions.RowTemplate.Height = 40;
            this.datagridViewTransactions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewTransactions.Size = new System.Drawing.Size(1183, 545);
            this.datagridViewTransactions.TabIndex = 1;
            this.datagridViewTransactions.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // mpesa_code
            // 
            this.mpesa_code.HeaderText = "Mpesa Code";
            this.mpesa_code.Name = "mpesa_code";
            // 
            // amount
            // 
            this.amount.HeaderText = "Amount";
            this.amount.Name = "amount";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Second Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Phone Number";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // current_date
            // 
            this.current_date.HeaderText = "Date";
            this.current_date.Name = "current_date";
            // 
            // current_time
            // 
            this.current_time.HeaderText = "Time";
            this.current_time.Name = "current_time";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Account Number";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // PeriodicReports
            // 
            this.PeriodicReports.Location = new System.Drawing.Point(4, 4);
            this.PeriodicReports.Name = "PeriodicReports";
            this.PeriodicReports.Size = new System.Drawing.Size(1205, 596);
            this.PeriodicReports.TabIndex = 5;
            this.PeriodicReports.Text = "Periodic Reports";
            this.PeriodicReports.UseVisualStyleBackColor = true;
            // 
            // showlords
            // 
            this.showlords.Location = new System.Drawing.Point(4, 4);
            this.showlords.Name = "showlords";
            this.showlords.Size = new System.Drawing.Size(1205, 596);
            this.showlords.TabIndex = 15;
            this.showlords.Text = "tabPage3";
            this.showlords.UseVisualStyleBackColor = true;
            // 
            // zones
            // 
            this.zones.Controls.Add(this.bunifuIconButton3);
            this.zones.Controls.Add(this.bunifuIconButton2);
            this.zones.Controls.Add(this.bunifuIconButton1);
            this.zones.Controls.Add(this.zoneDataGridView);
            this.zones.Controls.Add(this.bunifuLabel9);
            this.zones.Location = new System.Drawing.Point(4, 4);
            this.zones.Name = "zones";
            this.zones.Size = new System.Drawing.Size(1205, 596);
            this.zones.TabIndex = 7;
            this.zones.Text = "Zones";
            this.zones.UseVisualStyleBackColor = true;
            // 
            // bunifuIconButton1
            // 
            this.bunifuIconButton1.AllowAnimations = true;
            this.bunifuIconButton1.AllowBorderColorChanges = true;
            this.bunifuIconButton1.AllowMouseEffects = true;
            this.bunifuIconButton1.AnimationSpeed = 200;
            this.bunifuIconButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton1.BackgroundColor = System.Drawing.Color.Green;
            this.bunifuIconButton1.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuIconButton1.BorderRadius = 1;
            this.bunifuIconButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton1.BorderThickness = 1;
            this.bunifuIconButton1.ColorContrastOnClick = 30;
            this.bunifuIconButton1.ColorContrastOnHover = 30;
            this.bunifuIconButton1.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges35.BottomLeft = true;
            borderEdges35.BottomRight = true;
            borderEdges35.TopLeft = true;
            borderEdges35.TopRight = true;
            this.bunifuIconButton1.CustomizableEdges = borderEdges35;
            this.bunifuIconButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton1.Image = null;
            this.bunifuIconButton1.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton1.Location = new System.Drawing.Point(372, 3);
            this.bunifuIconButton1.Name = "bunifuIconButton1";
            this.bunifuIconButton1.RoundBorders = true;
            this.bunifuIconButton1.ShowBorders = true;
            this.bunifuIconButton1.Size = new System.Drawing.Size(53, 53);
            this.bunifuIconButton1.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton1.TabIndex = 7;
            this.bunifuIconButton1.Click += new System.EventHandler(this.bunifuIconButton1_Click);
            // 
            // zoneDataGridView
            // 
            this.zoneDataGridView.AllowCustomTheming = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.Black;
            this.zoneDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.zoneDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.zoneDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.zoneDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zoneDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.zoneDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.zoneDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.zoneDataGridView.ColumnHeadersHeight = 40;
            this.zoneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13});
            this.zoneDataGridView.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.zoneDataGridView.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.zoneDataGridView.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.zoneDataGridView.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.zoneDataGridView.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.zoneDataGridView.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.zoneDataGridView.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.zoneDataGridView.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.zoneDataGridView.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.zoneDataGridView.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.zoneDataGridView.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.zoneDataGridView.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.zoneDataGridView.CurrentTheme.Name = null;
            this.zoneDataGridView.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.zoneDataGridView.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.zoneDataGridView.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.zoneDataGridView.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.zoneDataGridView.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.zoneDataGridView.DefaultCellStyle = dataGridViewCellStyle19;
            this.zoneDataGridView.EnableHeadersVisualStyles = false;
            this.zoneDataGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.zoneDataGridView.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.zoneDataGridView.HeaderBgColor = System.Drawing.Color.Empty;
            this.zoneDataGridView.HeaderForeColor = System.Drawing.Color.White;
            this.zoneDataGridView.Location = new System.Drawing.Point(3, 62);
            this.zoneDataGridView.Name = "zoneDataGridView";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.zoneDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.zoneDataGridView.RowHeadersVisible = false;
            this.zoneDataGridView.RowTemplate.Height = 40;
            this.zoneDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.zoneDataGridView.Size = new System.Drawing.Size(1185, 531);
            this.zoneDataGridView.TabIndex = 3;
            this.zoneDataGridView.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Mpesa Code";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Second Name";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Phone Number";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Date";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Time";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Account Number";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // bunifuLabel9
            // 
            this.bunifuLabel9.AllowParentOverrides = false;
            this.bunifuLabel9.AutoEllipsis = false;
            this.bunifuLabel9.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel9.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel9.Location = new System.Drawing.Point(0, 3);
            this.bunifuLabel9.Name = "bunifuLabel9";
            this.bunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel9.Size = new System.Drawing.Size(51, 25);
            this.bunifuLabel9.TabIndex = 2;
            this.bunifuLabel9.Text = "Zones";
            this.bunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel9.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // complete
            // 
            this.complete.Controls.Add(this.bunifuButton225);
            this.complete.Controls.Add(this.bunifuLabel10);
            this.complete.Controls.Add(this.datagridViewComplete);
            this.complete.Location = new System.Drawing.Point(4, 4);
            this.complete.Name = "complete";
            this.complete.Size = new System.Drawing.Size(1205, 596);
            this.complete.TabIndex = 8;
            this.complete.Text = "Complete";
            this.complete.UseVisualStyleBackColor = true;
            // 
            // bunifuButton225
            // 
            this.bunifuButton225.AllowAnimations = true;
            this.bunifuButton225.AllowMouseEffects = true;
            this.bunifuButton225.AllowToggling = false;
            this.bunifuButton225.AnimationSpeed = 200;
            this.bunifuButton225.AutoGenerateColors = false;
            this.bunifuButton225.AutoRoundBorders = false;
            this.bunifuButton225.AutoSizeLeftIcon = true;
            this.bunifuButton225.AutoSizeRightIcon = true;
            this.bunifuButton225.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton225.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton225.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton225.BackgroundImage")));
            this.bunifuButton225.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton225.ButtonText = "Export To Excel";
            this.bunifuButton225.ButtonTextMarginLeft = 0;
            this.bunifuButton225.ColorContrastOnClick = 45;
            this.bunifuButton225.ColorContrastOnHover = 45;
            this.bunifuButton225.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges36.BottomLeft = true;
            borderEdges36.BottomRight = true;
            borderEdges36.TopLeft = true;
            borderEdges36.TopRight = true;
            this.bunifuButton225.CustomizableEdges = borderEdges36;
            this.bunifuButton225.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton225.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton225.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton225.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton225.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton225.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton225.ForeColor = System.Drawing.Color.White;
            this.bunifuButton225.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton225.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton225.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton225.IconMarginLeft = 11;
            this.bunifuButton225.IconPadding = 10;
            this.bunifuButton225.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton225.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton225.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton225.IconSize = 25;
            this.bunifuButton225.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton225.IdleBorderRadius = 1;
            this.bunifuButton225.IdleBorderThickness = 1;
            this.bunifuButton225.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton225.IdleIconLeftImage = null;
            this.bunifuButton225.IdleIconRightImage = null;
            this.bunifuButton225.IndicateFocus = false;
            this.bunifuButton225.Location = new System.Drawing.Point(1053, 0);
            this.bunifuButton225.Name = "bunifuButton225";
            this.bunifuButton225.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton225.OnDisabledState.BorderRadius = 1;
            this.bunifuButton225.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton225.OnDisabledState.BorderThickness = 1;
            this.bunifuButton225.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton225.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton225.OnDisabledState.IconLeftImage = null;
            this.bunifuButton225.OnDisabledState.IconRightImage = null;
            this.bunifuButton225.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton225.onHoverState.BorderRadius = 1;
            this.bunifuButton225.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton225.onHoverState.BorderThickness = 1;
            this.bunifuButton225.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton225.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton225.onHoverState.IconLeftImage = null;
            this.bunifuButton225.onHoverState.IconRightImage = null;
            this.bunifuButton225.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton225.OnIdleState.BorderRadius = 1;
            this.bunifuButton225.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton225.OnIdleState.BorderThickness = 1;
            this.bunifuButton225.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton225.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton225.OnIdleState.IconLeftImage = null;
            this.bunifuButton225.OnIdleState.IconRightImage = null;
            this.bunifuButton225.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton225.OnPressedState.BorderRadius = 1;
            this.bunifuButton225.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton225.OnPressedState.BorderThickness = 1;
            this.bunifuButton225.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton225.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton225.OnPressedState.IconLeftImage = null;
            this.bunifuButton225.OnPressedState.IconRightImage = null;
            this.bunifuButton225.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton225.TabIndex = 5;
            this.bunifuButton225.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton225.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton225.TextMarginLeft = 0;
            this.bunifuButton225.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton225.UseDefaultRadiusAndThickness = true;
            this.bunifuButton225.Click += new System.EventHandler(this.bunifuButton225_Click);
            // 
            // bunifuLabel10
            // 
            this.bunifuLabel10.AllowParentOverrides = false;
            this.bunifuLabel10.AutoEllipsis = false;
            this.bunifuLabel10.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel10.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel10.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel10.Location = new System.Drawing.Point(8, 8);
            this.bunifuLabel10.Name = "bunifuLabel10";
            this.bunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel10.Size = new System.Drawing.Size(158, 20);
            this.bunifuLabel10.TabIndex = 1;
            this.bunifuLabel10.Text = "Maintenance Complete";
            this.bunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel10.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // datagridViewComplete
            // 
            this.datagridViewComplete.AllowCustomTheming = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            this.datagridViewComplete.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.datagridViewComplete.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewComplete.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewComplete.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewComplete.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewComplete.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewComplete.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.datagridViewComplete.ColumnHeadersHeight = 40;
            this.datagridViewComplete.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_complete,
            this.description_complete,
            this.status_complete,
            this.amount_complete});
            this.datagridViewComplete.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewComplete.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewComplete.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewComplete.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewComplete.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewComplete.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewComplete.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewComplete.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewComplete.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewComplete.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewComplete.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewComplete.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewComplete.CurrentTheme.Name = null;
            this.datagridViewComplete.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewComplete.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewComplete.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewComplete.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewComplete.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewComplete.DefaultCellStyle = dataGridViewCellStyle23;
            this.datagridViewComplete.EnableHeadersVisualStyles = false;
            this.datagridViewComplete.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewComplete.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewComplete.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewComplete.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewComplete.Location = new System.Drawing.Point(6, 34);
            this.datagridViewComplete.Name = "datagridViewComplete";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewComplete.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.datagridViewComplete.RowHeadersVisible = false;
            this.datagridViewComplete.RowTemplate.Height = 40;
            this.datagridViewComplete.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewComplete.Size = new System.Drawing.Size(1336, 610);
            this.datagridViewComplete.TabIndex = 0;
            this.datagridViewComplete.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.datagridViewComplete.Click += new System.EventHandler(this.datagridViewComplete_Click);
            // 
            // name_complete
            // 
            this.name_complete.HeaderText = "Name";
            this.name_complete.Name = "name_complete";
            // 
            // description_complete
            // 
            this.description_complete.HeaderText = "Description";
            this.description_complete.Name = "description_complete";
            // 
            // status_complete
            // 
            this.status_complete.HeaderText = "Status";
            this.status_complete.Name = "status_complete";
            // 
            // amount_complete
            // 
            this.amount_complete.HeaderText = "Amount";
            this.amount_complete.Name = "amount_complete";
            // 
            // incomplete
            // 
            this.incomplete.Controls.Add(this.bunifuButton226);
            this.incomplete.Controls.Add(this.bunifuLabel11);
            this.incomplete.Controls.Add(this.datagridViewIncomplete);
            this.incomplete.Location = new System.Drawing.Point(4, 4);
            this.incomplete.Name = "incomplete";
            this.incomplete.Size = new System.Drawing.Size(1205, 596);
            this.incomplete.TabIndex = 9;
            this.incomplete.Text = "incomplete";
            this.incomplete.UseVisualStyleBackColor = true;
            // 
            // bunifuButton226
            // 
            this.bunifuButton226.AllowAnimations = true;
            this.bunifuButton226.AllowMouseEffects = true;
            this.bunifuButton226.AllowToggling = false;
            this.bunifuButton226.AnimationSpeed = 200;
            this.bunifuButton226.AutoGenerateColors = false;
            this.bunifuButton226.AutoRoundBorders = false;
            this.bunifuButton226.AutoSizeLeftIcon = true;
            this.bunifuButton226.AutoSizeRightIcon = true;
            this.bunifuButton226.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton226.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton226.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton226.BackgroundImage")));
            this.bunifuButton226.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton226.ButtonText = "Export To Excel";
            this.bunifuButton226.ButtonTextMarginLeft = 0;
            this.bunifuButton226.ColorContrastOnClick = 45;
            this.bunifuButton226.ColorContrastOnHover = 45;
            this.bunifuButton226.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges37.BottomLeft = true;
            borderEdges37.BottomRight = true;
            borderEdges37.TopLeft = true;
            borderEdges37.TopRight = true;
            this.bunifuButton226.CustomizableEdges = borderEdges37;
            this.bunifuButton226.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton226.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton226.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton226.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton226.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton226.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton226.ForeColor = System.Drawing.Color.White;
            this.bunifuButton226.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton226.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton226.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton226.IconMarginLeft = 11;
            this.bunifuButton226.IconPadding = 10;
            this.bunifuButton226.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton226.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton226.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton226.IconSize = 25;
            this.bunifuButton226.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton226.IdleBorderRadius = 1;
            this.bunifuButton226.IdleBorderThickness = 1;
            this.bunifuButton226.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton226.IdleIconLeftImage = null;
            this.bunifuButton226.IdleIconRightImage = null;
            this.bunifuButton226.IndicateFocus = false;
            this.bunifuButton226.Location = new System.Drawing.Point(1053, 3);
            this.bunifuButton226.Name = "bunifuButton226";
            this.bunifuButton226.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton226.OnDisabledState.BorderRadius = 1;
            this.bunifuButton226.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton226.OnDisabledState.BorderThickness = 1;
            this.bunifuButton226.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton226.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton226.OnDisabledState.IconLeftImage = null;
            this.bunifuButton226.OnDisabledState.IconRightImage = null;
            this.bunifuButton226.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton226.onHoverState.BorderRadius = 1;
            this.bunifuButton226.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton226.onHoverState.BorderThickness = 1;
            this.bunifuButton226.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton226.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton226.onHoverState.IconLeftImage = null;
            this.bunifuButton226.onHoverState.IconRightImage = null;
            this.bunifuButton226.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton226.OnIdleState.BorderRadius = 1;
            this.bunifuButton226.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton226.OnIdleState.BorderThickness = 1;
            this.bunifuButton226.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton226.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton226.OnIdleState.IconLeftImage = null;
            this.bunifuButton226.OnIdleState.IconRightImage = null;
            this.bunifuButton226.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton226.OnPressedState.BorderRadius = 1;
            this.bunifuButton226.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton226.OnPressedState.BorderThickness = 1;
            this.bunifuButton226.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton226.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton226.OnPressedState.IconLeftImage = null;
            this.bunifuButton226.OnPressedState.IconRightImage = null;
            this.bunifuButton226.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton226.TabIndex = 5;
            this.bunifuButton226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton226.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton226.TextMarginLeft = 0;
            this.bunifuButton226.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton226.UseDefaultRadiusAndThickness = true;
            this.bunifuButton226.Click += new System.EventHandler(this.bunifuButton226_Click);
            // 
            // bunifuLabel11
            // 
            this.bunifuLabel11.AllowParentOverrides = false;
            this.bunifuLabel11.AutoEllipsis = false;
            this.bunifuLabel11.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel11.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel11.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel11.Location = new System.Drawing.Point(7, 0);
            this.bunifuLabel11.Name = "bunifuLabel11";
            this.bunifuLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel11.Size = new System.Drawing.Size(214, 25);
            this.bunifuLabel11.TabIndex = 1;
            this.bunifuLabel11.Text = "Maintenance Incomplete";
            this.bunifuLabel11.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel11.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // datagridViewIncomplete
            // 
            this.datagridViewIncomplete.AllowCustomTheming = false;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            this.datagridViewIncomplete.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.datagridViewIncomplete.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewIncomplete.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewIncomplete.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewIncomplete.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewIncomplete.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewIncomplete.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.datagridViewIncomplete.ColumnHeadersHeight = 40;
            this.datagridViewIncomplete.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_incomplete,
            this.description_incomplete,
            this.status_incomplete,
            this.amount_incomplete});
            this.datagridViewIncomplete.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewIncomplete.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewIncomplete.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewIncomplete.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewIncomplete.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewIncomplete.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewIncomplete.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewIncomplete.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewIncomplete.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewIncomplete.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewIncomplete.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewIncomplete.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewIncomplete.CurrentTheme.Name = null;
            this.datagridViewIncomplete.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewIncomplete.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewIncomplete.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewIncomplete.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewIncomplete.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewIncomplete.DefaultCellStyle = dataGridViewCellStyle27;
            this.datagridViewIncomplete.EnableHeadersVisualStyles = false;
            this.datagridViewIncomplete.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewIncomplete.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewIncomplete.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewIncomplete.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewIncomplete.Location = new System.Drawing.Point(10, 36);
            this.datagridViewIncomplete.Name = "datagridViewIncomplete";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewIncomplete.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.datagridViewIncomplete.RowHeadersVisible = false;
            this.datagridViewIncomplete.RowTemplate.Height = 40;
            this.datagridViewIncomplete.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewIncomplete.Size = new System.Drawing.Size(1197, 608);
            this.datagridViewIncomplete.TabIndex = 0;
            this.datagridViewIncomplete.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // name_incomplete
            // 
            this.name_incomplete.HeaderText = "Name";
            this.name_incomplete.Name = "name_incomplete";
            // 
            // description_incomplete
            // 
            this.description_incomplete.HeaderText = "Description";
            this.description_incomplete.Name = "description_incomplete";
            // 
            // status_incomplete
            // 
            this.status_incomplete.HeaderText = "Status";
            this.status_incomplete.Name = "status_incomplete";
            // 
            // amount_incomplete
            // 
            this.amount_incomplete.HeaderText = "Amount";
            this.amount_incomplete.Name = "amount_incomplete";
            // 
            // occupied
            // 
            this.occupied.Controls.Add(this.bunifuButton227);
            this.occupied.Controls.Add(this.bunifuLabel8);
            this.occupied.Controls.Add(this.bunifuDataGridView1);
            this.occupied.Location = new System.Drawing.Point(4, 4);
            this.occupied.Name = "occupied";
            this.occupied.Size = new System.Drawing.Size(1205, 596);
            this.occupied.TabIndex = 10;
            this.occupied.Text = "occupied";
            this.occupied.UseVisualStyleBackColor = true;
            // 
            // bunifuButton227
            // 
            this.bunifuButton227.AllowAnimations = true;
            this.bunifuButton227.AllowMouseEffects = true;
            this.bunifuButton227.AllowToggling = false;
            this.bunifuButton227.AnimationSpeed = 200;
            this.bunifuButton227.AutoGenerateColors = false;
            this.bunifuButton227.AutoRoundBorders = false;
            this.bunifuButton227.AutoSizeLeftIcon = true;
            this.bunifuButton227.AutoSizeRightIcon = true;
            this.bunifuButton227.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton227.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton227.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton227.BackgroundImage")));
            this.bunifuButton227.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton227.ButtonText = "Export To Excel";
            this.bunifuButton227.ButtonTextMarginLeft = 0;
            this.bunifuButton227.ColorContrastOnClick = 45;
            this.bunifuButton227.ColorContrastOnHover = 45;
            this.bunifuButton227.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges38.BottomLeft = true;
            borderEdges38.BottomRight = true;
            borderEdges38.TopLeft = true;
            borderEdges38.TopRight = true;
            this.bunifuButton227.CustomizableEdges = borderEdges38;
            this.bunifuButton227.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton227.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton227.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton227.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton227.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton227.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton227.ForeColor = System.Drawing.Color.White;
            this.bunifuButton227.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton227.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton227.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton227.IconMarginLeft = 11;
            this.bunifuButton227.IconPadding = 10;
            this.bunifuButton227.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton227.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton227.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton227.IconSize = 25;
            this.bunifuButton227.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton227.IdleBorderRadius = 1;
            this.bunifuButton227.IdleBorderThickness = 1;
            this.bunifuButton227.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton227.IdleIconLeftImage = null;
            this.bunifuButton227.IdleIconRightImage = null;
            this.bunifuButton227.IndicateFocus = false;
            this.bunifuButton227.Location = new System.Drawing.Point(1041, 3);
            this.bunifuButton227.Name = "bunifuButton227";
            this.bunifuButton227.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton227.OnDisabledState.BorderRadius = 1;
            this.bunifuButton227.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton227.OnDisabledState.BorderThickness = 1;
            this.bunifuButton227.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton227.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton227.OnDisabledState.IconLeftImage = null;
            this.bunifuButton227.OnDisabledState.IconRightImage = null;
            this.bunifuButton227.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton227.onHoverState.BorderRadius = 1;
            this.bunifuButton227.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton227.onHoverState.BorderThickness = 1;
            this.bunifuButton227.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton227.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton227.onHoverState.IconLeftImage = null;
            this.bunifuButton227.onHoverState.IconRightImage = null;
            this.bunifuButton227.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton227.OnIdleState.BorderRadius = 1;
            this.bunifuButton227.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton227.OnIdleState.BorderThickness = 1;
            this.bunifuButton227.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton227.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton227.OnIdleState.IconLeftImage = null;
            this.bunifuButton227.OnIdleState.IconRightImage = null;
            this.bunifuButton227.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton227.OnPressedState.BorderRadius = 1;
            this.bunifuButton227.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton227.OnPressedState.BorderThickness = 1;
            this.bunifuButton227.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton227.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton227.OnPressedState.IconLeftImage = null;
            this.bunifuButton227.OnPressedState.IconRightImage = null;
            this.bunifuButton227.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton227.TabIndex = 5;
            this.bunifuButton227.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton227.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton227.TextMarginLeft = 0;
            this.bunifuButton227.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton227.UseDefaultRadiusAndThickness = true;
            this.bunifuButton227.Click += new System.EventHandler(this.bunifuButton227_Click);
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AllowParentOverrides = false;
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel8.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel8.Location = new System.Drawing.Point(11, 3);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(111, 21);
            this.bunifuLabel8.TabIndex = 1;
            this.bunifuLabel8.Text = "Occupied Units";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuDataGridView1
            // 
            this.bunifuDataGridView1.AllowCustomTheming = false;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.bunifuDataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuDataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.bunifuDataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.bunifuDataGridView1.ColumnHeadersHeight = 40;
            this.bunifuDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_occupied,
            this.unit_id,
            this.deposit_occ,
            this.rent_occ,
            this.hse_type_occ,
            this.no_of_bed});
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.Name = null;
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle31.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bunifuDataGridView1.DefaultCellStyle = dataGridViewCellStyle31;
            this.bunifuDataGridView1.EnableHeadersVisualStyles = false;
            this.bunifuDataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView1.HeaderBgColor = System.Drawing.Color.Empty;
            this.bunifuDataGridView1.HeaderForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.Location = new System.Drawing.Point(11, 40);
            this.bunifuDataGridView1.Name = "bunifuDataGridView1";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.bunifuDataGridView1.RowHeadersVisible = false;
            this.bunifuDataGridView1.RowTemplate.Height = 40;
            this.bunifuDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bunifuDataGridView1.Size = new System.Drawing.Size(1179, 604);
            this.bunifuDataGridView1.TabIndex = 0;
            this.bunifuDataGridView1.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.bunifuDataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuDataGridView1_CellClick);
            // 
            // name_occupied
            // 
            this.name_occupied.HeaderText = "Name";
            this.name_occupied.Name = "name_occupied";
            // 
            // unit_id
            // 
            this.unit_id.HeaderText = "Unit";
            this.unit_id.Name = "unit_id";
            // 
            // deposit_occ
            // 
            this.deposit_occ.HeaderText = "Deposit";
            this.deposit_occ.Name = "deposit_occ";
            // 
            // rent_occ
            // 
            this.rent_occ.HeaderText = "Rent";
            this.rent_occ.Name = "rent_occ";
            // 
            // hse_type_occ
            // 
            this.hse_type_occ.HeaderText = "House Type";
            this.hse_type_occ.Name = "hse_type_occ";
            // 
            // no_of_bed
            // 
            this.no_of_bed.HeaderText = "No: Of Bedrooms";
            this.no_of_bed.Name = "no_of_bed";
            // 
            // notOccupied
            // 
            this.notOccupied.Controls.Add(this.datagridViewNotOccupiedUnits);
            this.notOccupied.Controls.Add(this.bunifuButton219);
            this.notOccupied.Controls.Add(this.bunifuButton228);
            this.notOccupied.Controls.Add(this.bunifuLabel7);
            this.notOccupied.Location = new System.Drawing.Point(4, 4);
            this.notOccupied.Name = "notOccupied";
            this.notOccupied.Size = new System.Drawing.Size(1205, 596);
            this.notOccupied.TabIndex = 11;
            this.notOccupied.Text = "notOccupied";
            this.notOccupied.UseVisualStyleBackColor = true;
            // 
            // datagridViewNotOccupiedUnits
            // 
            this.datagridViewNotOccupiedUnits.AllowCustomTheming = false;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.Black;
            this.datagridViewNotOccupiedUnits.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.datagridViewNotOccupiedUnits.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridViewNotOccupiedUnits.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridViewNotOccupiedUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datagridViewNotOccupiedUnits.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagridViewNotOccupiedUnits.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewNotOccupiedUnits.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.datagridViewNotOccupiedUnits.ColumnHeadersHeight = 40;
            this.datagridViewNotOccupiedUnits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.unita_name,
            this.property_name,
            this.unit_deposit,
            this.unit_rent,
            this.unit_house_type,
            this.unit_no_of_bedrooms,
            this.unit_no_of_bathrooms,
            this.unit_tenants_count,
            this.units_id});
            this.datagridViewNotOccupiedUnits.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.datagridViewNotOccupiedUnits.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewNotOccupiedUnits.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewNotOccupiedUnits.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewNotOccupiedUnits.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datagridViewNotOccupiedUnits.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.datagridViewNotOccupiedUnits.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewNotOccupiedUnits.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewNotOccupiedUnits.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewNotOccupiedUnits.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.datagridViewNotOccupiedUnits.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.datagridViewNotOccupiedUnits.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.datagridViewNotOccupiedUnits.CurrentTheme.Name = null;
            this.datagridViewNotOccupiedUnits.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.datagridViewNotOccupiedUnits.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.datagridViewNotOccupiedUnits.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.datagridViewNotOccupiedUnits.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.datagridViewNotOccupiedUnits.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridViewNotOccupiedUnits.DefaultCellStyle = dataGridViewCellStyle35;
            this.datagridViewNotOccupiedUnits.EnableHeadersVisualStyles = false;
            this.datagridViewNotOccupiedUnits.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.datagridViewNotOccupiedUnits.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.datagridViewNotOccupiedUnits.HeaderBgColor = System.Drawing.Color.Empty;
            this.datagridViewNotOccupiedUnits.HeaderForeColor = System.Drawing.Color.White;
            this.datagridViewNotOccupiedUnits.Location = new System.Drawing.Point(12, 43);
            this.datagridViewNotOccupiedUnits.Name = "datagridViewNotOccupiedUnits";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridViewNotOccupiedUnits.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.datagridViewNotOccupiedUnits.RowHeadersVisible = false;
            this.datagridViewNotOccupiedUnits.RowTemplate.Height = 40;
            this.datagridViewNotOccupiedUnits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridViewNotOccupiedUnits.Size = new System.Drawing.Size(1195, 601);
            this.datagridViewNotOccupiedUnits.TabIndex = 7;
            this.datagridViewNotOccupiedUnits.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.datagridViewNotOccupiedUnits.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridViewNotOccupiedUnits_CellClick_1);
            // 
            // unita_name
            // 
            this.unita_name.HeaderText = "Unit Name";
            this.unita_name.Name = "unita_name";
            // 
            // property_name
            // 
            this.property_name.HeaderText = "Property Name";
            this.property_name.Name = "property_name";
            // 
            // unit_deposit
            // 
            this.unit_deposit.HeaderText = "Deposit";
            this.unit_deposit.Name = "unit_deposit";
            // 
            // unit_rent
            // 
            this.unit_rent.HeaderText = "Rent";
            this.unit_rent.Name = "unit_rent";
            // 
            // unit_house_type
            // 
            this.unit_house_type.HeaderText = "House Type";
            this.unit_house_type.Name = "unit_house_type";
            // 
            // unit_no_of_bedrooms
            // 
            this.unit_no_of_bedrooms.HeaderText = "Number Of Bedrooms";
            this.unit_no_of_bedrooms.Name = "unit_no_of_bedrooms";
            // 
            // unit_no_of_bathrooms
            // 
            this.unit_no_of_bathrooms.HeaderText = "Number of bathrooms";
            this.unit_no_of_bathrooms.Name = "unit_no_of_bathrooms";
            // 
            // unit_tenants_count
            // 
            this.unit_tenants_count.HeaderText = "Tenants count";
            this.unit_tenants_count.Name = "unit_tenants_count";
            // 
            // units_id
            // 
            this.units_id.HeaderText = "Id";
            this.units_id.Name = "units_id";
            // 
            // bunifuButton219
            // 
            this.bunifuButton219.AllowAnimations = true;
            this.bunifuButton219.AllowMouseEffects = true;
            this.bunifuButton219.AllowToggling = false;
            this.bunifuButton219.AnimationSpeed = 200;
            this.bunifuButton219.AutoGenerateColors = false;
            this.bunifuButton219.AutoRoundBorders = false;
            this.bunifuButton219.AutoSizeLeftIcon = true;
            this.bunifuButton219.AutoSizeRightIcon = true;
            this.bunifuButton219.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton219.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton219.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton219.BackgroundImage")));
            this.bunifuButton219.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton219.ButtonText = "Refresh";
            this.bunifuButton219.ButtonTextMarginLeft = 0;
            this.bunifuButton219.ColorContrastOnClick = 45;
            this.bunifuButton219.ColorContrastOnHover = 45;
            this.bunifuButton219.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges39.BottomLeft = true;
            borderEdges39.BottomRight = true;
            borderEdges39.TopLeft = true;
            borderEdges39.TopRight = true;
            this.bunifuButton219.CustomizableEdges = borderEdges39;
            this.bunifuButton219.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton219.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton219.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton219.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton219.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton219.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton219.ForeColor = System.Drawing.Color.White;
            this.bunifuButton219.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton219.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton219.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton219.IconMarginLeft = 11;
            this.bunifuButton219.IconPadding = 10;
            this.bunifuButton219.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton219.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton219.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton219.IconSize = 25;
            this.bunifuButton219.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton219.IdleBorderRadius = 1;
            this.bunifuButton219.IdleBorderThickness = 1;
            this.bunifuButton219.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton219.IdleIconLeftImage = null;
            this.bunifuButton219.IdleIconRightImage = null;
            this.bunifuButton219.IndicateFocus = false;
            this.bunifuButton219.Location = new System.Drawing.Point(889, 3);
            this.bunifuButton219.Name = "bunifuButton219";
            this.bunifuButton219.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton219.OnDisabledState.BorderRadius = 1;
            this.bunifuButton219.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton219.OnDisabledState.BorderThickness = 1;
            this.bunifuButton219.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton219.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton219.OnDisabledState.IconLeftImage = null;
            this.bunifuButton219.OnDisabledState.IconRightImage = null;
            this.bunifuButton219.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton219.onHoverState.BorderRadius = 1;
            this.bunifuButton219.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton219.onHoverState.BorderThickness = 1;
            this.bunifuButton219.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton219.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton219.onHoverState.IconLeftImage = null;
            this.bunifuButton219.onHoverState.IconRightImage = null;
            this.bunifuButton219.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton219.OnIdleState.BorderRadius = 1;
            this.bunifuButton219.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton219.OnIdleState.BorderThickness = 1;
            this.bunifuButton219.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton219.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton219.OnIdleState.IconLeftImage = null;
            this.bunifuButton219.OnIdleState.IconRightImage = null;
            this.bunifuButton219.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton219.OnPressedState.BorderRadius = 1;
            this.bunifuButton219.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton219.OnPressedState.BorderThickness = 1;
            this.bunifuButton219.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton219.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton219.OnPressedState.IconLeftImage = null;
            this.bunifuButton219.OnPressedState.IconRightImage = null;
            this.bunifuButton219.Size = new System.Drawing.Size(97, 29);
            this.bunifuButton219.TabIndex = 6;
            this.bunifuButton219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton219.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton219.TextMarginLeft = 0;
            this.bunifuButton219.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton219.UseDefaultRadiusAndThickness = true;
            this.bunifuButton219.Click += new System.EventHandler(this.bunifuButton219_Click);
            // 
            // bunifuButton228
            // 
            this.bunifuButton228.AllowAnimations = true;
            this.bunifuButton228.AllowMouseEffects = true;
            this.bunifuButton228.AllowToggling = false;
            this.bunifuButton228.AnimationSpeed = 200;
            this.bunifuButton228.AutoGenerateColors = false;
            this.bunifuButton228.AutoRoundBorders = false;
            this.bunifuButton228.AutoSizeLeftIcon = true;
            this.bunifuButton228.AutoSizeRightIcon = true;
            this.bunifuButton228.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton228.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton228.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton228.BackgroundImage")));
            this.bunifuButton228.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton228.ButtonText = "Export To Excel";
            this.bunifuButton228.ButtonTextMarginLeft = 0;
            this.bunifuButton228.ColorContrastOnClick = 45;
            this.bunifuButton228.ColorContrastOnHover = 45;
            this.bunifuButton228.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges40.BottomLeft = true;
            borderEdges40.BottomRight = true;
            borderEdges40.TopLeft = true;
            borderEdges40.TopRight = true;
            this.bunifuButton228.CustomizableEdges = borderEdges40;
            this.bunifuButton228.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton228.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton228.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton228.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton228.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton228.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton228.ForeColor = System.Drawing.Color.White;
            this.bunifuButton228.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton228.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton228.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton228.IconMarginLeft = 11;
            this.bunifuButton228.IconPadding = 10;
            this.bunifuButton228.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton228.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton228.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton228.IconSize = 25;
            this.bunifuButton228.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton228.IdleBorderRadius = 1;
            this.bunifuButton228.IdleBorderThickness = 1;
            this.bunifuButton228.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton228.IdleIconLeftImage = null;
            this.bunifuButton228.IdleIconRightImage = null;
            this.bunifuButton228.IndicateFocus = false;
            this.bunifuButton228.Location = new System.Drawing.Point(1007, 3);
            this.bunifuButton228.Name = "bunifuButton228";
            this.bunifuButton228.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton228.OnDisabledState.BorderRadius = 1;
            this.bunifuButton228.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton228.OnDisabledState.BorderThickness = 1;
            this.bunifuButton228.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton228.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton228.OnDisabledState.IconLeftImage = null;
            this.bunifuButton228.OnDisabledState.IconRightImage = null;
            this.bunifuButton228.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton228.onHoverState.BorderRadius = 1;
            this.bunifuButton228.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton228.onHoverState.BorderThickness = 1;
            this.bunifuButton228.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton228.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton228.onHoverState.IconLeftImage = null;
            this.bunifuButton228.onHoverState.IconRightImage = null;
            this.bunifuButton228.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton228.OnIdleState.BorderRadius = 1;
            this.bunifuButton228.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton228.OnIdleState.BorderThickness = 1;
            this.bunifuButton228.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton228.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton228.OnIdleState.IconLeftImage = null;
            this.bunifuButton228.OnIdleState.IconRightImage = null;
            this.bunifuButton228.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton228.OnPressedState.BorderRadius = 1;
            this.bunifuButton228.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton228.OnPressedState.BorderThickness = 1;
            this.bunifuButton228.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton228.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton228.OnPressedState.IconLeftImage = null;
            this.bunifuButton228.OnPressedState.IconRightImage = null;
            this.bunifuButton228.Size = new System.Drawing.Size(149, 34);
            this.bunifuButton228.TabIndex = 5;
            this.bunifuButton228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton228.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton228.TextMarginLeft = 0;
            this.bunifuButton228.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton228.UseDefaultRadiusAndThickness = true;
            this.bunifuButton228.Click += new System.EventHandler(this.bunifuButton228_Click);
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AllowParentOverrides = false;
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel7.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel7.Location = new System.Drawing.Point(12, 6);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(143, 21);
            this.bunifuLabel7.TabIndex = 0;
            this.bunifuLabel7.Text = "Units Not Occupied";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // VacancyPosition
            // 
            this.VacancyPosition.Controls.Add(this.bunifuLabel12);
            this.VacancyPosition.Controls.Add(this.bunifuDataGridView2);
            this.VacancyPosition.Location = new System.Drawing.Point(4, 4);
            this.VacancyPosition.Name = "VacancyPosition";
            this.VacancyPosition.Size = new System.Drawing.Size(1205, 596);
            this.VacancyPosition.TabIndex = 12;
            this.VacancyPosition.Text = "VacancyPosition";
            this.VacancyPosition.UseVisualStyleBackColor = true;
            // 
            // bunifuLabel12
            // 
            this.bunifuLabel12.AllowParentOverrides = false;
            this.bunifuLabel12.AutoEllipsis = false;
            this.bunifuLabel12.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel12.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel12.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel12.Location = new System.Drawing.Point(8, 6);
            this.bunifuLabel12.Name = "bunifuLabel12";
            this.bunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel12.Size = new System.Drawing.Size(116, 20);
            this.bunifuLabel12.TabIndex = 1;
            this.bunifuLabel12.Text = "Vacancy Position";
            this.bunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel12.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuDataGridView2
            // 
            this.bunifuDataGridView2.AllowCustomTheming = false;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle37;
            this.bunifuDataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuDataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuDataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.bunifuDataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle38;
            this.bunifuDataGridView2.ColumnHeadersHeight = 40;
            this.bunifuDataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_pos,
            this.address_pos,
            this.rent_pos,
            this.house_type});
            this.bunifuDataGridView2.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView2.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView2.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView2.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView2.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView2.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView2.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView2.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView2.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView2.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView2.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.bunifuDataGridView2.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView2.CurrentTheme.Name = null;
            this.bunifuDataGridView2.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView2.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView2.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView2.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView2.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bunifuDataGridView2.DefaultCellStyle = dataGridViewCellStyle39;
            this.bunifuDataGridView2.EnableHeadersVisualStyles = false;
            this.bunifuDataGridView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView2.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView2.HeaderBgColor = System.Drawing.Color.Empty;
            this.bunifuDataGridView2.HeaderForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView2.Location = new System.Drawing.Point(0, 32);
            this.bunifuDataGridView2.Name = "bunifuDataGridView2";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle40;
            this.bunifuDataGridView2.RowHeadersVisible = false;
            this.bunifuDataGridView2.RowTemplate.Height = 40;
            this.bunifuDataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bunifuDataGridView2.Size = new System.Drawing.Size(1187, 561);
            this.bunifuDataGridView2.TabIndex = 0;
            this.bunifuDataGridView2.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // name_pos
            // 
            this.name_pos.HeaderText = "Name";
            this.name_pos.Name = "name_pos";
            // 
            // address_pos
            // 
            this.address_pos.HeaderText = "Address";
            this.address_pos.Name = "address_pos";
            // 
            // rent_pos
            // 
            this.rent_pos.HeaderText = "Rent";
            this.rent_pos.Name = "rent_pos";
            // 
            // house_type
            // 
            this.house_type.HeaderText = "House Type";
            this.house_type.Name = "house_type";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.bunifuLabel13);
            this.tabPage2.Controls.Add(this.bunifuDataGridView3);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1205, 596);
            this.tabPage2.TabIndex = 13;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // bunifuLabel13
            // 
            this.bunifuLabel13.AllowParentOverrides = false;
            this.bunifuLabel13.AutoEllipsis = false;
            this.bunifuLabel13.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel13.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel13.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel13.Location = new System.Drawing.Point(8, 5);
            this.bunifuLabel13.Name = "bunifuLabel13";
            this.bunifuLabel13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel13.Size = new System.Drawing.Size(83, 25);
            this.bunifuLabel13.TabIndex = 1;
            this.bunifuLabel13.Text = "Messages";
            this.bunifuLabel13.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel13.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuDataGridView3
            // 
            this.bunifuDataGridView3.AllowCustomTheming = false;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.bunifuDataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuDataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuDataGridView3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.bunifuDataGridView3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.bunifuDataGridView3.ColumnHeadersHeight = 40;
            this.bunifuDataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_ms,
            this.apart_no,
            this.phne_number,
            this.email_ms,
            this.messages_ms});
            this.bunifuDataGridView3.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView3.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView3.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView3.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView3.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView3.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView3.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView3.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView3.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView3.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView3.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.bunifuDataGridView3.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView3.CurrentTheme.Name = null;
            this.bunifuDataGridView3.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView3.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView3.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView3.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView3.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bunifuDataGridView3.DefaultCellStyle = dataGridViewCellStyle43;
            this.bunifuDataGridView3.EnableHeadersVisualStyles = false;
            this.bunifuDataGridView3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView3.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView3.HeaderBgColor = System.Drawing.Color.Empty;
            this.bunifuDataGridView3.HeaderForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView3.Location = new System.Drawing.Point(6, 36);
            this.bunifuDataGridView3.Name = "bunifuDataGridView3";
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.bunifuDataGridView3.RowHeadersVisible = false;
            this.bunifuDataGridView3.RowTemplate.Height = 40;
            this.bunifuDataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bunifuDataGridView3.Size = new System.Drawing.Size(1325, 598);
            this.bunifuDataGridView3.TabIndex = 0;
            this.bunifuDataGridView3.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // name_ms
            // 
            this.name_ms.HeaderText = "Tenant Name";
            this.name_ms.Name = "name_ms";
            // 
            // apart_no
            // 
            this.apart_no.HeaderText = "Apartment";
            this.apart_no.Name = "apart_no";
            // 
            // phne_number
            // 
            this.phne_number.HeaderText = "Phone Number";
            this.phne_number.Name = "phne_number";
            // 
            // email_ms
            // 
            this.email_ms.HeaderText = "Email";
            this.email_ms.Name = "email_ms";
            // 
            // messages_ms
            // 
            this.messages_ms.HeaderText = "Messages";
            this.messages_ms.Name = "messages_ms";
            // 
            // amenity
            // 
            this.amenity.Controls.Add(this.bunifuDataGridView4);
            this.amenity.Controls.Add(this.bunifuLabel14);
            this.amenity.Location = new System.Drawing.Point(4, 4);
            this.amenity.Name = "amenity";
            this.amenity.Size = new System.Drawing.Size(1205, 596);
            this.amenity.TabIndex = 14;
            this.amenity.Text = "amenity";
            this.amenity.UseVisualStyleBackColor = true;
            // 
            // bunifuDataGridView4
            // 
            this.bunifuDataGridView4.AllowCustomTheming = false;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle45;
            this.bunifuDataGridView4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuDataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuDataGridView4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.bunifuDataGridView4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle46;
            this.bunifuDataGridView4.ColumnHeadersHeight = 40;
            this.bunifuDataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.utilities,
            this.salary,
            this.security,
            this.garbage});
            this.bunifuDataGridView4.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView4.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView4.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView4.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView4.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView4.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView4.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView4.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView4.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView4.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView4.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.bunifuDataGridView4.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView4.CurrentTheme.Name = null;
            this.bunifuDataGridView4.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView4.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView4.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView4.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView4.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bunifuDataGridView4.DefaultCellStyle = dataGridViewCellStyle47;
            this.bunifuDataGridView4.EnableHeadersVisualStyles = false;
            this.bunifuDataGridView4.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView4.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView4.HeaderBgColor = System.Drawing.Color.Empty;
            this.bunifuDataGridView4.HeaderForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView4.Location = new System.Drawing.Point(3, 36);
            this.bunifuDataGridView4.Name = "bunifuDataGridView4";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView4.RowHeadersDefaultCellStyle = dataGridViewCellStyle48;
            this.bunifuDataGridView4.RowHeadersVisible = false;
            this.bunifuDataGridView4.RowTemplate.Height = 40;
            this.bunifuDataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bunifuDataGridView4.Size = new System.Drawing.Size(1199, 614);
            this.bunifuDataGridView4.TabIndex = 1;
            this.bunifuDataGridView4.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.bunifuDataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuDataGridView4_CellClick);
            // 
            // utilities
            // 
            this.utilities.HeaderText = "Utilities";
            this.utilities.Name = "utilities";
            // 
            // salary
            // 
            this.salary.HeaderText = "salary";
            this.salary.Name = "salary";
            // 
            // security
            // 
            this.security.HeaderText = "Security";
            this.security.Name = "security";
            // 
            // garbage
            // 
            this.garbage.HeaderText = "Garbage collection";
            this.garbage.Name = "garbage";
            // 
            // bunifuLabel14
            // 
            this.bunifuLabel14.AllowParentOverrides = false;
            this.bunifuLabel14.AutoEllipsis = false;
            this.bunifuLabel14.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel14.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel14.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel14.Location = new System.Drawing.Point(3, 5);
            this.bunifuLabel14.Name = "bunifuLabel14";
            this.bunifuLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel14.Size = new System.Drawing.Size(162, 21);
            this.bunifuLabel14.TabIndex = 0;
            this.bunifuLabel14.Text = "Amenity Management";
            this.bunifuLabel14.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel14.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuIconButton2
            // 
            this.bunifuIconButton2.AllowAnimations = true;
            this.bunifuIconButton2.AllowBorderColorChanges = true;
            this.bunifuIconButton2.AllowMouseEffects = true;
            this.bunifuIconButton2.AnimationSpeed = 200;
            this.bunifuIconButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton2.BackgroundColor = System.Drawing.Color.Blue;
            this.bunifuIconButton2.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuIconButton2.BorderRadius = 1;
            this.bunifuIconButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton2.BorderThickness = 1;
            this.bunifuIconButton2.ColorContrastOnClick = 30;
            this.bunifuIconButton2.ColorContrastOnHover = 30;
            this.bunifuIconButton2.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges34.BottomLeft = true;
            borderEdges34.BottomRight = true;
            borderEdges34.TopLeft = true;
            borderEdges34.TopRight = true;
            this.bunifuIconButton2.CustomizableEdges = borderEdges34;
            this.bunifuIconButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton2.Image = null;
            this.bunifuIconButton2.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton2.Location = new System.Drawing.Point(546, 3);
            this.bunifuIconButton2.Name = "bunifuIconButton2";
            this.bunifuIconButton2.RoundBorders = true;
            this.bunifuIconButton2.ShowBorders = true;
            this.bunifuIconButton2.Size = new System.Drawing.Size(53, 53);
            this.bunifuIconButton2.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton2.TabIndex = 8;
            this.bunifuIconButton2.Click += new System.EventHandler(this.bunifuIconButton2_Click);
            // 
            // bunifuIconButton3
            // 
            this.bunifuIconButton3.AllowAnimations = true;
            this.bunifuIconButton3.AllowBorderColorChanges = true;
            this.bunifuIconButton3.AllowMouseEffects = true;
            this.bunifuIconButton3.AnimationSpeed = 200;
            this.bunifuIconButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton3.BackgroundColor = System.Drawing.Color.Red;
            this.bunifuIconButton3.BorderColor = System.Drawing.Color.White;
            this.bunifuIconButton3.BorderRadius = 1;
            this.bunifuIconButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton3.BorderThickness = 1;
            this.bunifuIconButton3.ColorContrastOnClick = 30;
            this.bunifuIconButton3.ColorContrastOnHover = 30;
            this.bunifuIconButton3.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges33.BottomLeft = true;
            borderEdges33.BottomRight = true;
            borderEdges33.TopLeft = true;
            borderEdges33.TopRight = true;
            this.bunifuIconButton3.CustomizableEdges = borderEdges33;
            this.bunifuIconButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton3.Image = null;
            this.bunifuIconButton3.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton3.Location = new System.Drawing.Point(700, 3);
            this.bunifuIconButton3.Name = "bunifuIconButton3";
            this.bunifuIconButton3.RoundBorders = true;
            this.bunifuIconButton3.ShowBorders = true;
            this.bunifuIconButton3.Size = new System.Drawing.Size(53, 53);
            this.bunifuIconButton3.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton3.TabIndex = 9;
            this.bunifuIconButton3.Click += new System.EventHandler(this.bunifuIconButton3_Click);
            // 
            // RentApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(1, 1);
            this.ClientSize = new System.Drawing.Size(1444, 955);
            this.Controls.Add(this.bunifuPages1);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.bunifuPanel6);
            this.Name = "RentApp";
            this.Text = "RentApp";
            this.Load += new System.EventHandler(this.RentApp_Load);
            this.bunifuPanel5.ResumeLayout(false);
            this.bunifuPanel4.ResumeLayout(false);
            this.bunifuPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlMenu.ResumeLayout(false);
            this.pnlMenu.PerformLayout();
            this.bunifuPanel2.ResumeLayout(false);
            this.bunifuPanel1.ResumeLayout(false);
            this.bunifuPanel6.ResumeLayout(false);
            this.bunifuPages1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.PageView.ResumeLayout(false);
            this.PageView.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewTenants)).EndInit();
            this.listProperty.ResumeLayout(false);
            this.listProperty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewOccupiedUnits)).EndInit();
            this.maintenance.ResumeLayout(false);
            this.maintenance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewMaintenance)).EndInit();
            this.payments.ResumeLayout(false);
            this.payments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewTransactions)).EndInit();
            this.zones.ResumeLayout(false);
            this.zones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zoneDataGridView)).EndInit();
            this.complete.ResumeLayout(false);
            this.complete.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewComplete)).EndInit();
            this.incomplete.ResumeLayout(false);
            this.incomplete.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewIncomplete)).EndInit();
            this.occupied.ResumeLayout(false);
            this.occupied.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView1)).EndInit();
            this.notOccupied.ResumeLayout(false);
            this.notOccupied.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridViewNotOccupiedUnits)).EndInit();
            this.VacancyPosition.ResumeLayout(false);
            this.VacancyPosition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView3)).EndInit();
            this.amenity.ResumeLayout(false);
            this.amenity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitModelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.propertyModelBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton5;
        private Bunifu.UI.WinForms.BunifuSeparator bunifuSeparator1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton buttonProperties;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.UI.WinForms.BunifuPanel pnlMenu;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton215;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton27;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton28;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton213;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton214;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton212;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton29;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton210;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton220;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton221;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton222;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton224;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton223;
        private Bunifu.UI.WinForms.BunifuColorTransition bunifuColorTransition1;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton6;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton22;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton23;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton24;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton21;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton26;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel1;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages1;
        private System.Windows.Forms.TabPage PageView;
        private System.Windows.Forms.TabPage listProperty;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewTenants;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewOccupiedUnits;
        private System.Windows.Forms.TabPage tabPage1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private System.Windows.Forms.TabPage maintenance;
        private System.Windows.Forms.TabPage payments;
        private System.Windows.Forms.TabPage PeriodicReports;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewMaintenance;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewTransactions;
        private System.Windows.Forms.TabPage zones;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel9;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_property;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.DataGridViewTextBoxColumn county;
        private System.Windows.Forms.DataGridViewTextBoxColumn first_name_property;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_count;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.TabPage complete;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewComplete;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_complete;
        private System.Windows.Forms.DataGridViewTextBoxColumn description_complete;
        private System.Windows.Forms.DataGridViewTextBoxColumn status_complete;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount_complete;
        private System.Windows.Forms.TabPage incomplete;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewIncomplete;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_incomplete;
        private System.Windows.Forms.DataGridViewTextBoxColumn description_incomplete;
        private System.Windows.Forms.DataGridViewTextBoxColumn status_incomplete;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount_incomplete;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel11;
        private System.Windows.Forms.BindingSource unitModelBindingSource;
        private System.Windows.Forms.BindingSource propertyModelBindingSource;
        private System.Windows.Forms.BindingSource unitModelBindingSource1;
        private System.Windows.Forms.TabPage occupied;
        private System.Windows.Forms.TabPage notOccupied;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuDataGridView bunifuDataGridView1;
        private System.Windows.Forms.TabPage VacancyPosition;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel12;
        private Bunifu.UI.WinForms.BunifuDataGridView bunifuDataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn address_pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn rent_pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn house_type;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton25;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton216;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton217;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton218;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton225;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton226;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton227;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton228;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton230;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton229;
        private System.Windows.Forms.DataGridViewTextBoxColumn mpesa_code;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn current_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn current_time;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TabPage tabPage2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel13;
        private Bunifu.UI.WinForms.BunifuDataGridView bunifuDataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_ms;
        private System.Windows.Forms.DataGridViewTextBoxColumn apart_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn phne_number;
        private System.Windows.Forms.DataGridViewTextBoxColumn email_ms;
        private System.Windows.Forms.DataGridViewTextBoxColumn messages_ms;
        private Bunifu.UI.WinForms.BunifuDataGridView zoneDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.TabPage amenity;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel14;
        private Bunifu.UI.WinForms.BunifuDataGridView bunifuDataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn utilities;
        private System.Windows.Forms.DataGridViewTextBoxColumn salary;
        private System.Windows.Forms.DataGridViewTextBoxColumn security;
        private System.Windows.Forms.DataGridViewTextBoxColumn garbage;
        private System.Windows.Forms.TabPage showlords;
        private System.Windows.Forms.DataGridViewTextBoxColumn maint_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn description;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton211;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton219;
        private System.Windows.Forms.DataGridViewTextBoxColumn first_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn second_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn kra_pin;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn phone_number;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_number;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_occupied;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn deposit_occ;
        private System.Windows.Forms.DataGridViewTextBoxColumn rent_occ;
        private System.Windows.Forms.DataGridViewTextBoxColumn hse_type_occ;
        private System.Windows.Forms.DataGridViewTextBoxColumn no_of_bed;
        private Bunifu.UI.WinForms.BunifuDataGridView datagridViewNotOccupiedUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn unita_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn property_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_deposit;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_rent;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_house_type;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_no_of_bedrooms;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_no_of_bathrooms;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_tenants_count;
        private System.Windows.Forms.DataGridViewTextBoxColumn units_id;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton2;
    }
}