﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Security.Policy;
using RentApp.Model;

namespace RentApp
{
    public partial class AddTenant : Form
    {
        public AddTenant()
        {
            InitializeComponent();
        }

   

        HttpClient client = new HttpClient();

        static AddTenant NewAddTenant;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            NewAddTenant = new AddTenant();
            NewAddTenant.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            NewAddTenant = new AddTenant();
            NewAddTenant.ShowDialog();
            return buttin_id;

        }

        private async void bunifuButton21_Click(object sender, EventArgs e)
        {
           

            try
            {

                var url = "http://165.232.121.9/properties/tenants/";
            
                var tenant = new tenantModel()
                {
                    first_name = first_name.Text,
                    second_name = second_name.Text,
                    third_name = third_name.Text,
                    kra_pin = kra_pin.Text,
                    email = email.Text,
                    phone_number = phone_number.Text,
                    id_number = id_number.Text,
                    unit = int.Parse(textbox_unit_id.Text),
                };


                var json = JsonConvert.SerializeObject(tenant);
                var data = new StringContent(json, Encoding.UTF8, "application/json");

               // StringContent data = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url, data);

                if (response.IsSuccessStatusCode)
                {
                    first_name.Clear();
                    second_name.Clear();
                    third_name.Clear();
                    kra_pin.Clear();
                    email.Clear();
                    phone_number.Clear();
                    id_number.Clear();
                    textbox_unit_id.Clear();

                    RentApp app = new RentApp();
                    app.loadData();
                }
                else
                {
                    MessageBox.Show(response.RequestMessage.ToString());
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

       
       

        private void AddTenant_Load(object sender, EventArgs e)
        {
            textbox_unit_id.Text = RentApp.unitsId;
        }
    }
    }
