﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentApp.Model
{
    public class maintenanceModel
    {
        public string name { get; set; }
        public string description { get; set; }
        public bool status { get; set; }
        public int unit { get; set; }
        public string amount { get; set; }
    }
}
