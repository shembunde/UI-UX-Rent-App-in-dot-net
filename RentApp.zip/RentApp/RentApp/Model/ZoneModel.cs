﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentApp.Model
{
    internal class ZoneModel

    {
        public string mpesa_code { get; set; }
        public string amount { get; set; }
        public string first_name { get; set; }
        public string second_name { get; set; }
        public string phone_number { get; set; }
        public string current_date { get; set; }
        public string current_time { get; set; }
        public string account_number { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
    }
}
