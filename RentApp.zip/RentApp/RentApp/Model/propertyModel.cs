﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentApp.Model
{
    public class propertyModel
    {
        public int id { get; set; }
        public List<unitModel> unit { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string county { get; set; }
        public string Landlord { get; set; }
    }
}
