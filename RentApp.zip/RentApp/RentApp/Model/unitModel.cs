﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentApp.Model
{
    public class unitModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public int property { get; set; }
        public string deposit { get; set; }
        public string rent { get; set; }
        public string house_type { get; set; }
        public int no_of_bedrooms { get; set; }
        public int no_of_bathrooms { get; set; }
        public string balcon { get; set; }
        public string floor { get; set; }
        public string square_foot { get; set; }
        public List<transactionModel> mpesa { get; set; }
        public List<maintenanceModel> maintainance { get; set; }
        public List<tenantModel> tenants { get; set; }
    }

}
