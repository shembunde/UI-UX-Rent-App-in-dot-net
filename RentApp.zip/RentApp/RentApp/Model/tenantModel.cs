﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentApp.Model
{
    public class tenantModel
    {
        public int id { get; set; }
        public int unit { get; set; }
        public string first_name { get; set; }
        public string second_name { get; set; }
        public string third_name { get; set; }
        public string kra_pin { get; set; }
        public string email { get; set; }
        public string phone_number { get; set; }
        public string id_number { get; set; }
    }
}
