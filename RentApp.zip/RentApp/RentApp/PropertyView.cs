﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class PropertyView : Form
    {
        public PropertyView()
        {
            InitializeComponent();
        }

        static PropertyView newPropertyView;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newPropertyView = new PropertyView();
            newPropertyView.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newPropertyView = new PropertyView();
            newPropertyView.ShowDialog();
            return buttin_id;

        }
    }
}
