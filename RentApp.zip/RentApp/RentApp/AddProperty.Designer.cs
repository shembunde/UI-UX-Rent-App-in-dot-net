﻿namespace RentApp
{
    partial class AddProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProperty));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.bunifuButton22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.textboxName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textboxLandlord = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textboxCounty = new Bunifu.UI.WinForms.BunifuTextBox();
            this.textboxAddress = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuSeparator1 = new Bunifu.UI.WinForms.BunifuSeparator();
            this.bunifuShadowPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel1.BorderRadius = 1;
            this.bunifuShadowPanel1.BorderThickness = 1;
            this.bunifuShadowPanel1.Controls.Add(this.bunifuButton22);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuButton21);
            this.bunifuShadowPanel1.Controls.Add(this.textboxName);
            this.bunifuShadowPanel1.Controls.Add(this.textboxLandlord);
            this.bunifuShadowPanel1.Controls.Add(this.textboxCounty);
            this.bunifuShadowPanel1.Controls.Add(this.textboxAddress);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuShadowPanel1.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel1.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(1, -23);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.CornflowerBlue;
            this.bunifuShadowPanel1.PanelColor2 = System.Drawing.Color.CornflowerBlue;
            this.bunifuShadowPanel1.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowDepth = 5;
            this.bunifuShadowPanel1.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(551, 468);
            this.bunifuShadowPanel1.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel1.TabIndex = 1;
            // 
            // bunifuButton22
            // 
            this.bunifuButton22.AllowAnimations = true;
            this.bunifuButton22.AllowMouseEffects = true;
            this.bunifuButton22.AllowToggling = false;
            this.bunifuButton22.AnimationSpeed = 200;
            this.bunifuButton22.AutoGenerateColors = false;
            this.bunifuButton22.AutoRoundBorders = false;
            this.bunifuButton22.AutoSizeLeftIcon = true;
            this.bunifuButton22.AutoSizeRightIcon = true;
            this.bunifuButton22.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton22.BackColor1 = System.Drawing.Color.Turquoise;
            this.bunifuButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton22.BackgroundImage")));
            this.bunifuButton22.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.ButtonText = "Update";
            this.bunifuButton22.ButtonTextMarginLeft = 0;
            this.bunifuButton22.ColorContrastOnClick = 45;
            this.bunifuButton22.ColorContrastOnHover = 45;
            this.bunifuButton22.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton22.CustomizableEdges = borderEdges1;
            this.bunifuButton22.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton22.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton22.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton22.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton22.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton22.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton22.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton22.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton22.IconMarginLeft = 11;
            this.bunifuButton22.IconPadding = 10;
            this.bunifuButton22.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton22.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton22.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton22.IconSize = 25;
            this.bunifuButton22.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton22.IdleBorderRadius = 1;
            this.bunifuButton22.IdleBorderThickness = 1;
            this.bunifuButton22.IdleFillColor = System.Drawing.Color.Turquoise;
            this.bunifuButton22.IdleIconLeftImage = null;
            this.bunifuButton22.IdleIconRightImage = null;
            this.bunifuButton22.IndicateFocus = false;
            this.bunifuButton22.Location = new System.Drawing.Point(308, 366);
            this.bunifuButton22.Name = "bunifuButton22";
            this.bunifuButton22.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton22.OnDisabledState.BorderRadius = 1;
            this.bunifuButton22.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.OnDisabledState.BorderThickness = 1;
            this.bunifuButton22.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton22.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton22.OnDisabledState.IconLeftImage = null;
            this.bunifuButton22.OnDisabledState.IconRightImage = null;
            this.bunifuButton22.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton22.onHoverState.BorderRadius = 1;
            this.bunifuButton22.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.onHoverState.BorderThickness = 1;
            this.bunifuButton22.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton22.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.onHoverState.IconLeftImage = null;
            this.bunifuButton22.onHoverState.IconRightImage = null;
            this.bunifuButton22.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton22.OnIdleState.BorderRadius = 1;
            this.bunifuButton22.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.OnIdleState.BorderThickness = 1;
            this.bunifuButton22.OnIdleState.FillColor = System.Drawing.Color.Turquoise;
            this.bunifuButton22.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.OnIdleState.IconLeftImage = null;
            this.bunifuButton22.OnIdleState.IconRightImage = null;
            this.bunifuButton22.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton22.OnPressedState.BorderRadius = 1;
            this.bunifuButton22.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton22.OnPressedState.BorderThickness = 1;
            this.bunifuButton22.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton22.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton22.OnPressedState.IconLeftImage = null;
            this.bunifuButton22.OnPressedState.IconRightImage = null;
            this.bunifuButton22.Size = new System.Drawing.Size(105, 46);
            this.bunifuButton22.TabIndex = 11;
            this.bunifuButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton22.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton22.TextMarginLeft = 0;
            this.bunifuButton22.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton22.UseDefaultRadiusAndThickness = true;
            // 
            // bunifuButton21
            // 
            this.bunifuButton21.AllowAnimations = true;
            this.bunifuButton21.AllowMouseEffects = true;
            this.bunifuButton21.AllowToggling = false;
            this.bunifuButton21.AnimationSpeed = 200;
            this.bunifuButton21.AutoGenerateColors = false;
            this.bunifuButton21.AutoRoundBorders = false;
            this.bunifuButton21.AutoSizeLeftIcon = true;
            this.bunifuButton21.AutoSizeRightIcon = true;
            this.bunifuButton21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton21.BackColor1 = System.Drawing.Color.Turquoise;
            this.bunifuButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton21.BackgroundImage")));
            this.bunifuButton21.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.ButtonText = "Add";
            this.bunifuButton21.ButtonTextMarginLeft = 0;
            this.bunifuButton21.ColorContrastOnClick = 45;
            this.bunifuButton21.ColorContrastOnHover = 45;
            this.bunifuButton21.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.bunifuButton21.CustomizableEdges = borderEdges2;
            this.bunifuButton21.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton21.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton21.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton21.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton21.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuButton21.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton21.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton21.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton21.IconMarginLeft = 11;
            this.bunifuButton21.IconPadding = 10;
            this.bunifuButton21.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton21.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton21.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton21.IconSize = 25;
            this.bunifuButton21.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton21.IdleBorderRadius = 1;
            this.bunifuButton21.IdleBorderThickness = 1;
            this.bunifuButton21.IdleFillColor = System.Drawing.Color.Turquoise;
            this.bunifuButton21.IdleIconLeftImage = null;
            this.bunifuButton21.IdleIconRightImage = null;
            this.bunifuButton21.IndicateFocus = false;
            this.bunifuButton21.Location = new System.Drawing.Point(63, 366);
            this.bunifuButton21.Name = "bunifuButton21";
            this.bunifuButton21.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton21.OnDisabledState.BorderRadius = 1;
            this.bunifuButton21.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnDisabledState.BorderThickness = 1;
            this.bunifuButton21.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton21.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton21.OnDisabledState.IconLeftImage = null;
            this.bunifuButton21.OnDisabledState.IconRightImage = null;
            this.bunifuButton21.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton21.onHoverState.BorderRadius = 1;
            this.bunifuButton21.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.onHoverState.BorderThickness = 1;
            this.bunifuButton21.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton21.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.onHoverState.IconLeftImage = null;
            this.bunifuButton21.onHoverState.IconRightImage = null;
            this.bunifuButton21.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton21.OnIdleState.BorderRadius = 1;
            this.bunifuButton21.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnIdleState.BorderThickness = 1;
            this.bunifuButton21.OnIdleState.FillColor = System.Drawing.Color.Turquoise;
            this.bunifuButton21.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.OnIdleState.IconLeftImage = null;
            this.bunifuButton21.OnIdleState.IconRightImage = null;
            this.bunifuButton21.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton21.OnPressedState.BorderRadius = 1;
            this.bunifuButton21.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnPressedState.BorderThickness = 1;
            this.bunifuButton21.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton21.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.OnPressedState.IconLeftImage = null;
            this.bunifuButton21.OnPressedState.IconRightImage = null;
            this.bunifuButton21.Size = new System.Drawing.Size(105, 46);
            this.bunifuButton21.TabIndex = 10;
            this.bunifuButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton21.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton21.TextMarginLeft = 0;
            this.bunifuButton21.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton21.UseDefaultRadiusAndThickness = true;
            this.bunifuButton21.Click += new System.EventHandler(this.bunifuButton21_Click);
            // 
            // textboxName
            // 
            this.textboxName.AcceptsReturn = false;
            this.textboxName.AcceptsTab = false;
            this.textboxName.AnimationSpeed = 200;
            this.textboxName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textboxName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textboxName.AutoSizeHeight = true;
            this.textboxName.BackColor = System.Drawing.Color.Transparent;
            this.textboxName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textboxName.BackgroundImage")));
            this.textboxName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textboxName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textboxName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textboxName.BorderColorIdle = System.Drawing.Color.Silver;
            this.textboxName.BorderRadius = 1;
            this.textboxName.BorderThickness = 1;
            this.textboxName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textboxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textboxName.DefaultText = "";
            this.textboxName.FillColor = System.Drawing.Color.White;
            this.textboxName.HideSelection = true;
            this.textboxName.IconLeft = null;
            this.textboxName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxName.IconPadding = 10;
            this.textboxName.IconRight = null;
            this.textboxName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxName.Lines = new string[0];
            this.textboxName.Location = new System.Drawing.Point(145, 113);
            this.textboxName.MaxLength = 32767;
            this.textboxName.MinimumSize = new System.Drawing.Size(1, 1);
            this.textboxName.Modified = false;
            this.textboxName.Multiline = false;
            this.textboxName.Name = "textboxName";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxName.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textboxName.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxName.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxName.OnIdleState = stateProperties4;
            this.textboxName.Padding = new System.Windows.Forms.Padding(3);
            this.textboxName.PasswordChar = '\0';
            this.textboxName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textboxName.PlaceholderText = "Property Name";
            this.textboxName.ReadOnly = false;
            this.textboxName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textboxName.SelectedText = "";
            this.textboxName.SelectionLength = 0;
            this.textboxName.SelectionStart = 0;
            this.textboxName.ShortcutsEnabled = true;
            this.textboxName.Size = new System.Drawing.Size(184, 50);
            this.textboxName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textboxName.TabIndex = 9;
            this.textboxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textboxName.TextMarginBottom = 0;
            this.textboxName.TextMarginLeft = 3;
            this.textboxName.TextMarginTop = 1;
            this.textboxName.TextPlaceholder = "Property Name";
            this.textboxName.UseSystemPasswordChar = false;
            this.textboxName.WordWrap = true;
            // 
            // textboxLandlord
            // 
            this.textboxLandlord.AcceptsReturn = false;
            this.textboxLandlord.AcceptsTab = false;
            this.textboxLandlord.AnimationSpeed = 200;
            this.textboxLandlord.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textboxLandlord.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textboxLandlord.AutoSizeHeight = true;
            this.textboxLandlord.BackColor = System.Drawing.Color.Transparent;
            this.textboxLandlord.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textboxLandlord.BackgroundImage")));
            this.textboxLandlord.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textboxLandlord.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textboxLandlord.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textboxLandlord.BorderColorIdle = System.Drawing.Color.Silver;
            this.textboxLandlord.BorderRadius = 1;
            this.textboxLandlord.BorderThickness = 1;
            this.textboxLandlord.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textboxLandlord.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxLandlord.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textboxLandlord.DefaultText = "";
            this.textboxLandlord.FillColor = System.Drawing.Color.White;
            this.textboxLandlord.HideSelection = true;
            this.textboxLandlord.IconLeft = null;
            this.textboxLandlord.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxLandlord.IconPadding = 10;
            this.textboxLandlord.IconRight = null;
            this.textboxLandlord.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxLandlord.Lines = new string[0];
            this.textboxLandlord.Location = new System.Drawing.Point(145, 281);
            this.textboxLandlord.MaxLength = 32767;
            this.textboxLandlord.MinimumSize = new System.Drawing.Size(1, 1);
            this.textboxLandlord.Modified = false;
            this.textboxLandlord.Multiline = false;
            this.textboxLandlord.Name = "textboxLandlord";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxLandlord.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textboxLandlord.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxLandlord.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxLandlord.OnIdleState = stateProperties8;
            this.textboxLandlord.Padding = new System.Windows.Forms.Padding(3);
            this.textboxLandlord.PasswordChar = '\0';
            this.textboxLandlord.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textboxLandlord.PlaceholderText = "Landlord";
            this.textboxLandlord.ReadOnly = false;
            this.textboxLandlord.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textboxLandlord.SelectedText = "";
            this.textboxLandlord.SelectionLength = 0;
            this.textboxLandlord.SelectionStart = 0;
            this.textboxLandlord.ShortcutsEnabled = true;
            this.textboxLandlord.Size = new System.Drawing.Size(184, 50);
            this.textboxLandlord.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textboxLandlord.TabIndex = 8;
            this.textboxLandlord.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textboxLandlord.TextMarginBottom = 0;
            this.textboxLandlord.TextMarginLeft = 3;
            this.textboxLandlord.TextMarginTop = 1;
            this.textboxLandlord.TextPlaceholder = "Landlord";
            this.textboxLandlord.UseSystemPasswordChar = false;
            this.textboxLandlord.WordWrap = true;
            // 
            // textboxCounty
            // 
            this.textboxCounty.AcceptsReturn = false;
            this.textboxCounty.AcceptsTab = false;
            this.textboxCounty.AnimationSpeed = 200;
            this.textboxCounty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textboxCounty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textboxCounty.AutoSizeHeight = true;
            this.textboxCounty.BackColor = System.Drawing.Color.Transparent;
            this.textboxCounty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textboxCounty.BackgroundImage")));
            this.textboxCounty.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textboxCounty.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textboxCounty.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textboxCounty.BorderColorIdle = System.Drawing.Color.Silver;
            this.textboxCounty.BorderRadius = 1;
            this.textboxCounty.BorderThickness = 1;
            this.textboxCounty.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textboxCounty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxCounty.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textboxCounty.DefaultText = "";
            this.textboxCounty.FillColor = System.Drawing.Color.White;
            this.textboxCounty.HideSelection = true;
            this.textboxCounty.IconLeft = null;
            this.textboxCounty.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxCounty.IconPadding = 10;
            this.textboxCounty.IconRight = null;
            this.textboxCounty.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxCounty.Lines = new string[0];
            this.textboxCounty.Location = new System.Drawing.Point(145, 225);
            this.textboxCounty.MaxLength = 32767;
            this.textboxCounty.MinimumSize = new System.Drawing.Size(1, 1);
            this.textboxCounty.Modified = false;
            this.textboxCounty.Multiline = false;
            this.textboxCounty.Name = "textboxCounty";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxCounty.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textboxCounty.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxCounty.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxCounty.OnIdleState = stateProperties12;
            this.textboxCounty.Padding = new System.Windows.Forms.Padding(3);
            this.textboxCounty.PasswordChar = '\0';
            this.textboxCounty.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textboxCounty.PlaceholderText = "County";
            this.textboxCounty.ReadOnly = false;
            this.textboxCounty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textboxCounty.SelectedText = "";
            this.textboxCounty.SelectionLength = 0;
            this.textboxCounty.SelectionStart = 0;
            this.textboxCounty.ShortcutsEnabled = true;
            this.textboxCounty.Size = new System.Drawing.Size(184, 50);
            this.textboxCounty.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textboxCounty.TabIndex = 7;
            this.textboxCounty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textboxCounty.TextMarginBottom = 0;
            this.textboxCounty.TextMarginLeft = 3;
            this.textboxCounty.TextMarginTop = 1;
            this.textboxCounty.TextPlaceholder = "County";
            this.textboxCounty.UseSystemPasswordChar = false;
            this.textboxCounty.WordWrap = true;
            // 
            // textboxAddress
            // 
            this.textboxAddress.AcceptsReturn = false;
            this.textboxAddress.AcceptsTab = false;
            this.textboxAddress.AnimationSpeed = 200;
            this.textboxAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.textboxAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.textboxAddress.AutoSizeHeight = true;
            this.textboxAddress.BackColor = System.Drawing.Color.Transparent;
            this.textboxAddress.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textboxAddress.BackgroundImage")));
            this.textboxAddress.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.textboxAddress.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textboxAddress.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.textboxAddress.BorderColorIdle = System.Drawing.Color.Silver;
            this.textboxAddress.BorderRadius = 1;
            this.textboxAddress.BorderThickness = 1;
            this.textboxAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.textboxAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxAddress.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.textboxAddress.DefaultText = "";
            this.textboxAddress.FillColor = System.Drawing.Color.White;
            this.textboxAddress.HideSelection = true;
            this.textboxAddress.IconLeft = null;
            this.textboxAddress.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxAddress.IconPadding = 10;
            this.textboxAddress.IconRight = null;
            this.textboxAddress.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.textboxAddress.Lines = new string[0];
            this.textboxAddress.Location = new System.Drawing.Point(145, 169);
            this.textboxAddress.MaxLength = 32767;
            this.textboxAddress.MinimumSize = new System.Drawing.Size(1, 1);
            this.textboxAddress.Modified = false;
            this.textboxAddress.Multiline = false;
            this.textboxAddress.Name = "textboxAddress";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxAddress.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.textboxAddress.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxAddress.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.textboxAddress.OnIdleState = stateProperties16;
            this.textboxAddress.Padding = new System.Windows.Forms.Padding(3);
            this.textboxAddress.PasswordChar = '\0';
            this.textboxAddress.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textboxAddress.PlaceholderText = "Address";
            this.textboxAddress.ReadOnly = false;
            this.textboxAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textboxAddress.SelectedText = "";
            this.textboxAddress.SelectionLength = 0;
            this.textboxAddress.SelectionStart = 0;
            this.textboxAddress.ShortcutsEnabled = true;
            this.textboxAddress.Size = new System.Drawing.Size(184, 50);
            this.textboxAddress.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.textboxAddress.TabIndex = 2;
            this.textboxAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.textboxAddress.TextMarginBottom = 0;
            this.textboxAddress.TextMarginLeft = 3;
            this.textboxAddress.TextMarginTop = 1;
            this.textboxAddress.TextPlaceholder = "Address";
            this.textboxAddress.UseSystemPasswordChar = false;
            this.textboxAddress.WordWrap = true;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.Location = new System.Drawing.Point(191, 45);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(92, 21);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "Add Property";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuSeparator1.BackgroundImage")));
            this.bunifuSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuSeparator1.DashCap = Bunifu.UI.WinForms.BunifuSeparator.CapStyles.Flat;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.Silver;
            this.bunifuSeparator1.LineStyle = Bunifu.UI.WinForms.BunifuSeparator.LineStyles.Solid;
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(63, 61);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Orientation = Bunifu.UI.WinForms.BunifuSeparator.LineOrientation.Horizontal;
            this.bunifuSeparator1.Size = new System.Drawing.Size(319, 46);
            this.bunifuSeparator1.TabIndex = 0;
            // 
            // AddProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 447);
            this.Controls.Add(this.bunifuShadowPanel1);
            this.Name = "AddProperty";
            this.Text = "Add Property";
            this.Load += new System.EventHandler(this.AddProperty_Load);
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton22;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton21;
        private Bunifu.UI.WinForms.BunifuTextBox textboxName;
        private Bunifu.UI.WinForms.BunifuTextBox textboxLandlord;
        private Bunifu.UI.WinForms.BunifuTextBox textboxCounty;
        private Bunifu.UI.WinForms.BunifuTextBox textboxAddress;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuSeparator bunifuSeparator1;
    }
}