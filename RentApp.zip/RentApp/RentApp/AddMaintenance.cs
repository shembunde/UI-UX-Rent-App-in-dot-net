﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class AddMaintenance : Form
    {
        public AddMaintenance()
        {
            InitializeComponent();
        }

        static AddMaintenance newAddMaintenance;
        static string buttin_id;


        public static string ShowBox(String txtMessage)
        {
            newAddMaintenance = new AddMaintenance();
            newAddMaintenance.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newAddMaintenance = new AddMaintenance();
            newAddMaintenance.ShowDialog();
            return buttin_id;

        }

        private void bunifuButton21_Click(object sender, EventArgs e)
        {

        }
    }
}
