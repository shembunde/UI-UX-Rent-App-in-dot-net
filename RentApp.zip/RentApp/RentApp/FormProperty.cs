﻿using Newtonsoft.Json;
using RentApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class FormProperty : Form
    {
        public FormProperty()
        {
            InitializeComponent();
        }

        private void FormProperty_Load(object sender, EventArgs e)
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                IEnumerable<propertyModel> properties = null;
                client.BaseAddress = new Uri(url);
                var consumeApi = client.GetAsync("property/");
                consumeApi.Wait();

                var readdata = consumeApi.Result;
                if (readdata.IsSuccessStatusCode)
                {
                    var displaydata = readdata.Content.ReadAsAsync<IList<propertyModel>>();
                    displaydata.Wait();

                    properties = displaydata.Result;

                    DataTable table = new DataTable();

                    table.Columns.Add("ID", typeof(int));
                    table.Columns.Add("Unit Name", typeof(string));
                    table.Columns.Add("Bedrooms", typeof(string));
                    table.Columns.Add("Bathrooms", typeof(string));
                    table.Columns.Add("Tenants", typeof(string));
                    table.Columns.Add("Balcony", typeof(string));
                    table.Columns.Add("Property", typeof(string));
                    table.Columns.Add("Address", typeof(string));


                    string count_tenants = "";
                    foreach (var property in properties)
                    {
                        foreach(var unit in property.unit)
                        {
                            count_tenants = unit.tenants.Count.ToString();
                            table.Rows.Add(unit.id, unit.name, unit.no_of_bedrooms, unit.no_of_bathrooms, count_tenants, unit.balcon, property.name, property.address);
                        }
                    }

                    dataGridViewProperties.DataSource = table;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewProperties_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textName.Text = dataGridViewProperties.CurrentRow.Cells[6].Value.ToString();
            TextNumberOFUnits.Text = dataGridViewProperties.CurrentRow.Cells[4].Value.ToString();
            textNumberOfTenants.Text = dataGridViewProperties.CurrentRow.Cells[2].Value.ToString();
        }

        private async void bunifuIconButton1_Click(object sender, EventArgs e)
        {
            try
            {

                string url = "https://mevanlix.co.ke/properties/";

                HttpClient client = new HttpClient();

                var property = new propertyModel()
                {
                    name = textBoxName.Text,
                    address = textBoxAddress.Text,
                    county = textBoxCounty.Text,
                    Landlord = textBoxlandLord.Text

                };

                var json = JsonConvert.SerializeObject(property);
                StringContent data = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url + "property/", data);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Insert successfull");
                    textBoxName.Clear();
                    textBoxAddress.Clear();
                    textBoxCounty.Clear();
                    textBoxlandLord.Clear();
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
