﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class GreenZone : Form
    {
        public GreenZone()
        {
            InitializeComponent();
        }



        static GreenZone newGreenZone;
        static string buttin_id;

        public static string ShowBox(String txtMessage)
        {
            newGreenZone = new GreenZone();
            newGreenZone.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newGreenZone = new GreenZone();
            newGreenZone.ShowDialog();
            return buttin_id;

        }
    }
}
