﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentApp
{
    public partial class RedZone : Form
    {
        public RedZone()
        {
            InitializeComponent();
        }

        static RedZone newRedZone;
        static string buttin_id;

        public static string ShowBox(String txtMessage)
        {
            newRedZone = new RedZone();
            newRedZone.ShowDialog();
            return buttin_id;

        }
        public static string ShowBox(String txtMessage, string txtTitle)
        {
            newRedZone = new RedZone();
            newRedZone.ShowDialog();
            return buttin_id;

        }

    }
}
